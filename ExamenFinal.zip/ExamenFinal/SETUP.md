# SETUP — CRUD de Usuarios y Roles (Approx / Laravel 11)

Instrucciones para levantar este proyecto **desde cero en un computador distinto** al usado para desarrollarlo. Sigue los pasos en orden; no se asume ningún paso implícito.

## 1. Requisitos previos

- PHP >= 8.2 con extensiones habituales de Laravel (`pdo_sqlite`, `mbstring`, `openssl`, `tokenizer`, `xml`, `ctype`, `json`)
- Composer 2.x
- Node.js/Bun (para compilar assets front-end con Vite). Si no tienes `bun`, usa `npm` como alternativa.

## 2. Ubicación del proyecto

El proyecto Laravel autocontenido está en:

```
ExamenFinal/approx-laravel_v1.0/Approx/
```

Todos los comandos siguientes se ejecutan **dentro de esa carpeta**.

## 3. Instalación

```bash
cd ExamenFinal/approx-laravel_v1.0/Approx

composer install

cp .env.example .env
php artisan key:generate

# Base de datos SQLite portable (no requiere servidor MySQL externo)
touch database/database.sqlite
```

## 4. Migraciones y datos de ejemplo

```bash
php artisan migrate:fresh --seed
```

Esto crea las tablas `roles` y `users` (con `role_id`), siembra los roles base (`admin`, `editor`, `viewer`) vía `RoleSeeder` y crea un usuario de demostración:

- **Email:** `demo@user.com`
- **Password:** `password`
- **Rol:** `admin`

## 5. Compilar assets del front-end

```bash
bun install && bun run build
# alternativa sin bun:
# npm install && npm run build
```

Para desarrollo interactivo (hot reload):

```bash
bun run dev
```

## 6. Levantar el servidor

```bash
php artisan serve
```

Abrir `http://127.0.0.1:8000`, iniciar sesión con `demo@user.com` / `password` y navegar a **Users** en el menú lateral (o `http://127.0.0.1:8000/users`).

## 7. Ejecutar la suite de pruebas

> [!WARNING]
> `phpunit.xml` no sobrescribe `DB_CONNECTION`/`DB_DATABASE` para el entorno de test, por lo que las pruebas usan el mismo `database/database.sqlite` que la app. Al usar `RefreshDatabase`, cada ejecución de tests **reinicia** esa base de datos (se pierden los datos de demo). Vuelve a ejecutar `php artisan migrate:fresh --seed` después de correr los tests si quieres continuar la demo manual.

```bash
php artisan test --filter=UserCrudTest
php artisan test --filter=UserPolicyTest
```

O toda la suite:

```bash
php artisan test
```

## 8. Funcionalidad entregada

- CRUD completo de usuarios (`/users`) con listado paginado, búsqueda por nombre/email, alta, edición y borrado.
- Roles (`admin`, `editor`, `viewer`) asociados a cada usuario vía `role_id`.
- Autorización por rol mediante `UserPolicy` (registrada en `AppServiceProvider`):
  - `admin` / `editor`: pueden crear y editar usuarios.
  - Solo `admin` puede borrar usuarios (y no puede borrarse a sí mismo).
  - `viewer`: solo puede consultar el listado.
- Validación de formularios vía `StoreUserRequest` / `UpdateUserRequest`.

## 9. Notas de portabilidad

- No se commitea ningún `.env` real ni credenciales; solo `.env.example` con `DB_CONNECTION=sqlite`.
- El proyecto no depende de ningún servicio externo (MySQL, Redis, etc.) para funcionar en modo de evaluación.
- Ningún archivo fuera de `ExamenFinal/` fue modificado; la plantilla original permanece intacta en `approx-laravel_v1.0/` (raíz del repo).
