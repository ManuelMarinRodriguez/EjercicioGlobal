# Guion del video — Examen Final: CRUD de Usuarios y Roles

> Duración estimada: 6-8 minutos. Grabar con el proyecto ya migrado y sembrado (`php artisan migrate:fresh --seed`) y el servidor corriendo (`php artisan serve`).

## 1. Introducción (30-45 s)

- Presentarse y nombrar el examen: "CRUD de gestión de usuarios y roles sobre la plantilla Approx (Laravel 11)".
- Explicar brevemente el objetivo: añadir un módulo funcional de administración de usuarios con roles y permisos sobre una plantilla de administración existente que solo traía maquetación estática.
- Mostrar la estructura de carpetas: destacar que todo el trabajo vive en `ExamenFinal/approx-laravel_v1.0/Approx/` y que la plantilla original no fue alterada.

## 2. Arquitectura y decisiones técnicas (1-1.5 min)

- Mostrar el modelo de datos: tabla `roles` y columna `role_id` en `users` (migraciones en `database/migrations/`).
- Mostrar `app/Models/Role.php` y la relación `belongsTo(Role)` en `app/Models/User.php`.
- Mostrar `app/Http/Controllers/UserController.php`: las 7 acciones RESTful (`index`, `create`, `store`, `edit`, `update`, `destroy`).
- Mostrar `app/Policies/UserPolicy.php` y su registro en `app/Providers/AppServiceProvider.php` (`Gate::policy`).
- Mostrar `routes/web.php`: explicar por qué `Route::resource('users', ...)` está declarado **antes** de las rutas dinámicas `{first}/{second}` y `{any}` del `RoutingController` (para no ser "tapado" por el catch-all).

## 3. Demo en vivo — Login (30 s)

- Abrir `http://127.0.0.1:8000`.
- Iniciar sesión con `demo@user.com` / `password` (usuario admin sembrado por el seeder).

## 4. Demo en vivo — CRUD de usuarios (2-3 min)

1. Navegar a **Users** desde el menú lateral (`/users`).
2. Mostrar el listado paginado y el buscador por nombre/email.
3. Pulsar **Add User**: crear un usuario nuevo, asignándole el rol `viewer`. Mostrar la validación (intentar enviar el formulario vacío y luego corregirlo).
4. Volver al listado y mostrar el usuario recién creado con su rol.
5. Editar ese usuario: cambiar el nombre y el rol a `editor`. Guardar y mostrar el cambio reflejado en el listado.
6. Eliminar el usuario editado y mostrar el mensaje de confirmación y el listado actualizado.

## 5. Demo en vivo — Roles y permisos (1.5-2 min)

1. Cerrar sesión y volver a entrar con un usuario con rol `viewer` (crear uno rápido con el admin, o usar `php artisan tinker` para asignarlo).
2. Intentar acceder a `/users/create`: mostrar que la aplicación responde con **403 Forbidden** (política `UserPolicy::create`).
3. Intentar borrar un usuario desde el listado: mostrar que también se bloquea.
4. Volver a entrar como `admin` e intentar borrarse a sí mismo: mostrar que la política lo impide (`UserPolicy::delete`).

## 6. Pruebas automatizadas (1 min)

- Mostrar en terminal:
  ```bash
  php artisan test --filter=UserCrudTest
  php artisan test --filter=UserPolicyTest
  ```
- Explicar brevemente qué cubre cada suite: `UserCrudTest` (altas, validación, edición, borrado, acceso de invitados) y `UserPolicyTest` (restricciones por rol).

## 7. Cierre (20-30 s)

- Resumir lo entregado: CRUD completo + roles + permisos + pruebas automatizadas, sin tocar la plantilla original ni depender de servicios externos (SQLite portable).
- Mencionar que `SETUP.md` documenta el proceso completo de instalación en una máquina limpia.
- Agradecer y cerrar.
