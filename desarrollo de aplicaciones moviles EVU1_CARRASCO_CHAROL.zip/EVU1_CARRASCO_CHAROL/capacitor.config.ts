import type { CapacitorConfig } from '@capacitor/cli';

/**
 * Configuración de Capacitor.
 *
 * Autora: Charol Carrasco
 * Asignatura: Desarrollo de Aplicaciones Móviles
 * Evaluación: Unidad 1
 *
 * Capacitor permitirá, en unidades posteriores, empaquetar esta aplicación web
 * como una aplicación nativa para Android o iOS.
 */
const config: CapacitorConfig = {
  // Identificador único de la futura aplicación móvil.
  appId: 'cl.ciisa.evu1.charolcarrasco',

  // Nombre que se mostrará al instalar la aplicación en un dispositivo.
  appName: 'Gestor de tareas',

  // Carpeta que Angular genera al compilar la aplicación para producción.
  webDir: 'www'
};

export default config;
