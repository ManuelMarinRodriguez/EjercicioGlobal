# Recursos estáticos

Esta carpeta está reservada para recursos estáticos de la aplicación, como imágenes, iconos, tipografías o archivos de apoyo.

En esta primera versión no se requieren recursos gráficos externos: la interfaz utiliza los iconos integrados de **Ionicons**, incluidos por Ionic.
