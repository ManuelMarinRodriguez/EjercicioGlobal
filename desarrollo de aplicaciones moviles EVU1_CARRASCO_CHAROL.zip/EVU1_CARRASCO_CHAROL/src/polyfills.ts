/**
 * Polyfills requeridos por Angular e Ionic.
 * Zone.js se carga desde la configuración de Angular.
 */
