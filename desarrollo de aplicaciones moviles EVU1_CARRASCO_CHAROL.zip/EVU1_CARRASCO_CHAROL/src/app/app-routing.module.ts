import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

/**
 * Definición central de las rutas de navegación.
 *
 * Autora: Charol Carrasco
 * Asignatura: Desarrollo de Aplicaciones Móviles
 * Evaluación: Unidad 1
 *
 * Cada ruta carga su módulo de forma diferida (lazy loading), reduciendo
 * el contenido inicial que debe cargar la aplicación.
 */
const routes: Routes = [
  {
    // Muestra el listado principal de tareas.
    path: 'tasks',
    loadChildren: () =>
      import('./pages/task-list/task-list.module').then(
        (module) => module.TaskListPageModule
      )
  },
  {
    // Agrupa las rutas para crear una tarea y editar una tarea existente.
    path: 'task',
    loadChildren: () =>
      import('./pages/task-form/task-form.module').then(
        (module) => module.TaskFormPageModule
      )
  },
  {
    // Presenta la información general y guía de uso de la aplicación.
    path: 'about',
    loadChildren: () =>
      import('./pages/about/about.module').then((module) => module.AboutPageModule)
  },
  {
    // Al abrir la aplicación, redirige directamente a la lista de tareas.
    path: '',
    pathMatch: 'full',
    redirectTo: 'tasks'
  }
];

/**
 * Módulo encargado de registrar las rutas para toda la aplicación.
 * PreloadAllModules prepara los módulos secundarios después de la carga inicial.
 */
@NgModule({
  imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
