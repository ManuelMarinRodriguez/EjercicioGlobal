import { Injectable } from '@angular/core';

import { Task, TaskDraft } from '../models/task.model';

/**
 * Servicio central de gestión de tareas.
 *
 * Autora: Charol Carrasco
 * Asignatura: Desarrollo de Aplicaciones Móviles
 * Evaluación: Unidad 1
 *
 * Implementa las operaciones CRUD (crear, leer, actualizar y eliminar) y
 * conserva las tareas en memoria durante la ejecución de la aplicación.
 * En unidades posteriores puede adaptarse para usar almacenamiento local o una API.
 */
@Injectable({
  providedIn: 'root'
})
export class TaskService {
  /**
   * Colección privada con las tareas iniciales de demostración.
   * Los datos se restauran al recargar la aplicación porque aún no hay persistencia.
   */
  private tasks: Task[] = [
    {
      id: 1,
      title: 'Revisar la evaluación de Ionic',
      description: 'Leer las instrucciones y organizar los requerimientos del proyecto.',
      completed: true,
      createdAt: '2026-10-20T09:00:00.000Z'
    },
    {
      id: 2,
      title: 'Diseñar la interfaz de tareas',
      description: 'Definir la lista, el formulario y las acciones principales.',
      completed: false,
      createdAt: '2026-10-21T10:30:00.000Z'
    },
    {
      id: 3,
      title: 'Documentar el proyecto',
      description: 'Preparar el paso a paso de instalación para Windows.',
      completed: false,
      createdAt: '2026-10-22T15:15:00.000Z'
    }
  ];

  /**
   * Obtiene una copia ordenada de todas las tareas.
   * Las tareas pendientes se muestran antes que las completadas.
   *
   * @returns Lista de tareas sin exponer directamente el arreglo interno.
   */
  public getTasks(): Task[] {
    return [...this.tasks].sort(
      (first, second) => Number(first.completed) - Number(second.completed)
    );
  }

  /**
   * Busca una tarea por su identificador único.
   *
   * @param id Identificador numérico de la tarea.
   * @returns Una copia de la tarea encontrada o undefined si no existe.
   */
  public getTaskById(id: number): Task | undefined {
    const task = this.tasks.find((currentTask) => currentTask.id === id);
    return task ? { ...task } : undefined;
  }

  /**
   * Crea una tarea nueva a partir de los datos ingresados en el formulario.
   * Se elimina el espacio sobrante al inicio y al final del título y descripción.
   *
   * @param draft Datos básicos: título y descripción.
   * @returns La tarea creada, incluyendo su identificador y fecha de creación.
   */
  public createTask(draft: TaskDraft): Task {
    const task: Task = {
      id: Date.now(),
      title: draft.title.trim(),
      description: draft.description.trim(),
      completed: false,
      createdAt: new Date().toISOString()
    };

    this.tasks = [task, ...this.tasks];
    return task;
  }

  /**
   * Actualiza el título y la descripción de una tarea existente.
   *
   * @param id Identificador de la tarea a modificar.
   * @param draft Nuevos datos ingresados desde el formulario.
   * @returns true si la tarea fue encontrada y actualizada; false si no existe.
   */
  public updateTask(id: number, draft: TaskDraft): boolean {
    const taskIndex = this.tasks.findIndex((task) => task.id === id);

    if (taskIndex === -1) {
      return false;
    }

    this.tasks[taskIndex] = {
      ...this.tasks[taskIndex],
      title: draft.title.trim(),
      description: draft.description.trim()
    };

    return true;
  }

  /**
   * Alterna el estado de una tarea entre pendiente y completada.
   *
   * @param id Identificador de la tarea cuyo estado se desea cambiar.
   */
  public toggleCompleted(id: number): void {
    this.tasks = this.tasks.map((task) =>
      task.id === id ? { ...task, completed: !task.completed } : task
    );
  }

  /**
   * Elimina definitivamente una tarea de la lista.
   *
   * @param id Identificador de la tarea que se debe eliminar.
   */
  public deleteTask(id: number): void {
    this.tasks = this.tasks.filter((task) => task.id !== id);
  }

  /**
   * Cuenta cuántas tareas aún están pendientes.
   *
   * @returns Cantidad de tareas que no han sido marcadas como completadas.
   */
  public getPendingCount(): number {
    return this.tasks.filter((task) => !task.completed).length;
  }
}
