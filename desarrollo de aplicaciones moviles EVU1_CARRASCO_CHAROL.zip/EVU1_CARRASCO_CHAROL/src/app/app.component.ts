import { Component } from '@angular/core';

/**
 * Componente raíz de la aplicación.
 *
 * Autora: Charol Carrasco
 * Asignatura: Desarrollo de Aplicaciones Móviles
 * Evaluación: Unidad 1
 *
 * Su plantilla contiene ion-app e ion-router-outlet, elementos que permiten
 * a Ionic cargar y cambiar las pantallas registradas en el módulo de rutas.
 */
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  /** Nombre general de la aplicación, disponible para futuras vistas. */
  public readonly appTitle = 'Gestor de tareas';
}
