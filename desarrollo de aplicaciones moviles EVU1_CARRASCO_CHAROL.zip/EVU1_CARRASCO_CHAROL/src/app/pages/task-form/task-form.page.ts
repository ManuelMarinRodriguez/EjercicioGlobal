import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

import { TaskDraft } from '../../models/task.model';
import { TaskService } from '../../services/task.service';

/**
 * Página utilizada para crear una nueva tarea o editar una existente.
 *
 * Autora: Charol Carrasco
 * Asignatura: Desarrollo de Aplicaciones Móviles
 * Evaluación: Unidad 1
 *
 * El modo de funcionamiento depende de la ruta:
 * - /task/new crea una tarea.
 * - /task/edit/:id recupera y modifica una tarea existente.
 */
@Component({
  selector: 'app-task-form',
  templateUrl: './task-form.page.html',
  styleUrls: ['./task-form.page.scss']
})
export class TaskFormPage implements OnInit {
  /** Valor enlazado al campo de título del formulario. */
  public title = '';

  /** Valor enlazado al campo de descripción del formulario. */
  public description = '';

  /** Indica si el formulario está creando o modificando una tarea. */
  public isEditing = false;

  /** Título que se muestra en el encabezado de acuerdo con el modo actual. */
  public pageTitle = 'Nueva tarea';

  /** Identificador de la tarea editada; es null durante la creación. */
  private taskId: number | null = null;

  /**
   * @param activatedRoute Permite leer el identificador presente en la URL.
   * @param alertController Muestra mensajes de validación y errores.
   * @param router Realiza la navegación al guardar, cancelar o encontrar un error.
   * @param taskService Proporciona las operaciones de creación y actualización.
   */
  public constructor(
    private readonly activatedRoute: ActivatedRoute,
    private readonly alertController: AlertController,
    private readonly router: Router,
    private readonly taskService: TaskService
  ) {}

  /**
   * Se ejecuta una vez al iniciar el componente.
   * Comprueba si existe un id en la ruta y, de existir, carga la tarea
   * correspondiente para activar el modo de edición.
   */
  public ngOnInit(): void {
    const idParameter = this.activatedRoute.snapshot.paramMap.get('id');

    if (idParameter === null) {
      return;
    }

    const id = Number(idParameter);
    const task = this.taskService.getTaskById(id);

    if (!task) {
      void this.showTaskNotFound();
      return;
    }

    this.taskId = id;
    this.isEditing = true;
    this.pageTitle = 'Editar tarea';
    this.title = task.title;
    this.description = task.description;
  }

  /**
   * Valida el formulario y guarda la tarea.
   * Crea una tarea si está en modo creación; de lo contrario, actualiza
   * la tarea identificada por taskId. Después vuelve al listado.
   */
  public async saveTask(): Promise<void> {
    const draft: TaskDraft = {
      title: this.title,
      description: this.description
    };

    if (!draft.title.trim()) {
      const alert = await this.alertController.create({
        header: 'Título requerido',
        message: 'Escribe un título para poder guardar la tarea.',
        buttons: ['Entendido']
      });

      await alert.present();
      return;
    }

    if (this.isEditing && this.taskId !== null) {
      this.taskService.updateTask(this.taskId, draft);
    } else {
      this.taskService.createTask(draft);
    }

    await this.router.navigateByUrl('/tasks');
  }

  /**
   * Descarta los cambios no guardados y vuelve a la lista de tareas.
   */
  public cancel(): void {
    void this.router.navigateByUrl('/tasks');
  }

  /**
   * Informa que no fue posible recuperar una tarea para editarla y ofrece
   * volver al listado. Puede ocurrir si la tarea fue eliminada.
   */
  private async showTaskNotFound(): Promise<void> {
    const alert = await this.alertController.create({
      header: 'Tarea no encontrada',
      message: 'La tarea solicitada no existe o fue eliminada.',
      buttons: [
        {
          text: 'Volver',
          handler: () => {
            void this.router.navigateByUrl('/tasks');
          }
        }
      ]
    });

    await alert.present();
  }
}
