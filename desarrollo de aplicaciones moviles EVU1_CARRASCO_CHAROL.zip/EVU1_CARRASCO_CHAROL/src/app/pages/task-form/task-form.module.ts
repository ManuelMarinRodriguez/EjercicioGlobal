import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';

import { TaskFormPage } from './task-form.page';

/**
 * Módulo del formulario de tareas.
 *
 * Autora: Charol Carrasco
 * Asignatura: Desarrollo de Aplicaciones Móviles
 * Evaluación: Unidad 1
 *
 * Registra las rutas para crear y editar tareas e incorpora FormsModule
 * para permitir el enlace bidireccional [(ngModel)] de los campos.
 */
@NgModule({
  imports: [
    // Directivas estructurales de Angular, por ejemplo *ngIf.
    CommonModule,

    // Permite utilizar ngForm y [(ngModel)] dentro del formulario.
    FormsModule,

    // Componentes móviles de Ionic, como ion-input, ion-textarea e ion-button.
    IonicModule,

    // Rutas hijas: /task/new crea y /task/edit/:id modifica una tarea.
    RouterModule.forChild([
      {
        path: 'new',
        component: TaskFormPage
      },
      {
        path: 'edit/:id',
        component: TaskFormPage
      }
    ])
  ],
  declarations: [TaskFormPage]
})
export class TaskFormPageModule {}
