import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';

import { TaskListPage } from './task-list.page';

/**
 * Módulo de la pantalla de listado de tareas.
 *
 * Autora: Charol Carrasco
 * Asignatura: Desarrollo de Aplicaciones Móviles
 * Evaluación: Unidad 1
 *
 * Declara TaskListPage e indica que esta página será accesible al navegar
 * a la ruta /tasks.
 */
@NgModule({
  imports: [
    // Directivas de Angular utilizadas en la plantilla, como *ngFor y *ngIf.
    CommonModule,

    // Componentes visuales de Ionic: listas, botones, encabezados, etc.
    IonicModule,

    // Ruta hija que renderiza TaskListPage al entrar a /tasks.
    RouterModule.forChild([
      {
        path: '',
        component: TaskListPage
      }
    ])
  ],
  declarations: [TaskListPage]
})
export class TaskListPageModule {}
