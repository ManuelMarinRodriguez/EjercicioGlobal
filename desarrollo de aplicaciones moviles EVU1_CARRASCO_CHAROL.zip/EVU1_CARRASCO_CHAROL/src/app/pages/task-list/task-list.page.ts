import { Component } from '@angular/core';
import { AlertController, ViewWillEnter } from '@ionic/angular';

import { Task } from '../../models/task.model';
import { TaskService } from '../../services/task.service';

/**
 * Página principal que presenta el listado de tareas.
 *
 * Autora: Charol Carrasco
 * Asignatura: Desarrollo de Aplicaciones Móviles
 * Evaluación: Unidad 1
 *
 * Desde esta pantalla la persona usuaria puede revisar, completar, editar
 * o solicitar la eliminación de una tarea.
 */
@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.page.html',
  styleUrls: ['./task-list.page.scss']
})
export class TaskListPage implements ViewWillEnter {
  /** Colección de tareas que se muestra en la interfaz. */
  public tasks: Task[] = [];

  /** Cantidad de tareas que aún no han sido completadas. */
  public pendingCount = 0;

  /**
   * @param taskService Servicio que proporciona las operaciones de tareas.
   * @param alertController Servicio Ionic utilizado para mostrar confirmaciones.
   */
  public constructor(
    private readonly taskService: TaskService,
    private readonly alertController: AlertController
  ) {}

  /**
   * Se ejecuta cada vez que la página está próxima a mostrarse.
   * Actualiza la lista para reflejar cambios realizados en otras pantallas.
   */
  public ionViewWillEnter(): void {
    this.loadTasks();
  }

  /**
   * Cambia el estado de la tarea seleccionada entre pendiente y completada.
   *
   * @param task Tarea que se marcó o desmarcó mediante el checkbox.
   */
  public toggleCompleted(task: Task): void {
    this.taskService.toggleCompleted(task.id);
    this.loadTasks();
  }

  /**
   * Muestra una alerta para evitar la eliminación accidental de una tarea.
   * Si la persona confirma, elimina la tarea y actualiza el listado.
   *
   * @param task Tarea que se desea eliminar.
   */
  public async confirmDelete(task: Task): Promise<void> {
    const alert = await this.alertController.create({
      header: '¿Eliminar tarea?',
      message: `La tarea <strong>${task.title}</strong> se eliminará permanentemente.`,
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel'
        },
        {
          text: 'Eliminar',
          role: 'destructive',
          handler: () => {
            this.taskService.deleteTask(task.id);
            this.loadTasks();
          }
        }
      ]
    });

    await alert.present();
  }

  /**
   * Entrega un identificador único a Angular para optimizar el renderizado
   * de la lista cuando cambia una tarea.
   *
   * @param _ Índice del elemento dentro de la lista, no utilizado.
   * @param task Tarea que se está renderizando.
   * @returns Identificador único de la tarea.
   */
  public trackByTaskId(_: number, task: Task): number {
    return task.id;
  }

  /**
   * Obtiene las tareas ordenadas y recalcula el contador de pendientes.
   * Es un método privado porque solo se utiliza internamente en esta página.
   */
  private loadTasks(): void {
    this.tasks = this.taskService.getTasks();
    this.pendingCount = this.taskService.getPendingCount();
  }
}
