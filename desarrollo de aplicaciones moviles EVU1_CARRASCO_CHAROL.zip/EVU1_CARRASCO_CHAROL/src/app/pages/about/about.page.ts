import { Component } from '@angular/core';

/**
 * Página informativa de la aplicación.
 *
 * Autora: Charol Carrasco
 * Asignatura: Desarrollo de Aplicaciones Móviles
 * Evaluación: Unidad 1
 *
 * Presenta el objetivo del proyecto, la guía básica de uso y las tecnologías
 * aplicadas en el desarrollo de la lista de tareas.
 */
@Component({
  selector: 'app-about',
  templateUrl: './about.page.html',
  styleUrls: ['./about.page.scss']
})
export class AboutPage {
  /** Tecnologías que se recorren en la plantilla para mostrar chips informativos. */
  public readonly technologies = ['Ionic', 'Angular', 'TypeScript', 'HTML', 'SCSS'];
}
