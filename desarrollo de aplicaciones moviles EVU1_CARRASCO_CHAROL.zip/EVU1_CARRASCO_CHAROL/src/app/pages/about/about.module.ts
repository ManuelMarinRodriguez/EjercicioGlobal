import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';

import { AboutPage } from './about.page';

/**
 * Módulo de la pantalla "Acerca de".
 *
 * Autora: Charol Carrasco
 * Asignatura: Desarrollo de Aplicaciones Móviles
 * Evaluación: Unidad 1
 *
 * Declara la pantalla informativa y la asocia a la ruta /about.
 */
@NgModule({
  imports: [
    // Directivas Angular necesarias en la plantilla, como *ngFor.
    CommonModule,

    // Componentes visuales Ionic: tarjetas, chips, listas e iconos.
    IonicModule,

    // Ruta hija que muestra AboutPage al navegar a /about.
    RouterModule.forChild([
      {
        path: '',
        component: AboutPage
      }
    ])
  ],
  declarations: [AboutPage]
})
export class AboutPageModule {}
