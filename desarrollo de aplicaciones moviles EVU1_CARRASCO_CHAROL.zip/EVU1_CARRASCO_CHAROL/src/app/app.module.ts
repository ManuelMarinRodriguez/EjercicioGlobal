import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

/**
 * Módulo principal de la aplicación.
 *
 * Autora: Charol Carrasco
 * Asignatura: Desarrollo de Aplicaciones Móviles
 * Evaluación: Unidad 1
 *
 * Declara el componente raíz e importa las configuraciones necesarias para
 * ejecutar Angular, Ionic y la navegación de la aplicación.
 */
@NgModule({
  // Componentes disponibles desde el módulo principal.
  declarations: [AppComponent],

  // Módulos requeridos para el navegador, Ionic y las rutas.
  imports: [BrowserModule, IonicModule.forRoot(), AppRoutingModule],

  // Ionic gestiona la reutilización de pantallas para una navegación móvil fluida.
  providers: [{ provide: RouteReuseStrategy, useClass: IonicRouteStrategy }],

  // Componente que Angular debe iniciar al cargar la aplicación.
  bootstrap: [AppComponent]
})
export class AppModule {}
