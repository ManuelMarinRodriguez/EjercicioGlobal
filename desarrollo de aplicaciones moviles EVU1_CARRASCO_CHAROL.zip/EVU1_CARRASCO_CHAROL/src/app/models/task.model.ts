/**
 * Modelo de datos de una tarea.
 *
 * Autora: Charol Carrasco
 * Asignatura: Desarrollo de Aplicaciones Móviles
 * Evaluación: Unidad 1
 *
 * Define los campos que debe poseer cada tarea administrada por la aplicación.
 */
export interface Task {
  /** Identificador único utilizado para editar, completar o eliminar la tarea. */
  id: number;

  /** Nombre breve y obligatorio de la tarea. */
  title: string;

  /** Información complementaria u opcional sobre la tarea. */
  description: string;

  /** Indica si la tarea fue completada por la persona usuaria. */
  completed: boolean;

  /** Fecha y hora de creación en formato ISO. */
  createdAt: string;
}

/**
 * Datos que se solicitan desde el formulario para crear o actualizar una tarea.
 * No incluye datos administrados automáticamente, como id, estado o fecha.
 */
export type TaskDraft = Pick<Task, 'title' | 'description'>;
