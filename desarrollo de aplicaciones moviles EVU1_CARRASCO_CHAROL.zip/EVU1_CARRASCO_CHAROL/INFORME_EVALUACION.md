# Desarrollo de Aplicaciones Móviles
## Evaluación Sumativa — Unidad 1
### Aplicación móvil de lista de tareas con Ionic

| Dato | Información |
|---|---|
| Institución | CIISA |
| Asignatura | Desarrollo de Aplicaciones Móviles |
| Evaluación | Unidad 1 |
| Proyecto | Gestor de tareas (To-Do List) |
| Framework seleccionado | Ionic con Angular |
| Autora | Charol Carrasco |
| Docente | Completar con el nombre del profesor o profesora |
| Fecha | Completar al momento de la entrega |

> **Indicaciones de formato para la versión Word o PDF:** Arial 12, interlineado 1,15, texto justificado, páginas numeradas y portada con el logo institucional de CIISA.

---

## Índice

1. Introducción  
2. Objetivo del proyecto  
3. Tecnologías utilizadas  
4. Preparación del entorno  
5. Estructura del proyecto  
6. Fundamentos de Ionic y Angular  
7. Patrones de diseño aplicados  
8. Diseño de interfaz y usabilidad  
9. Implementación de funcionalidades  
10. Evidencias de funcionamiento  
11. Conclusiones  
12. Anexos  

---

## 1. Introducción

El presente informe documenta el desarrollo de una aplicación móvil básica de gestión de tareas pendientes, creada para la Evaluación Sumativa de la Unidad 1 de la asignatura Desarrollo de Aplicaciones Móviles.

La solución se desarrolló utilizando **Ionic con Angular**, aprovechando componentes visuales orientados a dispositivos móviles y una arquitectura basada en componentes, servicios y rutas. La aplicación permite registrar, visualizar, editar, completar y eliminar tareas.

El proyecto fue preparado para que pueda instalarse y ejecutarse posteriormente en un computador con sistema operativo Windows. El proceso completo de instalación y configuración se encuentra en el archivo `INSTRUCCIONES_WINDOWS.md`.

---

## 2. Objetivo del proyecto

Crear una aplicación móvil tipo **To-Do List** que facilite la organización de tareas pendientes mediante una interfaz clara, intuitiva y adaptable a dispositivos móviles.

### Objetivos específicos

- Mostrar una lista de tareas con su título, descripción, fecha de creación y estado.
- Crear nuevas tareas desde un formulario.
- Editar tareas previamente registradas.
- Eliminar tareas mediante una confirmación para prevenir errores.
- Marcar tareas como completadas o pendientes.
- Aplicar componentes Ionic comunes y principios básicos de diseño de interfaces móviles.
- Documentar la arquitectura, los componentes y el proceso de instalación del proyecto.

---

## 3. Tecnologías utilizadas

| Tecnología | Uso dentro del proyecto |
|---|---|
| Node.js | Entorno de ejecución requerido por las herramientas de desarrollo. |
| npm | Instalación y administración de las dependencias. |
| Ionic CLI | Herramienta para servir, compilar y administrar el proyecto Ionic. |
| Ionic | Framework de componentes visuales móviles. |
| Angular | Framework frontend utilizado para componentes, rutas, formularios y servicios. |
| TypeScript | Lenguaje usado para la lógica de la aplicación. |
| HTML | Definición de las plantillas de interfaz. |
| SCSS | Estilos visuales, diseño responsivo y tema de colores. |
| Ionicons | Iconos incorporados en los componentes de Ionic. |
| Capacitor | Configuración inicial para una futura conversión a aplicación nativa. |

---

## 4. Preparación del entorno

Para utilizar el proyecto en Windows se debe:

1. Instalar Node.js en su versión LTS.
2. Verificar Node.js y npm con los comandos:

   ```cmd
   node --version
   npm --version
   ```

3. Instalar Ionic CLI globalmente:

   ```cmd
   npm install -g @ionic/cli
   ```

4. Descomprimir la carpeta del proyecto.
5. Abrir una terminal dentro de `EVU1_CARRASCO_CHAROL`.
6. Instalar dependencias:

   ```cmd
   npm install
   ```

7. Ejecutar la aplicación:

   ```cmd
   ionic serve
   ```

8. Abrir `http://localhost:8100` si el navegador no se abre de forma automática.

El detalle completo, incluyendo configuración de Visual Studio Code y solución de pasos comunes, está documentado en `INSTRUCCIONES_WINDOWS.md`.

---

## 5. Estructura del proyecto

```text
EVU1_CARRASCO_CHAROL/
├── package.json                    # Dependencias y comandos npm
├── angular.json                    # Configuración de compilación Angular
├── ionic.config.json               # Configuración de Ionic CLI
├── capacitor.config.ts             # Configuración para futuras plataformas nativas
├── INSTRUCCIONES_WINDOWS.md        # Guía de instalación en Windows
├── INFORME_EVALUACION.md           # Contenido base del informe académico
└── src/
    ├── app/
    │   ├── app.module.ts           # Módulo raíz
    │   ├── app-routing.module.ts   # Navegación entre pantallas
    │   ├── models/
    │   │   └── task.model.ts       # Estructura tipada de una tarea
    │   ├── services/
    │   │   └── task.service.ts     # Lógica CRUD de tareas
    │   └── pages/
    │       ├── task-list/          # Pantalla de listado
    │       ├── task-form/          # Pantalla para crear y editar
    │       └── about/              # Pantalla informativa
    ├── assets/                     # Recursos estáticos
    ├── theme/variables.scss        # Paleta de colores Ionic
    ├── global.scss                 # Estilos globales
    ├── index.html                  # Documento HTML base
    └── main.ts                     # Arranque de Angular
```

La estructura separa la interfaz, la lógica de datos y el modelo de una tarea. Esta organización facilita el mantenimiento y permite incorporar almacenamiento local o APIs externas en unidades posteriores.

---

## 6. Fundamentos de Ionic y Angular

### 6.1 Ionic

Ionic es un framework que permite desarrollar aplicaciones móviles multiplataforma utilizando tecnologías web. Entrega componentes preparados para comportarse y visualizarse de forma coherente en entornos móviles.

En este proyecto se utilizan, entre otros, los siguientes componentes:

- `ion-app` e `ion-router-outlet`: contenedor general y área de navegación.
- `ion-header`, `ion-toolbar`, `ion-title`: encabezados.
- `ion-content`: contenido desplazable de las pantallas.
- `ion-list`, `ion-item`: lista estructurada de tareas.
- `ion-input`, `ion-textarea`: formulario de ingreso de datos.
- `ion-button`: acciones de guardar, cancelar, editar y eliminar.
- `ion-checkbox`: cambio de estado de la tarea.
- `ion-fab`: acceso visible y persistente a la creación de tareas.
- `ion-alert`: confirmación para eliminar y validaciones.
- `ion-card`, `ion-chip`, `ion-badge` e `ion-icon`: retroalimentación y organización visual.

### 6.2 Angular

Angular se usa como framework frontend y organiza la aplicación en:

- **Componentes:** representan pantallas y controlan su interfaz.
- **Módulos:** reúnen componentes y dependencias relacionadas.
- **Servicios:** encapsulan lógica reutilizable y acceso a datos.
- **Rutas:** vinculan una dirección URL con una pantalla.
- **Data binding:** sincroniza datos de TypeScript con las vistas HTML.
- **Directivas:** permiten repetir o mostrar contenido condicionado; se usan `*ngFor` y `*ngIf`.

Las rutas principales implementadas son:

| Ruta | Pantalla |
|---|---|
| `/tasks` | Lista principal de tareas. |
| `/task/new` | Formulario para crear una tarea. |
| `/task/edit/:id` | Formulario para editar una tarea existente. |
| `/about` | Información de la aplicación y guía de uso. |

---

## 7. Patrones de diseño aplicados

### Arquitectura basada en componentes

La solución se divide en páginas con responsabilidades concretas:

- `TaskListPage`: muestra las tareas, cambia el estado y elimina.
- `TaskFormPage`: crea y edita tareas.
- `AboutPage`: comunica el objetivo, tecnologías y guía de uso.

Esto evita concentrar toda la lógica y la interfaz en un único archivo.

### Patrón Servicio

`TaskService` encapsula el CRUD de tareas. El resto de la aplicación se comunica con el servicio mediante métodos específicos:

- `getTasks()`
- `getTaskById()`
- `createTask()`
- `updateTask()`
- `toggleCompleted()`
- `deleteTask()`

Esta decisión evita duplicar código y simplifica una futura migración a `localStorage` o una API.

### Inyección de dependencias

Angular proporciona a cada componente las dependencias necesarias a través de su constructor. Por ejemplo, las páginas reciben `TaskService`, `Router`, `ActivatedRoute` o `AlertController`, en vez de crearlos manualmente.

### Modelo tipado

La interfaz `Task` fija la estructura de cada tarea:

```ts
export interface Task {
  id: number;
  title: string;
  description: string;
  completed: boolean;
  createdAt: string;
}
```

Con ello se mantiene consistencia en toda la aplicación y se aprovecha la validación de tipos de TypeScript.

---

## 8. Diseño de interfaz y usabilidad

La aplicación considera los principios fundamentales de diseño UI solicitados en la rúbrica:

| Principio | Aplicación en la interfaz |
|---|---|
| Jerarquía visual | Encabezado, resumen, contador, título y descripción se ordenan según importancia. |
| Balance | Uso equilibrado de tarjetas, espaciados y botones de acción. |
| Contraste | Paleta azul sobre superficies claras y colores diferenciados para los estados pendiente/completada. |
| Ritmo | Listado uniforme, iconografía repetible y márgenes consistentes. |
| Proporción | Tamaños de fuente, controles y tarjetas adecuados para interacción móvil. |
| Intuitividad | Botón flotante para crear, controles de edición visibles y navegación de retorno. |
| Prevención de errores | Validación de título obligatorio y confirmación antes de eliminar. |
| Retroalimentación | Contador de tareas, etiquetas de estado y pantalla vacía explicativa. |
| Accesibilidad | Etiquetas `aria-label` en acciones iconográficas y textos de apoyo. |

---

## 9. Implementación de funcionalidades

### 9.1 Visualizar tareas

La página principal utiliza `ion-list` e `ion-item`. Cada elemento incluye:

- Casilla para marcar su estado.
- Título.
- Descripción.
- Fecha de creación.
- Indicador “Pendiente” o “Completada”.
- Botón de edición.
- Botón de eliminación.

### 9.2 Agregar tareas

Al seleccionar el botón flotante se navega a `/task/new`. El formulario solicita:

- **Título:** obligatorio.
- **Descripción:** opcional.

Al guardar, se valida el título, se crea el objeto y se navega de regreso al listado.

### 9.3 Editar tareas

Cada tarea posee un botón de edición. La ruta recibe el identificador de la tarea y carga sus datos en el formulario. Al guardar, el servicio actualiza el elemento existente.

### 9.4 Completar tareas

El usuario puede marcar o desmarcar el `ion-checkbox`. El estado se refleja mediante una etiqueta de color y texto tachado en la tarea completada.

### 9.5 Eliminar tareas

El botón de eliminación abre una alerta de confirmación. La tarea solo se elimina si la persona usuaria confirma la acción.

### 9.6 Alcance de persistencia

En esta primera versión los datos se mantienen en memoria mediante `TaskService`. Por esa razón, las tareas de ejemplo se restauran al recargar la aplicación. La persistencia local se propone como evolución del proyecto para las siguientes unidades.

---

## 10. Evidencias de funcionamiento

> Insertar en esta sección las capturas obtenidas **después de instalar y ejecutar el proyecto en el equipo de destino**. Agregar un pie de figura a cada imagen.

### Figura 1. Lista principal de tareas

**[Insertar captura de la página `/tasks` mostrando el resumen, contador y tareas de ejemplo.]**

Descripción: se debe evidenciar la lista de tareas, el estado de cada una y las acciones disponibles.

### Figura 2. Formulario de creación

**[Insertar captura de la página `/task/new`.]**

Descripción: se debe evidenciar el formulario con campos para título y descripción, además de los botones de guardar y cancelar.

### Figura 3. Nueva tarea agregada

**[Insertar captura de la lista luego de crear una tarea.]**

Descripción: se debe mostrar que la nueva tarea aparece en el listado.

### Figura 4. Edición de una tarea

**[Insertar captura de `/task/edit/:id` con información precargada.]**

Descripción: se debe evidenciar que el formulario permite modificar una tarea existente.

### Figura 5. Confirmación de eliminación

**[Insertar captura de la alerta de confirmación.]**

Descripción: se debe mostrar la prevención de eliminación accidental.

### Figura 6. Diseño móvil

**[Insertar captura con el modo de dispositivo activado en Chrome o Edge.]**

Descripción: se debe evidenciar la adaptación de la interfaz a una pantalla móvil.

### Figura 7. Pantalla Acerca de

**[Insertar captura de la página `/about`.]**

Descripción: se deben mostrar las tecnologías utilizadas y la guía de uso.

---

## 11. Conclusiones

La aplicación desarrollada permite resolver el problema planteado mediante una lista de tareas funcional e intuitiva. Se aplicaron los conceptos fundamentales de Ionic y Angular, utilizando componentes móviles, enrutamiento, formularios, servicios e interfaces TypeScript.

La estructura del proyecto favorece la mantenibilidad porque separa las páginas, el modelo y la lógica de las tareas. Además, la interfaz aplica jerarquía visual, contraste, equilibrio y retroalimentación para facilitar la interacción de las personas usuarias.

La solución queda preparada para evolucionar durante las siguientes unidades mediante almacenamiento local, autenticación, consumo de APIs y compilación como aplicación nativa con Capacitor.

---

## 12. Anexos

### Anexo A. Comandos principales

```cmd
npm install
ionic serve
npm run build
```

### Anexo B. Lista de verificación antes de entregar

- [ ] Se instaló el proyecto en un equipo Windows preparado.
- [ ] Se ejecutó `npm install` sin errores.
- [ ] Se comprobó la aplicación con `ionic serve`.
- [ ] Se tomaron las capturas solicitadas.
- [ ] Se completaron los datos de portada y docente.
- [ ] Se aplicó Arial 12, interlineado 1,15 y texto justificado en el documento final.
- [ ] Se exportó el informe como Word o PDF.
- [ ] Se comprimió la carpeta del proyecto como `EVU1_CARRASCO_CHAROL.zip`.
- [ ] Se agregó la coevaluación requerida por la evaluación.
