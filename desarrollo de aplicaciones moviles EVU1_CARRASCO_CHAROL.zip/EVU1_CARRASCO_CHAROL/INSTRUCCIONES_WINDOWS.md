# EVU1_CARRASCO_CHAROL — Gestor de tareas Ionic

**Asignatura:** Desarrollo de Aplicaciones Móviles  
**Evaluación:** Unidad 1 — Aplicación móvil básica con Ionic  
**Autora:** Charol Carrasco  
**Framework seleccionado:** Ionic con Angular  
**Estado de esta entrega:** proyecto preparado, **no instalado ni ejecutado** en este computador.

---

## 1. Propósito del proyecto

La aplicación **Gestor de tareas** permite administrar una lista de tareas pendientes desde una interfaz móvil clara e intuitiva. Cada tarea posee:

- Título obligatorio.
- Descripción opcional.
- Estado de completitud.
- Fecha de creación.

Las funcionalidades implementadas son:

1. Visualizar el listado de tareas.
2. Agregar una tarea mediante formulario.
3. Editar el título y la descripción de una tarea existente.
4. Marcar tareas como completadas o pendientes.
5. Eliminar tareas con confirmación.
6. Consultar una pantalla informativa sobre la aplicación.

> En esta primera unidad las tareas se mantienen en memoria. Por ello, al recargar la aplicación se restablecen las tareas iniciales. En unidades posteriores se puede incorporar almacenamiento local, autenticación y consumo de API.

---

## 2. Requisitos previos en Windows

Antes de instalar el proyecto se requiere:

| Software | Versión recomendada | Uso |
|---|---:|---|
| Windows | 10 u 11, 64 bits | Sistema operativo |
| Node.js | LTS 20 o superior | Ejecutar herramientas y dependencias |
| npm | Se instala junto con Node.js | Gestor de paquetes |
| Ionic CLI | Última versión estable | Crear y servir proyectos Ionic |
| Visual Studio Code | Última versión estable | Editor recomendado |
| Google Chrome o Microsoft Edge | Actualizado | Navegador para pruebas |

---

## 3. Instalación y configuración del entorno en Windows

### Paso 1: instalar Node.js

1. Abrir el sitio oficial: [https://nodejs.org/](https://nodejs.org/).
2. Descargar la versión **LTS** para Windows.
3. Ejecutar el instalador descargado.
4. Mantener las opciones predeterminadas, incluyendo **npm package manager**.
5. Finalizar la instalación.
6. Cerrar y volver a abrir la terminal para que Windows reconozca los comandos.

### Paso 2: comprobar Node.js y npm

Abrir **Símbolo del sistema (CMD)**, PowerShell o la terminal integrada de VS Code y ejecutar:

```cmd
node --version
npm --version
```

Ambos comandos deben mostrar un número de versión. Si no ocurre, reiniciar el equipo o revisar que la instalación de Node.js se haya completado correctamente.

### Paso 3: instalar Ionic CLI globalmente

En la terminal ejecutar:

```cmd
npm install -g @ionic/cli
```

Luego comprobar la instalación:

```cmd
ionic --version
```

### Paso 4: instalar Visual Studio Code (recomendado)

1. Descargarlo desde [https://code.visualstudio.com/](https://code.visualstudio.com/).
2. Ejecutar el instalador.
3. Marcar la opción para agregar `code` al PATH si está disponible.
4. Abrir Visual Studio Code.

Extensiones sugeridas:

- **Angular Language Service**
- **Ionic**
- **ESLint**
- **Prettier - Code formatter**

---

## 4. Instalación del proyecto entregado

> Los siguientes comandos deben ejecutarse en **otro equipo Windows** preparado con los requisitos anteriores. No fueron ejecutados en el equipo donde se creó esta entrega.

### Paso 1: descomprimir el archivo de entrega

1. Descargar el archivo `EVU1_CARRASCO_CHAROL.zip`.
2. Hacer clic derecho sobre el ZIP.
3. Seleccionar **Extraer todo...**.
4. Elegir una ubicación sin restricciones, por ejemplo:

```text
C:\Proyectos\EVU1_CARRASCO_CHAROL
```

Evitar rutas sincronizadas o protegidas, como carpetas de OneDrive, si causan problemas de permisos.

### Paso 2: abrir una terminal en la carpeta del proyecto

En el Explorador de archivos, entrar a la carpeta descomprimida. Luego:

- Clic derecho y seleccionar **Abrir en Terminal**, o
- Abrir VS Code con **Archivo > Abrir carpeta**, elegir la carpeta del proyecto y usar **Terminal > New Terminal**.

La ruta mostrada por la terminal debe terminar en:

```text
EVU1_CARRASCO_CHAROL
```

### Paso 3: instalar las dependencias

Ejecutar:

```cmd
npm install
```

Este comando leerá `package.json` y descargará las dependencias necesarias dentro de la carpeta `node_modules`. Puede tardar algunos minutos según la conexión a Internet.

### Paso 4: iniciar la aplicación

Ejecutar:

```cmd
ionic serve
```

Ionic compilará la aplicación y abrirá el navegador predeterminado. Si no se abre automáticamente, ingresar manualmente a:

```text
http://localhost:8100
```

Para detener el servidor, volver a la terminal y presionar:

```text
Ctrl + C
```

### Paso 5: visualización móvil en el navegador

Para revisar el diseño como dispositivo móvil:

1. Abrir la aplicación en Chrome o Edge.
2. Presionar `F12` para abrir las herramientas de desarrollador.
3. Activar el botón **Toggle device toolbar** o presionar `Ctrl + Shift + M`.
4. Elegir un dispositivo móvil, por ejemplo **iPhone 12 Pro** o **Pixel 7**.
5. Actualizar la página si fuera necesario.

---

## 5. Comandos útiles

| Comando | Descripción |
|---|---|
| `npm install` | Instala las dependencias declaradas en el proyecto. |
| `ionic serve` | Compila e inicia el servidor local en `http://localhost:8100`. |
| `ionic serve --lab` | Muestra previsualización simultánea de estilo iOS y Material Design. |
| `npm run build` | Genera la compilación de producción en la carpeta `www`. |
| `ionic --version` | Muestra la versión de Ionic CLI instalada. |
| `node --version` | Muestra la versión de Node.js instalada. |

---

## 6. Estructura de archivos

```text
EVU1_CARRASCO_CHAROL/
├── .gitignore                         # Archivos y carpetas excluidos de Git
├── angular.json                       # Configuración de Angular
├── capacitor.config.ts                # Preparado para futuras compilaciones nativas
├── ionic.config.json                  # Configuración de Ionic CLI
├── package.json                       # Dependencias y comandos del proyecto
├── tsconfig.json                      # Configuración TypeScript base
├── INSTRUCCIONES_WINDOWS.md           # Esta guía de instalación y documentación
└── src/
    ├── index.html                     # Documento HTML principal
    ├── main.ts                        # Punto de arranque de Angular
    ├── polyfills.ts                   # Compatibilidad para navegadores
    ├── global.scss                    # Estilos globales
    ├── theme/
    │   └── variables.scss             # Paleta visual y variables Ionic
    ├── assets/
    │   └── README.md                  # Ubicación de recursos estáticos
    └── app/
        ├── app.component.ts           # Componente raíz
        ├── app.component.html         # Contenedor raíz y router outlet
        ├── app.module.ts              # Módulo principal
        ├── app-routing.module.ts      # Rutas de navegación
        ├── models/
        │   └── task.model.ts          # Contrato de datos de una tarea
        ├── services/
        │   └── task.service.ts        # Operaciones CRUD en memoria
        └── pages/
            ├── task-list/             # Listado y eliminación de tareas
            ├── task-form/             # Creación y edición de tareas
            └── about/                 # Información y documentación en la app
```

---

## 7. Componentes Ionic utilizados

| Componente | Ubicación | Propósito |
|---|---|---|
| `ion-app` y `ion-router-outlet` | Componente raíz | Contenedor de Ionic y navegación entre páginas. |
| `ion-header`, `ion-toolbar`, `ion-title` | Todas las páginas | Barra superior consistente y jerarquía visual. |
| `ion-content` | Todas las páginas | Área desplazable principal. |
| `ion-list` e `ion-item` | Lista de tareas | Presentar las tareas en una lista ordenada. |
| `ion-input` y `ion-textarea` | Formulario | Capturar título y descripción. |
| `ion-button` | Lista y formulario | Acciones de agregar, guardar, cancelar y eliminar. |
| `ion-fab` | Lista de tareas | Acción primaria persistente para crear tareas. |
| `ion-checkbox` | Lista de tareas | Marcar una tarea como completada. |
| `ion-alert` | Lista y formulario | Confirmar eliminación y mostrar mensajes de validación. |
| `ion-note`, `ion-icon`, `ion-badge` | Varias pantallas | Apoyo visual, retroalimentación y accesibilidad. |

---

## 8. Fundamentos de Ionic y Angular aplicados

### Ionic

Ionic es un framework para crear aplicaciones móviles multiplataforma utilizando tecnologías web: **HTML, CSS y TypeScript/JavaScript**. Proporciona componentes visuales que respetan convenciones de iOS y Android, por ejemplo botones, listas, encabezados, formularios y navegación.

En este proyecto se utiliza Ionic con Angular, por lo que cada pantalla está formada por componentes de Angular que emplean etiquetas Ionic como `ion-header`, `ion-list`, `ion-item` e `ion-button`.

### Angular

Angular es el framework de frontend seleccionado. Organiza la aplicación mediante:

- **Componentes:** unidades de interfaz formadas por una clase TypeScript, una plantilla HTML y estilos SCSS.
- **Módulos:** agrupaciones de componentes y dependencias. `AppModule` es el módulo inicial.
- **Servicios:** clases reutilizables para centralizar lógica y datos. `TaskService` administra el CRUD de tareas.
- **Rutas:** asignan una URL a cada página de la aplicación.
- **Enlace de datos (data binding):** conecta el estado TypeScript con la interfaz. En el formulario se usa `[(ngModel)]`.
- **Directivas:** controlan la representación de la vista. Se utilizan `*ngFor` para repetir tareas y `*ngIf` para mostrar estados vacíos o contenidos condicionales.

### Arquitectura del proyecto

La solución sigue una separación clara de responsabilidades:

- **Presentación:** páginas dentro de `src/app/pages`.
- **Lógica de negocio y estado:** `src/app/services/task.service.ts`.
- **Modelo de dominio:** interfaz `Task` en `src/app/models/task.model.ts`.
- **Navegación:** rutas centralizadas en `app-routing.module.ts`.
- **Tema visual:** variables globales en `src/theme/variables.scss`.

---

## 9. Patrones de diseño aplicados

### 9.1 Arquitectura basada en componentes

Angular divide la interfaz en componentes independientes. Por ejemplo:

- `TaskListPage` muestra, filtra y permite operar sobre las tareas.
- `TaskFormPage` concentra la creación y edición.
- `AboutPage` presenta información de uso.

Esta división mejora la legibilidad, facilita pruebas futuras y evita concentrar toda la aplicación en una sola pantalla.

### 9.2 Patrón Servicio

`TaskService` centraliza el acceso a las tareas y las operaciones **crear, leer, actualizar y eliminar (CRUD)**. Las páginas no manipulan directamente la colección interna; invocan métodos como `getTasks()`, `createTask()`, `updateTask()` y `deleteTask()`.

Beneficios:

- Evita duplicar lógica.
- Mantiene una fuente de datos consistente.
- Facilita reemplazar el almacenamiento en memoria por `localStorage` o una API en futuras unidades.

### 9.3 Inyección de dependencias

Angular entrega `TaskService`, `Router`, `ActivatedRoute` y `AlertController` a los componentes que los necesitan mediante sus constructores. Esto reduce el acoplamiento y permite sustituir dependencias al realizar pruebas.

Ejemplo conceptual:

```ts
constructor(
  private readonly taskService: TaskService,
  private readonly router: Router
) {}
```

### 9.4 Patrón Modelo de datos

La interfaz `Task` define la estructura única de una tarea:

```ts
export interface Task {
  id: number;
  title: string;
  description: string;
  completed: boolean;
  createdAt: string;
}
```

Esto aporta consistencia, autocompletado y validación estática de tipos en TypeScript.

### 9.5 Enrutamiento y navegación

`AppRoutingModule` administra las rutas. La navegación se realiza mediante enlaces declarativos `routerLink` y de forma programática tras guardar o eliminar. Cada página tiene una responsabilidad y URL concreta:

- `/tasks`
- `/task/new`
- `/task/edit/:id`
- `/about`

---

## 10. Decisiones de diseño UI y usabilidad

La interfaz fue pensada para una interacción rápida en pantallas móviles:

- **Jerarquía visual:** título y descripción de cada tarea aparecen ordenados; el encabezado comunica la pantalla activa.
- **Contraste:** se usa una paleta azul como color primario sobre superficies claras, con texto legible.
- **Balance y proporción:** se emplean tarjetas y espaciado consistente para evitar saturación visual.
- **Ritmo visual:** lista de elementos con altura, márgenes e iconos repetibles.
- **Acción principal visible:** el botón flotante “Nueva tarea” permanece accesible.
- **Prevención de errores:** el título se valida antes de guardar y la eliminación requiere confirmación.
- **Retroalimentación:** se indican los estados “Pendiente” y “Completada”; además, se muestra un estado vacío con una acción clara.
- **Accesibilidad:** botones con etiquetas `aria-label`, descripciones de ayuda y controles nativos de Ionic.
- **Navegación predecible:** los botones de retroceso aparecen automáticamente en pantallas secundarias.

---

## 11. Casos de prueba manual

Una vez iniciada la aplicación con `ionic serve`, verificar lo siguiente:

| N.º | Caso | Resultado esperado |
|---:|---|---|
| 1 | Abrir `/tasks` | Se observan tareas de ejemplo, contador y botón flotante. |
| 2 | Pulsar “Nueva tarea” | Se navega al formulario de creación. |
| 3 | Guardar con título vacío | Se muestra una alerta y no se crea una tarea. |
| 4 | Completar título y descripción, luego guardar | La tarea se agrega y se vuelve al listado. |
| 5 | Marcar el checkbox de una tarea | Cambia entre “Pendiente” y “Completada”. |
| 6 | Pulsar “Editar” | Se abre el formulario con los datos actuales. |
| 7 | Cambiar datos y guardar | El listado refleja los cambios. |
| 8 | Pulsar eliminar y cancelar | La tarea permanece. |
| 9 | Pulsar eliminar y confirmar | La tarea desaparece y el contador se actualiza. |
| 10 | Abrir “Acerca de” | Se visualiza la información y la guía de uso. |

---

## 12. Evidencias que se deben incluir en el informe de entrega

Luego de instalar y ejecutar el proyecto en el equipo de destino, tomar y añadir al documento Word o PDF las siguientes capturas:

1. Página inicial con la lista de tareas.
2. Formulario para crear una tarea.
3. Tarea agregada correctamente en la lista.
4. Formulario de edición con datos precargados.
5. Alerta de confirmación de eliminación.
6. Diseño visto en modo móvil desde las herramientas del navegador.
7. Página “Acerca de” con tecnologías y funcionalidades.

El documento académico debe incorporar portada, datos solicitados por la institución, desarrollo, estructura del proyecto, explicación de los componentes, capturas, páginas numeradas y el formato indicado en la evaluación (Arial 12, interlineado 1,15, alineación justificada).

---

## 13. Entrega final sugerida

1. Verificar que el proyecto funcione en el equipo donde se instale.
2. Crear el documento de informe en Word o PDF con las evidencias indicadas.
3. Comprimir la carpeta completa del proyecto, excluyendo opcionalmente `node_modules` para reducir el peso.
4. Nombrar el archivo comprimido exactamente:

```text
EVU1_CARRASCO_CHAROL.zip
```

5. Subir el ZIP, el documento de informe y la coevaluación solicitada a la plataforma institucional.

---

## 14. Posibles mejoras para próximas unidades

- Persistencia de tareas con Ionic Storage o `localStorage`.
- Filtros por tareas pendientes y completadas.
- Fechas límite y prioridades.
- Autenticación de usuarios.
- Sincronización con una API REST.
- Notificaciones y recordatorios.
- Compilación nativa con Capacitor para Android e iOS.
