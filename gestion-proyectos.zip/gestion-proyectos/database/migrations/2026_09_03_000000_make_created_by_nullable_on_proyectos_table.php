<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        $driver = Schema::getConnection()->getDriverName();

        if ($driver === 'sqlite') {
            $this->rebuildSqliteTable(nullable: true);

            return;
        }

        if ($driver === 'pgsql') {
            DB::statement('ALTER TABLE proyectos ALTER COLUMN created_by DROP NOT NULL');

            return;
        }

        DB::statement('ALTER TABLE proyectos MODIFY created_by BIGINT UNSIGNED NULL');
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        $driver = Schema::getConnection()->getDriverName();

        if ($driver === 'sqlite') {
            $this->rebuildSqliteTable(nullable: false);

            return;
        }

        if ($driver === 'pgsql') {
            DB::statement('ALTER TABLE proyectos ALTER COLUMN created_by SET NOT NULL');

            return;
        }

        DB::statement('ALTER TABLE proyectos MODIFY created_by BIGINT UNSIGNED NOT NULL');
    }

    /**
     * SQLite no soporta ALTER COLUMN para cambiar nullability y el paquete
     * doctrine/dbal (requerido por Blueprint::change()) no esta instalado.
     * Se reconstruye la tabla manualmente preservando datos y la FK a users.
     */
    private function rebuildSqliteTable(bool $nullable): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('proyectos_tmp', function (Blueprint $table) use ($nullable) {
            $table->id();
            $table->string('nombre');
            $table->date('fecha_inicio');
            $table->string('estado');
            $table->string('responsable');
            $table->decimal('monto', 12, 2);
            $foreign = $table->foreignId('created_by');

            if ($nullable) {
                $foreign->nullable();
            }

            $foreign->constrained('users')->onDelete('cascade');
            $table->timestamps();
        });

        DB::statement(
            'INSERT INTO proyectos_tmp (id, nombre, fecha_inicio, estado, responsable, monto, created_by, created_at, updated_at) '
            .'SELECT id, nombre, fecha_inicio, estado, responsable, monto, created_by, created_at, updated_at FROM proyectos'
        );

        Schema::drop('proyectos');
        Schema::rename('proyectos_tmp', 'proyectos');

        Schema::enableForeignKeyConstraints();
    }
};
