# Gestion de Proyectos

Sistema web para administrar proyectos (crear, editar, listar y eliminar), hecho con Laravel para la evaluacion del curso.

Autora: Charol Carrasco

## De que se trata

Basicamente es un CRUD de proyectos. Cada proyecto tiene nombre, fecha de inicio, estado, responsable y monto. Los proyectos quedan asociados al usuario que los crea (`created_by`), y hay un login/registro propio para poder entrar al sistema.

Tambien deje una consulta de la UF (ficticia, con un valor fijo) porque era parte de lo que pedian, y una mini API en `/api` que devuelve JSON para probar con Postman.

## Tecnologias usadas

- Laravel 12 (PHP)
- MySQL (o el motor que tengan configurado en el `.env`)
- Blade para las vistas
- Bootstrap para que se viera un poco mas ordenado

## Como levantar el proyecto

1. Clonar el repo y entrar a la carpeta.
2. Instalar dependencias:
   ```bash
   composer install
   ```
3. Copiar el archivo de entorno y generar la key:
   ```bash
   cp .env.example .env
   php artisan key:generate
   ```
4. Configurar la base de datos en el `.env` (usuario, password, nombre de la BD).
5. Correr las migraciones:
   ```bash
   php artisan migrate
   ```
6. Levantar el servidor:
   ```bash
   php artisan serve
   ```
7. Entrar a `http://localhost:8000` y de ahi redirige al listado de proyectos (pide login primero).

## Estructura (lo importante nomas)

- `app/Models` -> Proyecto, Usuario y User (el User es el de Laravel, Usuario lo agregue yo para el tema de relaciones).
- `app/Http/Controllers` -> ProyectoController (vistas web), AuthController (login/registro) y en `Api/` esta el controller de la API.
- `app/Services/UfService.php` -> saca el valor de la UF. Por ahora es un valor fijo porque no alcance a conectarlo a una API real de verdad, pero deje la estructura para que despues se pueda cambiar facil.
- `routes/web.php` y `routes/api.php` -> ahi estan todas las rutas, separadas por secciones con comentarios.

## Notas personales / cosas que me faltaron

- La UF esta hardcodeada, deberia consumir el servicio del Banco Central pero no me dio el tiempo.
- Falta validacion mas fina en algunos campos del formulario (por ejemplo montos negativos en el front, aunque en el back si se valida).
- El middleware `UsuarioAutenticado` es propio, no use el de Laravel porque queria entenderlo bien y practicar.
- Cualquier duda del codigo, dejé comentarios en los archivos principales explicando el por que de las cosas.

## Pendientes (si me alcanza el tiempo despues)

- [ ] Conectar la UF a una API real.
- [ ] Agregar tests automatizados (por ahora probe todo a mano).
- [ ] Mejorar el diseño de las vistas.
