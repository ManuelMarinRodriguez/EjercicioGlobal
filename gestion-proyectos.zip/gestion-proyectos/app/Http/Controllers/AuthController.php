<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

// Todo el flujo de login/registro esta aca, separado del ProyectoController
class AuthController extends Controller
{
    /**
     * Mostrar formulario de registro.
     */
    public function showRegistro()
    {
        return view('auth.registro');
    }

    /**
     * Registrar un nuevo usuario.
     */
    public function registro(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'correo' => 'required|email|max:255|unique:users,correo',
            'clave' => 'required|string|min:6|confirmed',
        ]);

        // la clave nunca se guarda en texto plano, siempre con hash
        $usuario = User::create([
            'nombre' => $request->nombre,
            'correo' => $request->correo,
            'clave' => Hash::make($request->clave),
        ]);

        // apenas se registra lo dejo logueado de una, para no hacerlo
        // pasar por el login otra vez
        Auth::login($usuario);

        return redirect('/proyectos')
            ->with('success', 'Usuario registrado correctamente.');
    }

    /**
     * Mostrar formulario de inicio de sesión.
     */
    public function showLogin()
    {
        return view('auth.login');
    }

    /**
     * Iniciar sesión.
     */
    public function login(Request $request)
    {
        $credenciales = $request->validate([
            'correo' => 'required|email',
            'clave' => 'required|string',
        ]);

        // ojo: Auth::attempt siempre espera la llave 'password',
        // por eso aca abajo se le pasa la clave con ese nombre
        if (Auth::attempt([
            'correo' => $credenciales['correo'],
            'password' => $credenciales['clave'],
        ])) {
            $request->session()->regenerate();

            return redirect('/proyectos')
                ->with('success', 'Inicio de sesión exitoso.');
        }

        return back()
            ->withErrors([
                'correo' => 'El correo o la clave son incorrectos.',
            ])
            ->onlyInput('correo');
    }

    /**
     * Cerrar sesión.
     */
    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/login')
            ->with('success', 'Sesión cerrada correctamente.');
    }
}
