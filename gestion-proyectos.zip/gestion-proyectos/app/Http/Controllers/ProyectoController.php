<?php

namespace App\Http\Controllers;

use App\Models\Proyecto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProyectoController extends Controller
{
    public function index()
    {
        $proyectos = Proyecto::orderBy('id', 'asc')->get();

        return view('proyectos.index', compact('proyectos'));
    }

    public function create()
    {
        return view('proyectos.create');
    }

    public function store(Request $request)
    {
        $datos = $request->validate([
            'nombre' => 'required|string|max:255',
            'fecha_inicio' => 'required|date',
            'estado' => 'required|string|max:100',
            'responsable' => 'required|string|max:255',
            'monto' => 'required|numeric|min:0'
        ]);

        // Guardar automáticamente el ID del usuario autenticado
        $datos['created_by'] = Auth::id();

        Proyecto::create($datos);

        return redirect()->route('proyectos.index')
            ->with('success', 'Proyecto creado correctamente.');
    }

    public function show(string $id)
    {
        $proyecto = Proyecto::findOrFail($id);

        return view('proyectos.show', compact('proyecto'));
    }

    public function edit(string $id)
    {
        $proyecto = Proyecto::findOrFail($id);

        return view('proyectos.edit', compact('proyecto'));
    }

    public function update(Request $request, string $id)
    {
        $datos = $request->validate([
            'nombre' => 'required|string|max:255',
            'fecha_inicio' => 'required|date',
            'estado' => 'required|string|max:100',
            'responsable' => 'required|string|max:255',
            'monto' => 'required|numeric|min:0'
        ]);

        $proyecto = Proyecto::findOrFail($id);

        $proyecto->update($datos);

        return redirect()->route('proyectos.index')
            ->with('success', 'Proyecto actualizado correctamente.');
    }

    public function delete(string $id)
    {
        $proyecto = Proyecto::findOrFail($id);

        return view('proyectos.delete', compact('proyecto'));
    }

    public function destroy(string $id)
    {
        $proyecto = Proyecto::findOrFail($id);

        $proyecto->delete();

        return redirect()->route('proyectos.index')
            ->with('success', 'Proyecto eliminado correctamente.');
    }
}
