<?php

namespace App\Http\Controllers;

use App\Services\UfService;

class UfController extends Controller
{
    public function index(UfService $ufService)
    {
        $uf = $ufService->obtenerUfDelDia();
        return view('uf.index', compact('uf'));
    }
}
