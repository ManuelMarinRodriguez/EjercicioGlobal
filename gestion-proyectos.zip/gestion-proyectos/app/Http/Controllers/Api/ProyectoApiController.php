<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreProyectoRequest;
use App\Http\Requests\UpdateProyectoRequest;
use App\Models\Proyecto;
use Illuminate\Http\JsonResponse;

class ProyectoApiController extends Controller
{
    public function index(): JsonResponse
    {
        $proyectos = Proyecto::orderBy('id', 'asc')->get();

        return response()->json($proyectos, 200);
    }

    public function store(StoreProyectoRequest $request): JsonResponse
    {
        $datos = $request->validated();
        $datos['created_by'] = null;

        try {
            $proyecto = Proyecto::create($datos);
        } catch (\Throwable $e) {
            return response()->json([
                'message' => 'No se pudo crear el proyecto.',
                'error' => config('app.debug') ? $e->getMessage() : null,
            ], 500);
        }

        return response()->json($proyecto, 201);
    }

    public function show(string $id): JsonResponse
    {
        $proyecto = Proyecto::find($id);

        if (! $proyecto) {
            return response()->json(['message' => 'Proyecto no encontrado.'], 404);
        }

        return response()->json($proyecto, 200);
    }

    public function update(UpdateProyectoRequest $request, string $id): JsonResponse
    {
        $proyecto = Proyecto::find($id);

        if (! $proyecto) {
            return response()->json(['message' => 'Proyecto no encontrado.'], 404);
        }

        $proyecto->update($request->validated());

        return response()->json($proyecto, 200);
    }

    public function destroy(string $id): JsonResponse
    {
        $proyecto = Proyecto::find($id);

        if (! $proyecto) {
            return response()->json(['message' => 'Proyecto no encontrado.'], 404);
        }

        $proyecto->delete();

        return response()->json(null, 204);
    }
}
