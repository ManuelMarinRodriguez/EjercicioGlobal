<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class UsuarioAutenticado
{
    /**
     * Maneja la solicitud.
     */
    public function handle(Request $request, Closure $next): Response
    {
        if (!Auth::check()) {
            return redirect('/login')
                ->withErrors([
                    'correo' => 'Debes iniciar sesión para acceder a esta sección.'
                ]);
        }

        return $next($request);
    }
}
