<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class UsuarioAutenticado
{
    /**
     * Chequea que haya un usuario logueado antes de dejarlo pasar.
     * Si no hay sesion activa, lo manda de vuelta al login.
     */
    public function handle(Request $request, Closure $next): Response
    {
        if (!Auth::check()) {
            return redirect('/login')
                ->withErrors([
                    'correo' => 'Debes iniciar sesión para acceder a esta sección.'
                ]);
        }

        return $next($request);
    }
}
