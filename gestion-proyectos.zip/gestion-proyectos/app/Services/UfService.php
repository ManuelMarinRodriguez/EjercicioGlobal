<?php

namespace App\Services;

class UfService
{
    public function obtenerUfDelDia(): float
    {
        return 39250.75;
    }
}
