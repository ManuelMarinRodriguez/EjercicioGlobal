<?php

namespace App\Services;

// Servicio pequeño para no llenar el controller de logica.
// Por ahora el valor esta fijo (hardcodeado) porque no alcance
// a conectarlo con la API real del Banco Central, pero la idea
// es que despues solo haya que cambiar este metodo y listo,
// el resto del sistema no se entera del cambio.
class UfService
{
    public function obtenerUfDelDia(): float
    {
        return 39250.75;
    }
}
