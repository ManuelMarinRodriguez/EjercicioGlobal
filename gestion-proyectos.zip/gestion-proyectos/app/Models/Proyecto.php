<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

// Modelo del proyecto, es el core de todo el sistema
class Proyecto extends Model
{
    // la tabla se llama distinto al nombre del modelo, ojo con eso
    protected $table = 'proyectos';

    // campos que se pueden llenar desde el form (mass assignment)
    protected $fillable = [
        'nombre',
        'fecha_inicio',
        'estado',
        'responsable',
        'monto',
        'created_by' // id del usuario que creo el proyecto
    ];

    protected $casts = [
        'fecha_inicio' => 'date:Y-m-d', // para que se muestre bonita la fecha
        'monto' => 'decimal:2', // asi no salen puros decimales raros
    ];

    // relacion con el usuario que creo el proyecto
    public function usuario()
    {
        return $this->belongsTo(Usuario::class, 'created_by');
    }
}
