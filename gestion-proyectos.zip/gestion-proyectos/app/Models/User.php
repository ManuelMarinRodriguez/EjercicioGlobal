<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $table = 'users';

    protected $fillable = [
        'nombre',
        'correo',
        'clave',
    ];

    protected $hidden = [
        'clave',
        'remember_token',
    ];

    /**
     * Indica a Laravel cuál es el campo utilizado como contraseña.
     */
    public function getAuthPasswordName()
    {
        return 'clave';
    }

    /**
     * Relación: un usuario puede tener muchos proyectos.
     */
    public function proyectos()
    {
        return $this->hasMany(Proyecto::class, 'created_by');
    }

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
        ];
    }
}
