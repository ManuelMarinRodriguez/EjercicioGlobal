<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

// Este es el User "oficial" que usa el sistema de autenticacion de Laravel
class User extends Authenticatable
{
    use HasFactory, Notifiable;

    // uso la misma tabla users que el modelo Usuario, no cree una tabla aparte
    protected $table = 'users';

    protected $fillable = [
        'nombre',
        'correo',
        'clave',
    ];

    protected $hidden = [
        'clave',
        'remember_token',
    ];

    /**
     * En vez de "password" mi tabla usa "clave", asi que hay
     * que decirle a Laravel donde buscar la contraseña.
     */
    public function getAuthPasswordName()
    {
        return 'clave';
    }

    /**
     * Relación: un usuario puede tener muchos proyectos.
     */
    public function proyectos()
    {
        return $this->hasMany(Proyecto::class, 'created_by');
    }

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
        ];
    }
}
