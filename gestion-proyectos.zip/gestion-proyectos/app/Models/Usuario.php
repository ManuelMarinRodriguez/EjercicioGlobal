<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Usuario extends Model
{
    protected $table = 'users';

    protected $fillable = [
        'nombre',
        'correo',
        'clave'
    ];

    protected $hidden = [
        'clave'
    ];

    public function proyectos()
    {
        return $this->hasMany(Proyecto::class, 'created_by');
    }
}
