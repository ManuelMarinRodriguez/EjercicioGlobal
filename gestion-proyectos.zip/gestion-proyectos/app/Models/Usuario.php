<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

// Este modelo lo cree por separado del User de laravel
// porque en algunas partes solo necesitaba los datos basicos
// sin todo el tema de autenticacion (Authenticatable, etc)
class Usuario extends Model
{
    protected $table = 'users';

    protected $fillable = [
        'nombre',
        'correo',
        'clave'
    ];

    // la clave no deberia mostrarse nunca en las respuestas
    protected $hidden = [
        'clave'
    ];

    // un usuario puede tener varios proyectos creados
    public function proyectos()
    {
        return $this->hasMany(Proyecto::class, 'created_by');
    }
}
