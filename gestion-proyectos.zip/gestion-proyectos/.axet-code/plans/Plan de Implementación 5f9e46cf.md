# Plan: Coleccion Postman para API de Proyectos

> [!NOTE]
> Puedes editar este archivo directamente antes de aprobarlo. Al pulsar **Ejecutar plan** se usa la versión más reciente guardada, no la original generada por el modelo.

## 1. Arquitectura y archivos afectados

| Archivo | Tipo de cambio | Descripcion |
|---|---|---|
| [postman_collection.json](postman_collection.json) | NEW | Coleccion Postman v2.1 (importable) con variables `base_url`/`csrf_token`/`proyecto_id`, manejo automatico de cookies de sesion, y carpetas: `Auth` (registro, login) y `Proyectos` (los 5 endpoints con casos exitosos y de error 404/422/`[]`). |

> [!NOTE]
> No se modifica ningun archivo de codigo (`routes/api.php`, `ProyectoApiController.php`, `bootstrap/app.php` ya estan completos segun la iteracion anterior). Este entregable es exclusivamente el archivo de coleccion para importar en Postman.

## 2. Dependencias nuevas o a actualizar

No aplica. No se agregan paquetes al proyecto; es un archivo JSON estatico consumido por la app de Postman.

## 3. Cambios de entorno/configuracion/base de datos

No aplica codigo diff. Unicamente se documentan dentro de la propia coleccion las variables que el usuario debe ajustar al importar:

```json
{
  "base_url": "http://127.0.0.1:8000",
  "correo": "prueba@example.com",
  "clave": "secret123"
}
```

> [!IMPORTANT]
> Las rutas `/api/proyectos` usan sesion (`web` + `UsuarioAutenticado`), no Bearer token. La coleccion debe habilitar "Automatically follow redirects" desactivado en login y usar el manejo de cookies nativo de Postman (mismo dominio en todas las requests) para que `POST/GET/PUT/PATCH/DELETE /api/proyectos` queden autenticados.

## 4. Estrategia de pruebas

1. Incluir en `Auth > Registro` y `Auth > Login` un **Test script** (pestana *Scripts > Post-response*) que extraiga el `_token` CSRF del HTML de la vista con regex y lo guarde en una variable de coleccion, reutilizada en el body `x-www-form-urlencoded` del propio request de login/registro.
   > [!WARNING]
   > Si el usuario ya existe, `Registro` devolvera error de validacion (correo duplicado); el flujo recomendado en la coleccion es ejecutar `Login` directamente en ese caso.
2. Carpeta `Proyectos` con una request por caso, replicando exactamente los escenarios de [API_TESTS.md](API_TESTS.md):
   - `POST` feliz (201) y `POST` con campos vacios/faltantes (422).
   - `GET` listado (200 con datos) y (200 con `[]`, tras eliminar).
   - `GET /{id}` existente (200) e inexistente (404).
   - `PUT`/`PATCH /{id}` existente (200) e inexistente (404) y con campos vacios (422).
   - `DELETE /{id}` existente (204) e inexistente (404).
3. Agregar un **Test script** en `POST /api/proyectos` (caso feliz) que guarde el `id` devuelto en una variable de coleccion `proyecto_id`, reutilizada automaticamente por las requests `GET/PUT/PATCH/DELETE /{id}` (evita editar IDs a mano).
4. Validacion final: importar el JSON en Postman (`File > Import`) y usar "Run collection" (Runner) para confirmar que cada request devuelve el codigo esperado, en el otro equipo con BD disponible. No se ejecuta nada en este equipo (sin BD).

## 5. Checklist de aceptacion

**Estructura de la coleccion**
- [ ] [postman_collection.json](postman_collection.json) valido segun Postman Collection Schema v2.1.0.
- [ ] Variables de coleccion (`base_url`, `correo`, `clave`, `csrf_token`, `proyecto_id`) declaradas y documentadas.
- [ ] Carpeta `Auth` con `Registro` y `Login` (extraccion de CSRF y captura de cookie de sesion).
- [ ] Carpeta `Proyectos` con las 5 operaciones y sus variantes de error.

**Cobertura de casos**
- [ ] `POST` cubre 201 (feliz) y 422 (vacios/faltantes).
- [ ] `GET` listado cubre 200 con datos y 200 con `[]`.
- [ ] `GET /{id}` cubre 200 y 404.
- [ ] `PUT`/`PATCH /{id}` cubre 200, 404 y 422.
- [ ] `DELETE /{id}` cubre 204 y 404.

> [!IMPORTANT]
> Confirmar que ninguna request de `Proyectos` incluya headers `Authorization`; deben depender solo de la cookie de sesion capturada en `Auth`, igual que en produccion.

**Entrega**
- [ ] Un unico archivo listo para `Import` directo en Postman, sin pasos manuales adicionales de configuracion.

---
Usa los botones **Ejecutar plan** / **Descartar** en el panel de chat para continuar.
