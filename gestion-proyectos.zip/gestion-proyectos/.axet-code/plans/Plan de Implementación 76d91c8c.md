# Plan: Corregir 500 en POST /api/proyectos por migracion no aplicada (created_by NOT NULL)

> [!NOTE]
> Puedes editar este archivo directamente antes de aprobarlo. Al pulsar **Ejecutar plan** se usa la versión más reciente guardada, no la original generada por el modelo.

## 1. Arquitectura y archivos afectados

| Archivo | Tipo de cambio | Descripcion |
|---|---|---|
| [database/migrations/2026_09_03_000000_make_created_by_nullable_on_proyectos_table.php](database/migrations/2026_09_03_000000_make_created_by_nullable_on_proyectos_table.php) | MOD | Reemplazar `$table->foreignId('created_by')->nullable()->change()` (requiere `doctrine/dbal`, **no instalado** en [composer.json](composer.json)) por `DB::statement(...)` especifico al driver activo (sqlite/mysql/pgsql), para que la columna quede realmente nullable sin depender de un paquete ausente. |
| [app/Http/Controllers/Api/ProyectoApiController.php](app/Http/Controllers/Api/ProyectoApiController.php) | MOD | En `store()`, envolver `Proyecto::create($datos)` en `try/catch (\Throwable $e)` y devolver `response()->json(['message' => '...'], 500)` con el mensaje real solo si `config('app.debug')`, para que un fallo de BD futuro no dependa del handler generico de `bootstrap/app.php`. |
| [DIAGNOSTICO_JSON.md](DIAGNOSTICO_JSON.md) | MOD | Agregar seccion especifica sobre este error 500: como leer `storage/logs/laravel.log` y como re-ejecutar migraciones (`migrate:fresh`) para confirmar que `created_by` quedo nullable. |

> [!NOTE]
> Causa raiz identificada por revision estatica (sin PHP/BD en este equipo): [composer.json](composer.json) no incluye `doctrine/dbal`, paquete requerido por Laravel para cualquier `->change()` de columna en migraciones. Si esa migracion fallo silenciosamente o nunca corrio en el otro equipo, `created_by` sigue siendo `NOT NULL` (definido en [database/migrations/2026_08_09_215821_add_created_by_to_proyectos_table.php](database/migrations/2026_08_09_215821_add_created_by_to_proyectos_table.php)). El controlador ([app/Http/Controllers/Api/ProyectoApiController.php](app/Http/Controllers/Api/ProyectoApiController.php):23) fuerza `created_by = null`, lo que viola la restriccion NOT NULL/FK en el INSERT y Laravel responde `500 {"message":"Server Error"}` (JSON correcto, pero por una excepcion de base de datos no controlada).

## 2. Dependencias nuevas o a actualizar

| Paquete | Version | Uso |
|---|---|---|
| — | — | No se agrega `doctrine/dbal`; se evita la dependencia usando `DB::statement()` nativo por driver, mas simple y sin afectar otros paquetes ya bloqueados por conflictos de version (`carbonphp/carbon-doctrine-types` restringe `doctrine/dbal` a `^4.0.0`). |

## 3. Cambios de entorno/configuracion/base de datos

```diff
--- a/database/migrations/2026_09_03_000000_make_created_by_nullable_on_proyectos_table.php
+++ b/database/migrations/2026_09_03_000000_make_created_by_nullable_on_proyectos_table.php
     public function up(): void
     {
-        Schema::table('proyectos', function (Blueprint $table) {
-            $table->foreignId('created_by')->nullable()->change();
-        });
+        $driver = Schema::getConnection()->getDriverName();
+
+        match ($driver) {
+            'sqlite' => DB::statement('CREATE TABLE proyectos_tmp AS SELECT * FROM proyectos'), // ver migracion completa: rebuild sqlite-safe
+            'pgsql' => DB::statement('ALTER TABLE proyectos ALTER COLUMN created_by DROP NOT NULL'),
+            default => DB::statement('ALTER TABLE proyectos MODIFY created_by BIGINT UNSIGNED NULL'),
+        };
     }
```

> [!WARNING]
> SQLite no soporta `ALTER COLUMN ... DROP NOT NULL` directamente; requiere recrear la tabla (`PRAGMA foreign_keys=off` + copiar datos + renombrar). La migracion final debe implementar ese procedimiento completo para sqlite (driver por defecto de este proyecto segun `composer.json` → `post-create-project-cmd` crea `database/database.sqlite`).

## 4. Estrategia de pruebas

1. Confirmar el driver de BD real usado en el otro equipo antes de tocar la migracion:
   ```bash
   php artisan tinker --execute="echo config('database.default');"
   ```
2. Revisar el log para confirmar la hipotesis exacta (constraint NOT NULL vs FK vs otra causa):
   ```bash
   tail -n 50 storage/logs/laravel.log
   ```
   > [!WARNING]
   > Si el log muestra un error distinto a "NOT NULL constraint failed: proyectos.created_by" (p. ej. columna inexistente, tabla `users` faltante), el diagnostico de esta seccion debe revisarse antes de aplicar el fix.
3. Revertir y re-aplicar migraciones en limpio para verificar que la nueva migracion sí deja `created_by` nullable:
   ```bash
   php artisan migrate:fresh
   ```
4. Repetir el request que fallaba y confirmar 201 con `id` presente:
   ```bash
   curl -i -X POST http://127.0.0.1:8000/api/proyectos \
     -H "Content-Type: application/json" \
     -d '{"nombre":"Proyecto X","fecha_inicio":"2025-01-01","estado":"activo","responsable":"Ana","monto":1000}'
   ```
5. Re-ejecutar la coleccion Postman completa (Runner) para confirmar que los tests "Status 201 Created" y "Respuesta incluye todos los campos" pasan.

## 5. Checklist de aceptacion

**Migracion**
- [ ] `created_by` queda `NULL`-able en sqlite, mysql y pgsql sin requerir `doctrine/dbal`.
- [ ] `php artisan migrate:fresh` corre sin errores en el driver real del otro equipo.

**API**
- [ ] `POST /api/proyectos` con body valido responde `201` con el `id` del proyecto creado.
- [ ] `POST /api/proyectos` sigue respondiendo `422` JSON con campos vacios/faltantes (sin regresion).

> [!IMPORTANT]
> Confirmar que ningun otro endpoint (`GET`, `PUT`/`PATCH`, `DELETE`) dependa de `created_by` NOT NULL en alguna consulta o validacion adicional antes de cerrar el fix.

**Documentacion**
- [ ] [DIAGNOSTICO_JSON.md](DIAGNOSTICO_JSON.md) incluye el paso de revisar `storage/logs/laravel.log` para diagnosticar futuros 500.

---
Usa los botones **Ejecutar plan** / **Descartar** en el panel de chat para continuar.
