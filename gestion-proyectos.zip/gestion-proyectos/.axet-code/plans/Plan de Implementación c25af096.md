# Plan: Eliminar dependencia de rate limiter "api" inexistente

> [!NOTE]
> Puedes editar este archivo directamente antes de aprobarlo. Al pulsar **Ejecutar plan** se usa la versión más reciente guardada, no la original generada por el modelo.

## 1. Arquitectura y archivos afectados

| Archivo | Tipo de cambio | Descripcion |
|---|---|---|
| [bootstrap/app.php](bootstrap/app.php) | MOD | En el `$middleware->group('api', [...])` redefinido, quitar `ThrottleRequests::class.':api'` (o registrar el limiter `api` con `RateLimiter::for()`) para que la excepcion `MissingRateLimiterException` deje de ocurrir en cada request bajo `/api/*`. |
| [routes/api.php](routes/api.php) | MOD | Ninguno (se confirma que las rutas ya no referencian throttle propio; el problema viene del grupo global en `bootstrap/app.php`). |

> [!NOTE]
> Causa raiz: la iteracion anterior redefinio el grupo de middleware `api` en [bootstrap/app.php](bootstrap/app.php) incluyendo `ThrottleRequests::class.':api'`, pero el limiter llamado `api` nunca se registro (Laravel 11+ ya no trae `RouteServiceProvider::configureRateLimiting()` por defecto en apps sin `bootstrap/providers.php` legacy). Cualquier request a `/api/*` dispara `MissingRateLimiterException`, que Laravel muestra como pagina HTML de error 500 salvo que `shouldRenderJsonWhen` ya la intercepte (aqui si devuelve JSON, pero con 500). La solucion mas simple y segura es quitar el throttle de ese grupo, ya que no era un requisito explicito del usuario.

## 2. Dependencias nuevas o a actualizar

No se agregan dependencias; se usan clases ya incluidas en `laravel/framework`.

## 3. Cambios de entorno/configuracion/base de datos

```diff
--- a/bootstrap/app.php
+++ b/bootstrap/app.php
     ->withMiddleware(function (Middleware $middleware): void {
         $middleware->validateCsrfTokens(except: [
             'api/*',
         ]);
         $middleware->group('api', [
             \Illuminate\Routing\Middleware\SubstituteBindings::class,
-            \Illuminate\Routing\Middleware\ThrottleRequests::class.':api',
         ]);
     })
```

No se requieren cambios de base de datos.

## 4. Estrategia de pruebas

1. Confirmar en el equipo del usuario que el error desaparece tras limpiar cache de config (el error puede quedar cacheado):
   ```bash
   php artisan config:clear
   php artisan route:clear
   ```
2. Repetir el request que fallaba:
   ```bash
   curl -i http://127.0.0.1:8000/api/proyectos
   ```
   **Esperado:** `200 OK`, JSON, sin `MissingRateLimiterException`.
3. Repetir el `POST` que motivo el test de Postman ("Status 201 Created"):
   ```bash
   curl -i -X POST http://127.0.0.1:8000/api/proyectos \
     -H "Content-Type: application/json" \
     -d '{"nombre":"Proyecto X","fecha_inicio":"2025-01-01","estado":"activo","responsable":"Ana","monto":1000}'
   ```
   **Esperado:** `201 Created` con `id` en el body.
4. Re-ejecutar la coleccion Postman completa (Runner) para confirmar que ya no hay 500 en ninguna request.

> [!WARNING]
> Sin PHP disponible en este equipo (verificado en iteraciones previas); todo lo anterior se verifica solo por lectura de codigo aqui. La ejecucion real debe hacerse en el equipo del usuario, que es donde se reprodujo el error.

## 5. Checklist de aceptacion

**Middleware**
- [ ] Grupo `api` en `bootstrap/app.php` ya no referencia `ThrottleRequests::class.':api'`.
- [ ] `php artisan config:clear && php artisan route:clear` ejecutado antes de reprobar.

> [!IMPORTANT]
> Confirmar que quitar el throttle no reintroduce ningun middleware de sesion: el grupo `api` debe quedar solo con `SubstituteBindings` (o vacio), sin `StartSession`/`EncryptCookies`/`VerifyCsrfToken`/`Authenticate`.

**API**
- [ ] `GET /api/proyectos` responde `200` JSON sin excepcion.
- [ ] `POST /api/proyectos` responde `201` JSON con `id` presente.
- [ ] Coleccion Postman completa corre sin ningun `500`.

---
Usa los botones **Ejecutar plan** / **Descartar** en el panel de chat para continuar.
