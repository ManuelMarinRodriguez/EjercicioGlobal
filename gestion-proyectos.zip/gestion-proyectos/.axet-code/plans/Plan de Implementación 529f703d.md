# Plan: API REST CRUD de Proyectos

> [!NOTE]
> Puedes editar este archivo directamente antes de aprobarlo. Al pulsar **Ejecutar plan** se usa la versión más reciente guardada, no la original generada por el modelo.

## 1. Arquitectura y archivos afectados

| Archivo | Tipo de cambio | Descripcion |
|---|---|---|
| [bootstrap/app.php](bootstrap/app.php) | MOD | Registrar `routes/api.php` con prefijo `/api` en `withRouting()`. |
| [routes/api.php](routes/api.php) | NEW | Define las 5 rutas REST (`POST`, `GET`, `GET /{id}`, `PUT`/`PATCH`, `DELETE`) protegidas por `UsuarioAutenticado`. |
| [app/Http/Controllers/Api/ProyectoApiController.php](app/Http/Controllers/Api/ProyectoApiController.php) | NEW | Controlador dedicado a JSON: `index`, `store`, `show`, `update`, `destroy` con codigos 201/200/404/204. |
| [app/Http/Requests/StoreProyectoRequest.php](app/Http/Requests/StoreProyectoRequest.php) | NEW | Reglas `required` para `nombre`, `fecha_inicio`, `estado`, `responsable`, `monto`. |
| [app/Http/Requests/UpdateProyectoRequest.php](app/Http/Requests/UpdateProyectoRequest.php) | NEW | Mismas reglas `required` para actualizacion completa (PUT/PATCH). |
| [app/Models/Proyecto.php](app/Models/Proyecto.php) | MOD | Agregar `casts` (`fecha_inicio` => date, `monto` => decimal) para asegurar formato consistente en JSON. |
| [tests/Feature/ProyectoApiTest.php](tests/Feature/ProyectoApiTest.php) | NEW | Cobertura de los 5 endpoints y sus casos borde (404, arreglo vacio, validacion). |

> [!NOTE]
> No se reescribe `ProyectoController.php` (vistas Blade) ni sus rutas en [routes/web.php](routes/web.php); el API queda en un controlador y namespace separado (`App\Http\Controllers\Api`) para no romper el flujo web existente.

## 2. Dependencias nuevas o a actualizar

No se requieren paquetes nuevos: Laravel 13 (`laravel/framework: ^13.8`) ya incluye `Illuminate\Http\JsonResponse`, `Form Requests` y el motor de rutas necesarios.

## 3. Cambios de entorno/configuracion/base de datos

No se requieren cambios de esquema (la tabla `proyectos` ya tiene todos los campos). Solo cambia el bootstrap de rutas:

```diff
 return Application::configure(basePath: dirname(__DIR__))
     ->withRouting(
         web: __DIR__.'/../routes/web.php',
+        api: __DIR__.'/../routes/api.php',
         commands: __DIR__.'/../routes/console.php',
         health: '/up',
     )
```

> [!IMPORTANT]
> El campo `created_by` sigue siendo `NOT NULL` con FK a `users`. Las rutas API se mantienen bajo el middleware `UsuarioAutenticado` (guard `web`/sesion) para poder asignar `Auth::id()` igual que en el controlador web, evitando romper la restriccion de la BD.

## 4. Estrategia de pruebas

1. Ejecutar migraciones limpias en SQLite de test:
   ```bash
   php artisan test --filter ProyectoApiTest
   ```
2. `POST /api/proyectos` — caso feliz (201, cuerpo con todos los campos) y caso de validacion (422 si algun campo requerido falta o esta vacio).
3. `GET /api/proyectos` — con tabla vacia (200 + `[]`) y con datos (200 + arreglo con todos los campos).
4. `GET /api/proyectos/{id}` — existente (200 + campos completos) e inexistente (404).
5. `PUT /api/proyectos/{id}` — existente (200 + campos actualizados) e inexistente (404).
   > [!WARNING]
   > El enunciado menciona "respuesta HTTP de 201" para actualizar pero luego exige "codigo de respuesta debe ser 200"; se implementara **200** (estandar REST para update) por ser el requisito mas especifico y consistente con el resto del enunciado. Se documentara la discrepancia al usuario.
6. `DELETE /api/proyectos/{id}` — existente (204, cuerpo vacio) e inexistente (404).
7. Suite completa final:
   ```bash
   php artisan test
   ```

## 5. Checklist de aceptacion

**Rutas y controlador**
- [ ] `routes/api.php` creado y registrado en `bootstrap/app.php`.
- [ ] `ProyectoApiController` implementa `index`, `store`, `show`, `update`, `destroy`.

**Reglas de negocio**
- [ ] POST valida todos los campos como `required` y responde 201 con el proyecto creado.
- [ ] GET (listado) responde 200 y `[]` cuando no hay registros.
- [ ] GET (por id) responde 200 con todos los campos, o 404 si no existe.
- [ ] PUT/PATCH responde 200 con todos los campos actualizados, o 404 si no existe.
- [ ] DELETE responde 204 con cuerpo vacio, o 404 si no existe.

> [!IMPORTANT]
> Verificar que las rutas API no queden accesibles sin autenticacion, para no romper la integridad referencial de `created_by`.

**Pruebas**
- [ ] `tests/Feature/ProyectoApiTest.php` cubre los 5 endpoints y sus casos borde.
- [ ] `php artisan test` pasa sin fallos.

---
Usa los botones **Ejecutar plan** / **Descartar** en el panel de chat para continuar.
