# Plan: API REST CRUD de Proyectos (POST, GET, PATCH/PUT, DELETE)

> [!NOTE]
> Puedes editar este archivo directamente antes de aprobarlo. Al pulsar **Ejecutar plan** se usa la versión más reciente guardada, no la original generada por el modelo.

## 1. Arquitectura y archivos afectados

| Archivo | Tipo de cambio | Descripcion |
|---|---|---|
| [bootstrap/app.php](bootstrap/app.php) | MOD | Registrar `api: __DIR__.'/../routes/api.php'` en `withRouting()` para habilitar el grupo de rutas `/api/*`. |
| [routes/api.php](routes/api.php) | NEW | Rutas `GET /api/proyectos`, `POST /api/proyectos`, `GET /api/proyectos/{id}`, `PUT\|PATCH /api/proyectos/{id}`, `DELETE /api/proyectos/{id}` apuntando al nuevo controlador API, bajo el middleware `UsuarioAutenticado` existente. |
| [app/Http/Controllers/Api/ProyectoApiController.php](app/Http/Controllers/Api/ProyectoApiController.php) | NEW | Controlador dedicado a JSON (no reutiliza el `ProyectoController` de vistas) con `index`, `store`, `show`, `update`, `destroy`, cada uno devolviendo el codigo HTTP exacto pedido. |
| [app/Http/Requests/StoreProyectoRequest.php](app/Http/Requests/StoreProyectoRequest.php) | NEW | FormRequest con reglas `required` para `nombre`, `fecha_inicio`, `estado`, `responsable`, `monto`. `created_by` se deriva de `Auth::id()`, no se valida como input. |
| [app/Http/Requests/UpdateProyectoRequest.php](app/Http/Requests/UpdateProyectoRequest.php) | NEW | Mismas reglas `required` para la actualizacion (evita payloads parciales, segun "todos los campos son requeridos"). |
| [app/Http/Resources/ProyectoResource.php](app/Http/Resources/ProyectoResource.php) | NEW | Serializador consistente que expone todos los campos del modelo en cada respuesta (`index`, `show`, `store`, `update`). |
| [app/Models/Proyecto.php](app/Models/Proyecto.php) | MOD | Sin cambios de esquema; se revisara si conviene exponer `casts` (`fecha_inicio` a `date`, `monto` a `decimal:2`) para que el JSON serialice formatos consistentes. |
| [tests/Feature/ProyectoApiTest.php](tests/Feature/ProyectoApiTest.php) | NEW | Cobertura de los 5 endpoints y sus casos borde (404, arreglo vacio, campos requeridos). |

> [!NOTE]
> No se modifica `app/Http/Controllers/ProyectoController.php` ni `routes/web.php`: el CRUD basado en vistas Blade sigue intacto y separado del nuevo API JSON.

## 2. Dependencias nuevas o a actualizar

No se requieren paquetes nuevos. Laravel 13 ya incluye el soporte de rutas `api.php` y `FormRequest`/`JsonResource` sin necesidad de instalar `laravel/sanctum` ni ejecutar `artisan install:api`, ya que no se usa autenticacion por token.

## 3. Cambios de entorno/configuracion/base de datos

No se requieren migraciones nuevas: la tabla `proyectos` ya define `nombre`, `fecha_inicio`, `estado`, `responsable`, `monto` como `NOT NULL` y `created_by` con FK obligatoria, lo que respalda la regla "todos los campos son requeridos".

```diff
--- a/bootstrap/app.php
+++ b/bootstrap/app.php
 return Application::configure(basePath: dirname(__DIR__))
     ->withRouting(
         web: __DIR__.'/../routes/web.php',
+        api: __DIR__.'/../routes/api.php',
         commands: __DIR__.'/../routes/console.php',
         health: '/up',
     )
```

## 4. Estrategia de pruebas

1. Ejecutar la suite completa antes de tocar nada para tener una linea base:
   ```bash
   php artisan test
   ```
2. Test `POST /api/proyectos`: caso feliz (201 + JSON con todos los campos) y caso con campos vacios/faltantes (debe fallar la validacion, sin crear registro).
3. Test `GET /api/proyectos`: con tabla vacia (200 + `[]`) y con registros (200 + arreglo con todos los campos).
4. Test `GET /api/proyectos/{id}`: id existente (200 + todos los campos) e id inexistente (404).
5. Test `PUT/PATCH /api/proyectos/{id}`: id existente (respuesta con campos actualizados) e id inexistente (404).

   > [!WARNING]
   > El enunciado es contradictorio: el titulo del bloque de actualizacion pide "respuesta HTTP de 201" pero el detalle indica "El codigo de respuesta debe ser 200". Se implementara **200** (estandar REST para PUT/PATCH exitoso sobre recurso existente) por ser el requisito mas especifico y repetido; se documentara la discrepancia para confirmacion del usuario antes de cerrar el ticket.

6. Test `DELETE /api/proyectos/{id}`: id existente (204 sin body) e id inexistente (404).
7. Ejecutar el archivo especifico durante el desarrollo iterativo:
   ```bash
   php artisan test --filter=ProyectoApiTest
   ```

## 5. Checklist de aceptacion

**Backend**
- [ ] `routes/api.php` registrado en `bootstrap/app.php` y accesible bajo `/api/proyectos`.
- [ ] `POST /api/proyectos` responde 201 con el proyecto creado y todos sus campos.
- [ ] `GET /api/proyectos` responde 200, incluye todos los campos, y devuelve `[]` si no hay datos.
- [ ] `GET /api/proyectos/{id}` responde 200 con todos los campos o 404 si no existe.
- [ ] `PUT/PATCH /api/proyectos/{id}` responde con los campos actualizados o 404 si no existe.
- [ ] `DELETE /api/proyectos/{id}` responde 204 sin body o 404 si no existe.

**Validacion**
- [ ] `StoreProyectoRequest` y `UpdateProyectoRequest` marcan `nombre`, `fecha_inicio`, `estado`, `responsable`, `monto` como `required`.
- [ ] `created_by` se asigna automaticamente desde `Auth::id()`, no se exige como input del cliente.

> [!IMPORTANT]
> Confirmar con el usuario el codigo de respuesta final del endpoint de actualizacion (200 vs 201 mencionados de forma contradictoria) antes de dar por cerrado el requerimiento, para evitar fallos en pruebas automatizadas de aceptacion.

**Pruebas**
- [ ] `tests/Feature/ProyectoApiTest.php` cubre los 5 endpoints y sus casos 404/vacio.
- [ ] `php artisan test` pasa completo sin romper `ExampleTest`.

---
Usa los botones **Ejecutar plan** / **Descartar** en el panel de chat para continuar.
