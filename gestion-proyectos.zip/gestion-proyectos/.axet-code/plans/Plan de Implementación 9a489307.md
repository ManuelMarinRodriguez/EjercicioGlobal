# Plan: Blindaje definitivo de respuestas JSON en microservicios API

> [!NOTE]
> Puedes editar este archivo directamente antes de aprobarlo. Al pulsar **Ejecutar plan** se usa la versión más reciente guardada, no la original generada por el modelo.

## 1. Arquitectura y archivos afectados

| Archivo | Tipo de cambio | Descripcion |
|---|---|---|
| [bootstrap/app.php](bootstrap/app.php) | MOD | Redefinir explicitamente el grupo de middleware `api` con `$middleware->group('api', [...])`, incluyendo solo `SubstituteBindings` y `ThrottleRequests` — sin `StartSession`, `EncryptCookies`, `VerifyCsrfToken` ni `Authenticate` — para eliminar por completo la posibilidad de que una request a `/api/*` inicie sesion o sea redirigida a `/login`, sin depender de la configuracion implicita de Laravel. |
| [routes/api.php](routes/api.php) | MOD | Agregar `Route::get('/ping', ...)` de diagnostico sin controlador ni Form Request, que devuelve JSON estatico `{"ok": true}` — util para aislar si un problema reportado es de infraestructura/cache (por ejemplo, siempre funciona) o de un endpoint especifico. |
| [DIAGNOSTICO_JSON.md](DIAGNOSTICO_JSON.md) | NEW | Guia de verificacion paso a paso para el equipo con BD: limpieza de caches, comandos `curl -i` que muestran el `Content-Type` real de cada respuesta, y la distincion explicita entre la ruta web protegida `/proyectos` (HTML, requiere login) y la ruta API publica `/api/proyectos` (JSON, sin login) — causa mas probable del reclamo recurrente. |
| [API_TESTS.md](API_TESTS.md) | MOD | Agregar el caso `GET /api/ping` y una nota destacada aclarando que **nunca** se debe probar `/proyectos` (sin `/api`) esperando JSON. |

> [!NOTE]
> Revision linea por linea confirma que el codigo actual ya es correcto: [routes/api.php](routes/api.php) no tiene `UsuarioAutenticado` ni `web`, [ProyectoApiController.php](app/Http/Controllers/Api/ProyectoApiController.php) no usa `Auth::`, los `FormRequest` fuerzan 422 JSON en `failedValidation()`, y [bootstrap/app.php](bootstrap/app.php) ya fuerza JSON en excepciones bajo `api/*`. Este plan agrega una capa explicita adicional (grupo `api` redefinido) y herramientas de diagnostico porque no hay PHP/BD en este equipo para reproducir el reclamo, y la causa mas probable es cache vieja o prueba contra la URL equivocada (`/proyectos` en vez de `/api/proyectos`).

## 2. Dependencias nuevas o a actualizar

No se requieren paquetes nuevos; se usan clases ya incluidas en `laravel/framework` (`Illuminate\Routing\Middleware\SubstituteBindings`, `Illuminate\Routing\Middleware\ThrottleRequests`).

## 3. Cambios de entorno/configuracion/base de datos

```diff
--- a/bootstrap/app.php
+++ b/bootstrap/app.php
     ->withMiddleware(function (Middleware $middleware): void {
         $middleware->validateCsrfTokens(except: [
             'api/*',
         ]);
+        $middleware->group('api', [
+            \Illuminate\Routing\Middleware\SubstituteBindings::class,
+            \Illuminate\Routing\Middleware\ThrottleRequests::class.':api',
+        ]);
     })
```

```diff
--- a/routes/api.php
+++ b/routes/api.php
 Route::middleware(ForceJsonResponse::class)->group(function () {
+    Route::get('/ping', fn () => response()->json(['ok' => true]))
+        ->name('api.ping');
+
     Route::get('/proyectos', [ProyectoApiController::class, 'index'])
```

No se requieren cambios de base de datos.

## 4. Estrategia de pruebas

> [!WARNING]
> Sin PHP/BD disponible en este equipo (verificado: `php`/`composer` no estan en el PATH y no existe `.env`). Todo lo anterior es revision estatica; la ejecucion real debe hacerse en el otro equipo.

1. En el otro equipo, limpiar caches antes de cualquier prueba (causa mas probable si el codigo ya estaba corregido en iteraciones previas):
   ```bash
   php artisan route:clear
   php artisan config:clear
   php artisan cache:clear
   ```
2. Verificar el diagnostico minimo, sin controlador ni validacion de por medio:
   ```bash
   curl -i http://127.0.0.1:8000/api/ping
   ```
   **Esperado:** `200 OK`, `Content-Type: application/json`, body `{"ok":true}`.
3. Confirmar que la ruta **web** (sin `/api`) sigue siendo HTML y exige login — esto es intencional, no un bug:
   ```bash
   curl -i http://127.0.0.1:8000/proyectos
   ```
   **Esperado:** redirect 302 a `/login` (comportamiento correcto de la vista Blade, no del API).
4. Confirmar el endpoint real sin ningun header adicional:
   ```bash
   curl -i http://127.0.0.1:8000/api/proyectos
   ```
   **Esperado:** `200 OK`, `Content-Type: application/json`, sin `Location: /login`.
5. Correr la coleccion Postman completa (Runner) y revisar visualmente el `Content-Type` de cada respuesta.

## 5. Checklist de aceptacion

**Middleware y rutas**
- [ ] Grupo `api` redefinido en `bootstrap/app.php` sin `StartSession`, `EncryptCookies`, `VerifyCsrfToken` ni middleware de autenticacion.
- [ ] `GET /api/ping` responde JSON sin pasar por controlador ni Form Request.

> [!IMPORTANT]
> Confirmar que `/api/ping` y `/api/proyectos` respondan JSON **incluso con cache de rutas/config vieja** (es decir, repetir la prueba tras `route:clear`/`config:clear`, no solo antes).

**Documentacion**
- [ ] [DIAGNOSTICO_JSON.md](DIAGNOSTICO_JSON.md) creado, distinguiendo claramente `/proyectos` (HTML, login) de `/api/proyectos` (JSON, publico).
- [ ] [API_TESTS.md](API_TESTS.md) actualizado con el caso `/api/ping` y la advertencia sobre la URL correcta.

---
Usa los botones **Ejecutar plan** / **Descartar** en el panel de chat para continuar.
