# Plan: Endurecer rutas API para JSON puro sin sesion y limpiar caches

> [!NOTE]
> Puedes editar este archivo directamente antes de aprobarlo. Al pulsar **Ejecutar plan** se usa la versión más reciente guardada, no la original generada por el modelo.

## 1. Arquitectura y archivos afectados

| Archivo | Tipo de cambio | Descripcion |
|---|---|---|
| [routes/api.php](routes/api.php) | MOD | Agregar `Route::fallback()` dentro del archivo para que cualquier ruta `/api/*` no definida responda JSON 404 en lugar de la pagina HTML por defecto de Laravel. |
| [bootstrap/app.php](bootstrap/app.php) | MOD | Redefinir explicitamente el grupo de middleware `api` en `withMiddleware()` (`$middleware->group('api', [...])` solo con `SubstituteBindings`/`ThrottleRequests`) para garantizar, de forma explicita y no solo por convencion, que ningun middleware de sesion/auth pueda quedar adherido a ese grupo. |
| [app/Http/Middleware/ForceJsonResponse.php](app/Http/Middleware/ForceJsonResponse.php) | NEW | Middleware que fuerza el header `Accept: application/json` en cada request entrante bajo `/api/*`, para que ninguna respuesta (exitosa o de error) pueda degradar a HTML sin importar los headers que envie el cliente. |
| [routes/api.php](routes/api.php) | MOD | Aplicar `ForceJsonResponse` a las 5 rutas existentes (via `Route::middleware(...)->group(...)`). |
| [API_TESTS.md](API_TESTS.md) | MOD | Agregar seccion "Diagnostico" con los comandos de limpieza de cache y una prueba de ruta inexistente (`/api/no-existe`) para confirmar 404 JSON. |
| [postman_collection.json](postman_collection.json) | MOD | Agregar request "13. GET /api/ruta-inexistente - Fallback (404 JSON)" para verificar en el otro equipo que el fallback nunca devuelve HTML. |

> [!NOTE]
> Revision de codigo actual (`routes/api.php`, `ProyectoApiController.php`, `bootstrap/app.php`, `StoreProyectoRequest`/`UpdateProyectoRequest`, `Controller.php` base) confirma que ya no hay middleware de sesion (`web`, `UsuarioAutenticado`) ni `auth` aplicado a la API, y que la validacion ya fuerza JSON 422. El reclamo probablemente proviene de cache de rutas/config obsoleta en el entorno de prueba o de una coleccion Postman/curl re-importada a medias; este plan agrega capas de seguridad adicionales (fallback + middleware forzado) para que sea imposible reproducir HTML/login aunque exista cache vieja de por medio.

## 2. Dependencias nuevas o a actualizar

No se requieren paquetes nuevos: `ForceJsonResponse` y `Route::fallback()` usan clases ya incluidas en `laravel/framework: ^13.8`.

## 3. Cambios de entorno/configuracion/base de datos

```diff
--- a/bootstrap/app.php
+++ b/bootstrap/app.php
     ->withMiddleware(function (Middleware $middleware): void {
         $middleware->validateCsrfTokens(except: [
             'api/*',
         ]);
+        $middleware->group('api', [
+            \Illuminate\Routing\Middleware\SubstituteBindings::class,
+            \Illuminate\Routing\Middleware\ThrottleRequestsWithRedis::class.':api',
+        ]);
     })
```

```diff
--- a/routes/api.php
+++ b/routes/api.php
+use App\Http\Middleware\ForceJsonResponse;
+
-Route::get('/proyectos', [ProyectoApiController::class, 'index'])
-    ->name('api.proyectos.index');
+Route::middleware(ForceJsonResponse::class)->group(function () {
+    Route::get('/proyectos', [ProyectoApiController::class, 'index'])
+        ->name('api.proyectos.index');
+    // ... resto de rutas
+});
+
+Route::fallback(function () {
+    return response()->json(['message' => 'Ruta no encontrada.'], 404);
+});
```

No se requieren cambios de base de datos.

## 4. Estrategia de pruebas

> [!WARNING]
> Sin BD disponible en este equipo: no se ejecutan migraciones ni `php artisan test` aqui. Verificacion solo estatica de codigo.

1. Documentar en `API_TESTS.md` los comandos de limpieza de cache a correr **en el otro equipo antes de probar** (causa mas probable del reclamo si el codigo ya estaba corregido):
   ```bash
   php artisan route:clear
   php artisan config:clear
   php artisan cache:clear
   php artisan serve
   ```
2. Verificar (lectura de codigo) que `Route::fallback()` en `routes/api.php` solo aplique dentro del prefijo `/api` (por estar en ese archivo) y no afecte a `routes/web.php`.
3. Agregar prueba `curl` de ruta inexistente sin `Accept` header, para confirmar JSON aun sin ese encabezado:
   ```bash
   curl -i "$BASE_URL/api/ruta-inexistente"
   ```
4. Agregar prueba `curl` de `/api/proyectos` sin ningun header, para confirmar que nunca redirige a `/login`:
   ```bash
   curl -i "$BASE_URL/api/proyectos"
   ```
   **Esperado:** `200 OK` con `Content-Type: application/json`, sin `Location: /login` en la respuesta.
5. En el otro equipo con BD, correr la coleccion Postman actualizada completa (Runner) y confirmar visualmente que ninguna respuesta muestra `Content-Type: text/html`.

## 5. Checklist de aceptacion

**Rutas y middleware**
- [ ] `routes/api.php` sin ninguna referencia a `web`, `UsuarioAutenticado` o `Auth::`.
- [ ] `Route::fallback()` agregado en `routes/api.php` devolviendo JSON 404.
- [ ] `ForceJsonResponse` aplicado a las 5 rutas de `proyectos`.

> [!IMPORTANT]
> Confirmar que el grupo de middleware `api` redefinido en `bootstrap/app.php` no incluya `StartSession`, `EncryptCookies`, `VerifyCsrfToken` ni `Authenticate`/`UsuarioAutenticado`, para que ninguna peticion a `/api/*` pueda terminar en un redirect a `/login`.

**Respuestas JSON**
- [ ] `GET /api/proyectos` sin headers responde 200 JSON (no redirect, no HTML).
- [ ] `GET /api/ruta-inexistente` responde 404 JSON (no la pagina 404 de Laravel).
- [ ] `POST`/`PUT`/`PATCH` con campos vacios siguen respondiendo 422 JSON.

**Documentacion**
- [ ] `API_TESTS.md` incluye la seccion de limpieza de cache y los dos `curl` de diagnostico (sin headers, ruta inexistente).
- [ ] `postman_collection.json` incluye el request de fallback (404 JSON) sin depender de cookies ni login.

---
Usa los botones **Ejecutar plan** / **Descartar** en el panel de chat para continuar.
