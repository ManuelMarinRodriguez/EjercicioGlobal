# Plan: API REST CRUD de Proyectos (sin pruebas automatizadas + coleccion curl)

> [!NOTE]
> Puedes editar este archivo directamente antes de aprobarlo. Al pulsar **Ejecutar plan** se usa la versión más reciente guardada, no la original generada por el modelo.

## 1. Arquitectura y archivos afectados

| Archivo | Tipo de cambio | Descripcion |
|---|---|---|
| [bootstrap/app.php](bootstrap/app.php) | MOD | Registrar `routes/api.php` con prefijo `/api` en `withRouting()`. |
| [routes/api.php](routes/api.php) | NEW | Define las 5 rutas REST (`POST`, `GET`, `GET /{id}`, `PUT`/`PATCH`, `DELETE`) protegidas por `UsuarioAutenticado`. |
| [app/Http/Controllers/Api/ProyectoApiController.php](app/Http/Controllers/Api/ProyectoApiController.php) | NEW | Controlador dedicado a JSON: `index`, `store`, `show`, `update`, `destroy` con codigos 201/200/404/204. |
| [app/Http/Requests/StoreProyectoRequest.php](app/Http/Requests/StoreProyectoRequest.php) | NEW | Reglas `required` para todos los campos del proyecto. |
| [app/Http/Requests/UpdateProyectoRequest.php](app/Http/Requests/UpdateProyectoRequest.php) | NEW | Mismas reglas `required` para actualizacion completa (PUT/PATCH). |
| [app/Models/Proyecto.php](app/Models/Proyecto.php) | MOD | Agregar/ajustar `casts` para asegurar formato consistente en JSON. |
| [API_TESTS.md](API_TESTS.md) | NEW | Coleccion de comandos `curl` para probar los 5 endpoints (casos exitosos y de error) en otro equipo con BD disponible. |

> [!NOTE]
> No se reescribe `ProyectoController.php` (vistas Blade) ni [routes/web.php](routes/web.php); el API queda aislado en `App\Http\Controllers\Api`.

## 2. Dependencias nuevas o a actualizar

No se requieren paquetes nuevos: Laravel 13 ya incluye todo lo necesario (Form Requests, JsonResponse, motor de rutas).

## 3. Cambios de entorno/configuracion/base de datos

```diff
 return Application::configure(basePath: dirname(__DIR__))
     ->withRouting(
         web: __DIR__.'/../routes/web.php',
+        api: __DIR__.'/../routes/api.php',
         commands: __DIR__.'/../routes/console.php',
         health: '/up',
     )
```

No se requieren cambios de esquema (la tabla `proyectos` ya tiene todos los campos).

## 4. Estrategia de pruebas

> [!WARNING]
> No se ejecutaran migraciones ni `php artisan test` en este equipo (sin BD disponible). La verificacion se limitara a revision estatica del codigo. Las pruebas reales se haran en otro computador usando [API_TESTS.md](API_TESTS.md).

1. Generar [API_TESTS.md](API_TESTS.md) con un bloque `bash` por cada caso:
   - `POST /api/proyectos` caso feliz (201) y caso de validacion (422, campo vacio).
   - `GET /api/proyectos` con datos y (documentado) caso de tabla vacia (200 + `[]`).
   - `GET /api/proyectos/{id}` existente (200) e inexistente (404).
   - `PUT /api/proyectos/{id}` existente (200) e inexistente (404).
   - `DELETE /api/proyectos/{id}` existente (204) e inexistente (404).
2. Cada bloque `curl` incluira `-i` para mostrar el codigo de estado HTTP y encabezados relevantes (cookies/CSRF si la ruta usa sesion).
3. No se crea `tests/Feature/ProyectoApiTest.php` en esta iteracion.

## 5. Checklist de aceptacion

**Rutas y controlador**
- [ ] `routes/api.php` creado y registrado en `bootstrap/app.php`.
- [ ] `ProyectoApiController` implementa `index`, `store`, `show`, `update`, `destroy`.

**Reglas de negocio**
- [ ] POST valida todos los campos como `required` y responde 201 con el proyecto creado.
- [ ] GET (listado) responde 200 y `[]` cuando no hay registros.
- [ ] GET (por id) responde 200 con todos los campos, o 404 si no existe.
- [ ] PUT/PATCH responde 200 con todos los campos actualizados, o 404 si no existe.
- [ ] DELETE responde 204 con cuerpo vacio, o 404 si no existe.

> [!IMPORTANT]
> Verificar que las rutas API no queden accesibles sin autenticacion, para no romper la integridad referencial de `created_by`.

**Documentacion**
- [ ] [API_TESTS.md](API_TESTS.md) generado con `curl` para los 5 endpoints y sus casos de error (404, 422, arreglo vacio).

---
Usa los botones **Ejecutar plan** / **Descartar** en el panel de chat para continuar.
