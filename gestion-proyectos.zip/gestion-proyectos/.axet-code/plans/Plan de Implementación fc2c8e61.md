# Plan: Endpoints API sin sesion y con respuestas JSON puras

> [!NOTE]
> Puedes editar este archivo directamente antes de aprobarlo. Al pulsar **Ejecutar plan** se usa la versión más reciente guardada, no la original generada por el modelo.

## 1. Arquitectura y archivos afectados

| Archivo | Tipo de cambio | Descripcion |
|---|---|---|
| [routes/api.php](routes/api.php) | MOD | Quitar el grupo `['web', UsuarioAutenticado::class]`; las rutas quedan sin exigir sesion/login (grupo `api` estandar de Laravel, stateless). |
| [app/Http/Controllers/Api/ProyectoApiController.php](app/Http/Controllers/Api/ProyectoApiController.php) | MOD | Quitar la dependencia de `Auth::id()` en `store()` (ya no hay usuario autenticado obligatorio); `created_by` se envia como `null` si no hay sesion activa. |
| [app/Http/Requests/StoreProyectoRequest.php](app/Http/Requests/StoreProyectoRequest.php) | MOD | Sobrescribir `failedValidation()` para forzar respuesta JSON 422 (evita el redirect HTML por defecto de `FormRequest` cuando la request no trae `Accept: application/json`). |
| [app/Http/Requests/UpdateProyectoRequest.php](app/Http/Requests/UpdateProyectoRequest.php) | MOD | Mismo override de `failedValidation()` para JSON 422. |
| [database/migrations/2026_08_09_215821_add_created_by_to_proyectos_table.php](database/migrations/2026_08_09_215821_add_created_by_to_proyectos_table.php) | MOD | *(alternativa evaluada, ver seccion 3)* — se descarta modificar la migracion ya ejecutada en otros entornos. |
| [database/migrations/2026_09_03_000000_make_created_by_nullable_on_proyectos_table.php](database/migrations/2026_09_03_000000_make_created_by_nullable_on_proyectos_table.php) | NEW | Nueva migracion que vuelve `created_by` nullable, ya que sin login no siempre habra un usuario que asignar. |
| [bootstrap/app.php](bootstrap/app.php) | MOD | En `withExceptions()`, forzar que cualquier excepcion (404 ruta no encontrada, 405 metodo no permitido, errores de validacion, 500) devuelva JSON cuando la URL empieza con `api/*`, en vez de la pagina de error HTML de Laravel. |
| [API_TESTS.md](API_TESTS.md) | MOD | Quitar los pasos de registro/login/cookie; los `curl` de `/api/proyectos` pasan a ser directos sin autenticacion previa. |
| [postman_collection.json](postman_collection.json) | MOD | Eliminar la carpeta `Auth` y la dependencia de cookies de sesion; las 12 requests de `Proyectos` quedan autocontenidas y ejecutables de inmediato tras importar. |

> [!NOTE]
> No se toca [routes/web.php](routes/web.php) ni `ProyectoController` (vistas Blade): ese flujo sigue exigiendo login normalmente. Solo el namespace `Api` deja de requerir sesion.

## 2. Dependencias nuevas o a actualizar

| Paquete | Version | Uso |
|---|---|---|
| — | — | No se agregan dependencias; se usan clases ya incluidas en `laravel/framework` (`Illuminate\Http\Exceptions\HttpResponseException`, `Illuminate\Foundation\Configuration\Exceptions`). |

## 3. Cambios de entorno/configuracion/base de datos

```diff
--- a/routes/api.php
+++ b/routes/api.php
-use App\Http\Middleware\UsuarioAutenticado;
 use Illuminate\Support\Facades\Route;
 
-Route::middleware(['web', UsuarioAutenticado::class])->group(function () {
-    Route::get('/proyectos', [ProyectoApiController::class, 'index'])
-    ...
-});
+Route::get('/proyectos', [ProyectoApiController::class, 'index'])->name('api.proyectos.index');
+Route::post('/proyectos', [ProyectoApiController::class, 'store'])->name('api.proyectos.store');
+Route::get('/proyectos/{id}', [ProyectoApiController::class, 'show'])->name('api.proyectos.show');
+Route::match(['put', 'patch'], '/proyectos/{id}', [ProyectoApiController::class, 'update'])->name('api.proyectos.update');
+Route::delete('/proyectos/{id}', [ProyectoApiController::class, 'destroy'])->name('api.proyectos.destroy');
```

```diff
--- a/bootstrap/app.php
+++ b/bootstrap/app.php
     ->withExceptions(function (Exceptions $exceptions): void {
-        //
+        $exceptions->shouldRenderJsonWhen(function ($request, $e) {
+            return $request->is('api/*') || $request->expectsJson();
+        });
     })->create();
```

Nueva migracion (`created_by` nullable):

```php
Schema::table('proyectos', function (Blueprint $table) {
    $table->foreignId('created_by')->nullable()->change();
});
```

> [!IMPORTANT]
> Al quitar `UsuarioAutenticado` de `routes/api.php`, los 5 endpoints quedan **publicos**. Si en otro momento se requiere proteger la API con un token (Sanctum), sera un cambio separado; por ahora se cumple literalmente "no debe pedir iniciar sesion".

## 4. Estrategia de pruebas

> [!WARNING]
> Sin BD disponible en este equipo: no se ejecutan migraciones ni `php artisan test` aqui. Verificacion solo estatica del codigo.

1. Actualizar `API_TESTS.md` y `postman_collection.json` para reflejar que ya no hace falta cookie/login:
   ```bash
   curl -i -X POST http://127.0.0.1:8000/api/proyectos \
     -H "Content-Type: application/json" -H "Accept: application/json" \
     -d '{"nombre":"Proyecto X","fecha_inicio":"2025-01-01","estado":"activo","responsable":"Ana","monto":1000}'
   ```
2. Verificar (lectura de codigo) que `StoreProyectoRequest`/`UpdateProyectoRequest` devuelvan 422 en JSON aunque el `curl` no incluya `Accept: application/json`.
3. Verificar que una ruta inexistente bajo `/api/*` (p. ej. `GET /api/no-existe`) devuelva JSON 404 en vez de la pagina HTML de error, gracias a `shouldRenderJsonWhen`.
4. En el otro equipo con BD, correr:
   ```bash
   php artisan migrate
   php artisan test --filter ProyectoApiTest
   ```

## 5. Checklist de aceptacion

**Rutas y autenticacion**
- [ ] `routes/api.php` sin `UsuarioAutenticado` ni grupo `web`; los 5 endpoints responden sin login.
- [ ] `ProyectoApiController::store` no falla si no hay usuario autenticado (`created_by` nulo permitido).

**Respuestas JSON**
- [ ] `StoreProyectoRequest`/`UpdateProyectoRequest` responden 422 JSON siempre, sin redirect HTML.
- [ ] `bootstrap/app.php` fuerza JSON en excepciones bajo `api/*` (404, 405, 500).

> [!IMPORTANT]
> Confirmar que ninguna respuesta de `/api/proyectos/*` sea una pagina HTML de Laravel (login, error 419/500) bajo ningun escenario de error.

**Base de datos**
- [ ] Nueva migracion aplica `created_by` nullable sin romper el flujo web existente (que sigue enviando `Auth::id()`).

**Documentacion**
- [ ] `API_TESTS.md` y `postman_collection.json` actualizados: sin pasos de registro/login/cookies, listos para ejecutar directo.

---
Usa los botones **Ejecutar plan** / **Descartar** en el panel de chat para continuar.
