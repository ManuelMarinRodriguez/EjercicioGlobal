# Pruebas manuales de la API de Proyectos (`curl`)

Esta guía contiene los comandos `curl` para probar los 5 endpoints REST de
`Proyecto` en un equipo con base de datos disponible. No fue ejecutada en este
equipo (sin conexión a BD); ejecútala en el otro computador siguiendo el orden
indicado.

## 0. Requisitos previos

1. Levantar el servidor local:
   ```bash
   php artisan migrate
   php artisan serve
   ```
   Por defecto queda en `http://127.0.0.1:8000`. Ajusta `BASE_URL` si usas otro host/puerto.

2. Los endpoints `/api/proyectos` son **publicos**: no requieren login ni
   cookie de sesion, y estan exentos de verificacion CSRF (ver
   `bootstrap/app.php`). Todas las respuestas (exitosas y de error) son JSON
   puro, incluyendo 404/422/500, gracias a `shouldRenderJsonWhen` en
   `bootstrap/app.php`.

3. Variable usada en los ejemplos:
   ```bash
   BASE_URL="http://127.0.0.1:8000"
   ```

## 1. `POST /api/proyectos` — Crear proyecto

### 1.1 Caso feliz (201)

```bash
curl -i -X POST "$BASE_URL/api/proyectos" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -d '{
    "nombre": "Migracion a la nube",
    "fecha_inicio": "2026-01-15",
    "estado": "En progreso",
    "responsable": "Ana Torres",
    "monto": 15000.50
  }'
```

**Esperado:** `HTTP/1.1 201 Created` con el JSON del proyecto creado (incluye
`id`, `created_by` en `null`, `created_at`, `updated_at`).

### 1.2 Caso de validación — campos vacíos (422)

```bash
curl -i -X POST "$BASE_URL/api/proyectos" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -d '{
    "nombre": "",
    "fecha_inicio": "",
    "estado": "",
    "responsable": "",
    "monto": ""
  }'
```

**Esperado:** `HTTP/1.1 422 Unprocessable Content` (JSON) con los errores de
validación de cada campo `required`.

### 1.3 Caso de validación — campos faltantes (422)

```bash
curl -i -X POST "$BASE_URL/api/proyectos" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -d '{}'
```

**Esperado:** `422` (JSON) con errores `required` para `nombre`,
`fecha_inicio`, `estado`, `responsable` y `monto`.

## 2. `GET /api/proyectos` — Listar todos los proyectos

### 2.1 Con proyectos registrados (200)

```bash
curl -i "$BASE_URL/api/proyectos" \
  -H "Accept: application/json"
```

**Esperado:** `HTTP/1.1 200 OK` con un arreglo JSON que incluye todos los
campos de cada proyecto.

### 2.2 Con la tabla vacía (200 + `[]`)

Elimina previamente todos los proyectos (ver sección 5) y repite la misma
petición:

```bash
curl -i "$BASE_URL/api/proyectos" \
  -H "Accept: application/json"
```

**Esperado:** `HTTP/1.1 200 OK` con el cuerpo `[]`.

## 3. `GET /api/proyectos/{id}` — Buscar proyecto por ID

### 3.1 ID existente (200)

```bash
ID=1

curl -i "$BASE_URL/api/proyectos/$ID" \
  -H "Accept: application/json"
```

**Esperado:** `HTTP/1.1 200 OK` con el JSON del proyecto (todos los campos).

### 3.2 ID inexistente (404)

```bash
curl -i "$BASE_URL/api/proyectos/999999" \
  -H "Accept: application/json"
```

**Esperado:** `HTTP/1.1 404 Not Found` (JSON) con
`{"message":"Proyecto no encontrado."}`.

## 4. `PUT`/`PATCH` `/api/proyectos/{id}` — Actualizar proyecto

### 4.1 ID existente (200)

```bash
ID=1

curl -i -X PUT "$BASE_URL/api/proyectos/$ID" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -d '{
    "nombre": "Migracion a la nube (fase 2)",
    "fecha_inicio": "2026-02-01",
    "estado": "Completado",
    "responsable": "Ana Torres",
    "monto": 22000.00
  }'
```

También puede probarse con `PATCH` (misma ruta, mismo controlador):

```bash
curl -i -X PATCH "$BASE_URL/api/proyectos/$ID" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -d '{
    "nombre": "Migracion a la nube (fase 2)",
    "fecha_inicio": "2026-02-01",
    "estado": "Completado",
    "responsable": "Ana Torres",
    "monto": 22000.00
  }'
```

**Esperado:** `HTTP/1.1 200 OK` con el JSON del proyecto ya actualizado
(todos los campos reflejan los nuevos valores).

### 4.2 ID inexistente (404)

```bash
curl -i -X PUT "$BASE_URL/api/proyectos/999999" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -d '{
    "nombre": "No existe",
    "fecha_inicio": "2026-02-01",
    "estado": "Completado",
    "responsable": "Ana Torres",
    "monto": 1000
  }'
```

**Esperado:** `HTTP/1.1 404 Not Found` (JSON) con
`{"message":"Proyecto no encontrado."}`.

### 4.3 Caso de validación — campos vacíos (422)

```bash
ID=1

curl -i -X PUT "$BASE_URL/api/proyectos/$ID" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -d '{
    "nombre": "",
    "fecha_inicio": "",
    "estado": "",
    "responsable": "",
    "monto": ""
  }'
```

**Esperado:** `422` (JSON) con errores `required` para cada campo.

## 5. `DELETE /api/proyectos/{id}` — Eliminar proyecto

### 5.1 ID existente (204)

```bash
ID=1

curl -i -X DELETE "$BASE_URL/api/proyectos/$ID" \
  -H "Accept: application/json"
```

**Esperado:** `HTTP/1.1 204 No Content` con cuerpo vacío.

### 5.2 ID inexistente (404)

```bash
curl -i -X DELETE "$BASE_URL/api/proyectos/999999" \
  -H "Accept: application/json"
```

**Esperado:** `HTTP/1.1 404 Not Found` (JSON) con
`{"message":"Proyecto no encontrado."}`.

## 6. Resumen de códigos esperados

| Endpoint | Caso | Código esperado |
|---|---|---|
| `POST /api/proyectos` | Datos completos y válidos | `201` |
| `POST /api/proyectos` | Campos vacíos/faltantes | `422` |
| `GET /api/proyectos` | Con datos | `200` (arreglo con todos los campos) |
| `GET /api/proyectos` | Sin datos | `200` (`[]`) |
| `GET /api/proyectos/{id}` | ID existente | `200` (todos los campos) |
| `GET /api/proyectos/{id}` | ID inexistente | `404` |
| `PUT`/`PATCH /api/proyectos/{id}` | ID existente, datos válidos | `200` (campos actualizados) |
| `PUT`/`PATCH /api/proyectos/{id}` | ID inexistente | `404` |
| `PUT`/`PATCH /api/proyectos/{id}` | Campos vacíos/faltantes | `422` |
| `DELETE /api/proyectos/{id}` | ID existente | `204` (cuerpo vacío) |
| `DELETE /api/proyectos/{id}` | ID inexistente | `404` |

> [!NOTE]
> Ningun endpoint requiere headers de autenticacion (`Cookie`, `Authorization`,
> `_token`); todas las respuestas, incluidas las de error, son JSON puro.
