<?php

namespace Tests\Feature;

use App\Models\Proyecto;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class ProyectoApiTest extends TestCase
{
    use RefreshDatabase;

    private function usuarioAutenticado(): User
    {
        return User::create([
            'nombre' => 'Usuario de Prueba',
            'correo' => 'usuario@example.com',
            'clave' => Hash::make('password'),
        ]);
    }

    private function datosProyecto(array $overrides = []): array
    {
        return array_merge([
            'nombre' => 'Proyecto de prueba',
            'fecha_inicio' => '2026-01-15',
            'estado' => 'En progreso',
            'responsable' => 'Juan Perez',
            'monto' => 1500.50,
        ], $overrides);
    }

    public function test_store_crea_un_proyecto_y_retorna_201(): void
    {
        $usuario = $this->usuarioAutenticado();

        $response = $this->actingAs($usuario)
            ->postJson('/api/proyectos', $this->datosProyecto());

        $response->assertStatus(201)
            ->assertJsonFragment([
                'nombre' => 'Proyecto de prueba',
                'estado' => 'En progreso',
                'responsable' => 'Juan Perez',
            ]);

        $this->assertDatabaseHas('proyectos', [
            'nombre' => 'Proyecto de prueba',
            'created_by' => $usuario->id,
        ]);
    }

    public function test_store_falla_con_422_si_falta_un_campo_requerido(): void
    {
        $usuario = $this->usuarioAutenticado();

        foreach (['nombre', 'fecha_inicio', 'estado', 'responsable', 'monto'] as $campo) {
            $datos = $this->datosProyecto([$campo => '']);

            $response = $this->actingAs($usuario)
                ->postJson('/api/proyectos', $datos);

            $response->assertStatus(422)
                ->assertJsonValidationErrors([$campo]);
        }
    }

    public function test_index_retorna_arreglo_vacio_cuando_no_hay_proyectos(): void
    {
        $usuario = $this->usuarioAutenticado();

        $response = $this->actingAs($usuario)->getJson('/api/proyectos');

        $response->assertStatus(200)
            ->assertExactJson([]);
    }

    public function test_index_retorna_todos_los_proyectos_con_sus_campos(): void
    {
        $usuario = $this->usuarioAutenticado();
        Proyecto::create($this->datosProyecto(['created_by' => $usuario->id]));

        $response = $this->actingAs($usuario)->getJson('/api/proyectos');

        $response->assertStatus(200)
            ->assertJsonCount(1)
            ->assertJsonFragment(['nombre' => 'Proyecto de prueba']);
    }

    public function test_show_retorna_200_con_todos_los_campos_si_existe(): void
    {
        $usuario = $this->usuarioAutenticado();
        $proyecto = Proyecto::create($this->datosProyecto(['created_by' => $usuario->id]));

        $response = $this->actingAs($usuario)->getJson("/api/proyectos/{$proyecto->id}");

        $response->assertStatus(200)
            ->assertJsonFragment([
                'id' => $proyecto->id,
                'nombre' => 'Proyecto de prueba',
                'responsable' => 'Juan Perez',
            ]);
    }

    public function test_show_retorna_404_si_el_id_no_existe(): void
    {
        $usuario = $this->usuarioAutenticado();

        $response = $this->actingAs($usuario)->getJson('/api/proyectos/999');

        $response->assertStatus(404);
    }

    public function test_update_retorna_200_con_los_campos_actualizados(): void
    {
        $usuario = $this->usuarioAutenticado();
        $proyecto = Proyecto::create($this->datosProyecto(['created_by' => $usuario->id]));

        $nuevosDatos = $this->datosProyecto([
            'nombre' => 'Proyecto actualizado',
            'estado' => 'Finalizado',
        ]);

        $response = $this->actingAs($usuario)
            ->putJson("/api/proyectos/{$proyecto->id}", $nuevosDatos);

        $response->assertStatus(200)
            ->assertJsonFragment([
                'nombre' => 'Proyecto actualizado',
                'estado' => 'Finalizado',
            ]);

        $this->assertDatabaseHas('proyectos', [
            'id' => $proyecto->id,
            'nombre' => 'Proyecto actualizado',
            'estado' => 'Finalizado',
        ]);
    }

    public function test_update_retorna_404_si_el_id_no_existe(): void
    {
        $usuario = $this->usuarioAutenticado();

        $response = $this->actingAs($usuario)
            ->putJson('/api/proyectos/999', $this->datosProyecto());

        $response->assertStatus(404);
    }

    public function test_destroy_retorna_204_con_cuerpo_vacio(): void
    {
        $usuario = $this->usuarioAutenticado();
        $proyecto = Proyecto::create($this->datosProyecto(['created_by' => $usuario->id]));

        $response = $this->actingAs($usuario)
            ->deleteJson("/api/proyectos/{$proyecto->id}");

        $response->assertStatus(204)
            ->assertNoContent();

        $this->assertDatabaseMissing('proyectos', ['id' => $proyecto->id]);
    }

    public function test_destroy_retorna_404_si_el_id_no_existe(): void
    {
        $usuario = $this->usuarioAutenticado();

        $response = $this->actingAs($usuario)
            ->deleteJson('/api/proyectos/999');

        $response->assertStatus(404);
    }
}
