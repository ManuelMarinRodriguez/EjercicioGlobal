# Community Labeling

Graphify is running in assistant/skill mode (no API key). You are the host
assistant (Claude Code / Codex / Gemini CLI). Read the community listing below
and write 2-5 word plain-language names for each.

## Language

Write every name in English (en). Do not switch languages.

## Communities

Community 0: ProyectoController, ProyectoController.php, .create(, .delete(, .destroy(, .edit(, .index(, .show(, .store(, .update(
Community 1: AuthController, AuthController.php, .login(, .logout(, .registro(, .showLogin(, .showRegistro(
Community 2: User, User.php, .casts(, .getAuthPasswordName(, .proyectos(
Community 3: UserFactory, UserFactory.php, .definition(, .unverified(
Community 4: AppServiceProvider, AppServiceProvider.php, .boot(, .register(
Community 5: UfController, UfController.php, .index(
Community 6: ExampleTest.php, ExampleTest, .test_the_application_returns_a_successful_response(
Community 7: UsuarioAutenticado, UsuarioAutenticado.php, .handle(
Community 8: 0001_01_01_000000_create_users_table.php, down(, up(
Community 9: 0001_01_01_000001_create_cache_table.php, down(, up(
Community 10: 0001_01_01_000002_create_jobs_table.php, down(, up(
Community 11: 2026_07_19_191511_create_proyectos_table.php, down(, up(
Community 12: 2026_08_09_215028_update_users_table_for_evaluacion_u2.php, down(, up(
Community 13: 2026_08_09_215821_add_created_by_to_proyectos_table.php, down(, up(
Community 14: Proyecto, Proyecto.php, .usuario(
Community 15: Usuario, Usuario.php, .proyectos(
Community 16: DatabaseSeeder.php, DatabaseSeeder, .run(
Community 17: UfService, UfService.php, .obtenerUfDelDia(
Community 18: ExampleTest.php, ExampleTest, .test_that_true_is_true(
Community 19: Controller.php, Controller
Community 20: TestCase.php, TestCase
Community 21: login.blade.php
Community 22: registro.blade.php
Community 23: app.php
Community 24: providers.php
Community 25: app.php
Community 26: auth.php
Community 27: cache.php
Community 28: database.php
Community 29: filesystems.php
Community 30: logging.php
Community 31: mail.php
Community 32: queue.php
Community 33: services.php
Community 34: session.php
Community 35: app.js
Community 36: app.blade.php
Community 37: create.blade.php
Community 38: delete.blade.php
Community 39: edit.blade.php
Community 40: index.blade.php
Community 41: show.blade.php
Community 42: index.php
Community 43: console.php
Community 44: web.php
Community 45: index.blade.php
Community 46: welcome.blade.php
Community 47: vite.config.js

## Instructions

Write a single JSON object mapping each community id (as a string) to its
2-5 word name to: c:\MMarinro\gestion-proyectos\.graphify\label-instructions\communities.json

Example:
```json
{
  "0": "Authentication Flow",
  "1": "Authentication Flow",
  "2": "Authentication Flow"
}
```

Then re-run `graphify update` (or `graphify label`) to ingest the names.
