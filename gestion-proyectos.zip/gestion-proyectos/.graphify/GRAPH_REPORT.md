# Graph Report - .  (2026-09-02)

## Corpus Check
- Corpus is ~11.084 words - fits in a single context window. You may not need a graph.

## Summary
- 103 nodes · 56 edges · 15 communities detected
- Extraction: 100% EXTRACTED · 0% INFERRED · 0% AMBIGUOUS
- Token cost: 0 input · 0 output
- Edge kinds: method: 28 · contains: 27 · calls: 1


## Input Scope
- Requested: all
- Resolved: all (source: configured-default)
- Included files: 49 · Candidates: recursive
- Excluded: 0 untracked · 0 ignored · 0 sensitive · 0 missing committed
## God Nodes (most connected - your core abstractions)
1. `ProyectoController` - 9 edges
2. `AuthController` - 6 edges
3. `User` - 4 edges
4. `AppServiceProvider` - 3 edges
5. `UserFactory` - 3 edges
6. `UfController` - 2 edges
7. `UsuarioAutenticado` - 2 edges
8. `Proyecto` - 2 edges
9. `Usuario` - 2 edges
10. `UfService` - 2 edges

## Surprising Connections (you probably didn't know these)
- None detected - all connections are within the same source files.

## Communities

### Community 0 - "Community 0"
Cohesion: 0.22
Nodes (1): ProyectoController

### Community 1 - "Community 1"
Cohesion: 0.29
Nodes (1): AuthController

### Community 2 - "Community 2"
Cohesion: 0.40
Nodes (1): User

### Community 3 - "Community 3"
Cohesion: 0.50
Nodes (1): UserFactory

### Community 4 - "Community 4"
Cohesion: 0.50
Nodes (1): AppServiceProvider

### Community 5 - "Community 5"
Cohesion: 0.67
Nodes (1): UfController

### Community 6 - "Community 6"
Cohesion: 0.67
Nodes (1): ExampleTest

### Community 7 - "Community 7"
Cohesion: 0.67
Nodes (1): UsuarioAutenticado

### Community 14 - "Community 14"
Cohesion: 0.67
Nodes (1): Proyecto

### Community 15 - "Community 15"
Cohesion: 0.67
Nodes (1): Usuario

### Community 16 - "Community 16"
Cohesion: 0.67
Nodes (1): DatabaseSeeder

### Community 17 - "Community 17"
Cohesion: 0.67
Nodes (1): UfService

### Community 18 - "Community 18"
Cohesion: 0.67
Nodes (1): ExampleTest

### Community 19 - "Community 19"
Cohesion: 1.00
Nodes (1): Controller

### Community 20 - "Community 20"
Cohesion: 1.00
Nodes (1): TestCase

## Knowledge Gaps
- **2 isolated node(s):** `Controller`, `TestCase`
  These have ≤1 connection - possible missing edges or undocumented components.
- **Thin community `Community 0`** (1 nodes): `ProyectoController`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 1`** (1 nodes): `AuthController`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 2`** (1 nodes): `User`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 3`** (1 nodes): `UserFactory`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 4`** (1 nodes): `AppServiceProvider`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 5`** (1 nodes): `UfController`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 6`** (1 nodes): `ExampleTest`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 7`** (1 nodes): `UsuarioAutenticado`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 14`** (1 nodes): `Proyecto`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 15`** (1 nodes): `Usuario`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 16`** (1 nodes): `DatabaseSeeder`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 17`** (1 nodes): `UfService`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 18`** (1 nodes): `ExampleTest`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 19`** (1 nodes): `Controller`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 20`** (1 nodes): `TestCase`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What connects `Controller`, `TestCase` to the rest of the system?**
  _2 weakly-connected nodes found - possible documentation gaps or missing edges._