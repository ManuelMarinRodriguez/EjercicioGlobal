# Node Description Batch 1 of 3

Graphify is running in assistant/skill mode (no API key). You are the host
assistant (Claude Code / Codex / Gemini CLI). Read the prompt below and write
your JSON answer to the answer file.

## Prompt

You are documenting nodes in a knowledge graph.
For each entry below, write ONE concise factual plain-language sentence
describing what it is or does. Use only the provided context.
For a code symbol (kind=code-symbol — a function, class, or constant),
describe what the function/symbol does based on its name, source location
and neighbors — e.g. "Resolves the configured ontology profile from graphify.yaml.".
Write every description in English (en). Do not switch languages.
No marketing language.
Respond ONLY with a JSON object mapping each node id (as a string) to its
one-sentence description — no prose, no markdown fences.

- "controllers_proyectocontroller_proyectocontroller": "ProyectoController" | kind=code-symbol | source=app/Http/Controllers/ProyectoController.php:L9 | neighbors=[ProyectoController.php, .create(), .delete(), .destroy(), .edit(), .index()]
- "controllers_authcontroller_authcontroller": "AuthController" | kind=code-symbol | source=app/Http/Controllers/AuthController.php:L10 | neighbors=[AuthController.php, .login(), .logout(), .registro(), .showLogin(), .showRegistro()]
- "models_user_user": "User" | kind=code-symbol | source=app/Models/User.php:L9 | neighbors=[User.php, .casts(), .getAuthPasswordName(), .proyectos()]
- "factories_userfactory_userfactory": "UserFactory" | kind=code-symbol | source=database/factories/UserFactory.php:L13 | neighbors=[UserFactory.php, .definition(), .unverified()]
- "providers_appserviceprovider_appserviceprovider": "AppServiceProvider" | kind=code-symbol | source=app/Providers/AppServiceProvider.php:L7 | neighbors=[AppServiceProvider.php, .boot(), .register()]
- "controllers_proyectocontroller_proyectocontroller_delete": ".delete()" | kind=code-symbol | source=app/Http/Controllers/ProyectoController.php:L74 | neighbors=[ProyectoController, .destroy()]
- "controllers_proyectocontroller_proyectocontroller_destroy": ".destroy()" | kind=code-symbol | source=app/Http/Controllers/ProyectoController.php:L81 | neighbors=[ProyectoController, .delete()]
- "controllers_ufcontroller_ufcontroller": "UfController" | kind=code-symbol | source=app/Http/Controllers/UfController.php:L7 | neighbors=[UfController.php, .index()]
- "feature_exampletest_exampletest": "ExampleTest" | kind=code-symbol | source=tests/Feature/ExampleTest.php:L8 | neighbors=[ExampleTest.php, .test_the_application_returns_a_success…]
- "middleware_usuarioautenticado_usuarioautenticado": "UsuarioAutenticado" | kind=code-symbol | source=app/Http/Middleware/UsuarioAutenticado.php:L10 | neighbors=[UsuarioAutenticado.php, .handle()]
- "migrations_0001_01_01_000000_create_users_table": "0001_01_01_000000_create_users_table.php" | kind=code-symbol | source=database/migrations/0001_01_01_000000_create_users_table.php:L1 | neighbors=[down(), up()]
- "migrations_0001_01_01_000001_create_cache_table": "0001_01_01_000001_create_cache_table.php" | kind=code-symbol | source=database/migrations/0001_01_01_000001_create_cache_table.php:L1 | neighbors=[down(), up()]
- "migrations_0001_01_01_000002_create_jobs_table": "0001_01_01_000002_create_jobs_table.php" | kind=code-symbol | source=database/migrations/0001_01_01_000002_create_jobs_table.php:L1 | neighbors=[down(), up()]
- "migrations_2026_07_19_191511_create_proyectos_table": "2026_07_19_191511_create_proyectos_table.php" | kind=code-symbol | source=database/migrations/2026_07_19_191511_create_proyectos_table.php:L1 | neighbors=[down(), up()]
- "migrations_2026_08_09_215028_update_users_table_for_evaluacion_u2": "2026_08_09_215028_update_users_table_for_evaluacion_u2.php" | kind=code-symbol | source=database/migrations/2026_08_09_215028_update_users_table_for_evaluacion_u2.php:L1 | neighbors=[down(), up()]
- "migrations_2026_08_09_215821_add_created_by_to_proyectos_table": "2026_08_09_215821_add_created_by_to_proyectos_table.php" | kind=code-symbol | source=database/migrations/2026_08_09_215821_add_created_by_to_proyectos_table.php:L1 | neighbors=[down(), up()]
- "models_proyecto_proyecto": "Proyecto" | kind=code-symbol | source=app/Models/Proyecto.php:L7 | neighbors=[Proyecto.php, .usuario()]
- "models_usuario_usuario": "Usuario" | kind=code-symbol | source=app/Models/Usuario.php:L7 | neighbors=[Usuario.php, .proyectos()]
- "seeders_databaseseeder_databaseseeder": "DatabaseSeeder" | kind=code-symbol | source=database/seeders/DatabaseSeeder.php:L9 | neighbors=[DatabaseSeeder.php, .run()]
- "services_ufservice_ufservice": "UfService" | kind=code-symbol | source=app/Services/UfService.php:L5 | neighbors=[UfService.php, .obtenerUfDelDia()]
- "unit_exampletest_exampletest": "ExampleTest" | kind=code-symbol | source=tests/Unit/ExampleTest.php:L7 | neighbors=[ExampleTest.php, .test_that_true_is_true()]
- "controllers_authcontroller": "AuthController.php" | kind=code-symbol | source=app/Http/Controllers/AuthController.php:L1 | neighbors=[AuthController]
- "controllers_authcontroller_authcontroller_login": ".login()" | kind=code-symbol | source=app/Http/Controllers/AuthController.php:L54 | neighbors=[AuthController]
- "controllers_authcontroller_authcontroller_logout": ".logout()" | kind=code-symbol | source=app/Http/Controllers/AuthController.php:L81 | neighbors=[AuthController]
- "controllers_authcontroller_authcontroller_registro": ".registro()" | kind=code-symbol | source=app/Http/Controllers/AuthController.php:L23 | neighbors=[AuthController]
- "controllers_authcontroller_authcontroller_showlogin": ".showLogin()" | kind=code-symbol | source=app/Http/Controllers/AuthController.php:L46 | neighbors=[AuthController]
- "controllers_authcontroller_authcontroller_showregistro": ".showRegistro()" | kind=code-symbol | source=app/Http/Controllers/AuthController.php:L15 | neighbors=[AuthController]
- "controllers_controller": "Controller.php" | kind=code-symbol | source=app/Http/Controllers/Controller.php:L1 | neighbors=[Controller]
- "controllers_controller_controller": "Controller" | kind=code-symbol | source=app/Http/Controllers/Controller.php:L5 | neighbors=[Controller.php]
- "controllers_proyectocontroller": "ProyectoController.php" | kind=code-symbol | source=app/Http/Controllers/ProyectoController.php:L1 | neighbors=[ProyectoController]
- "controllers_proyectocontroller_proyectocontroller_create": ".create()" | kind=code-symbol | source=app/Http/Controllers/ProyectoController.php:L18 | neighbors=[ProyectoController]
- "controllers_proyectocontroller_proyectocontroller_edit": ".edit()" | kind=code-symbol | source=app/Http/Controllers/ProyectoController.php:L49 | neighbors=[ProyectoController]
- "controllers_proyectocontroller_proyectocontroller_index": ".index()" | kind=code-symbol | source=app/Http/Controllers/ProyectoController.php:L11 | neighbors=[ProyectoController]
- "controllers_proyectocontroller_proyectocontroller_show": ".show()" | kind=code-symbol | source=app/Http/Controllers/ProyectoController.php:L42 | neighbors=[ProyectoController]
- "controllers_proyectocontroller_proyectocontroller_store": ".store()" | kind=code-symbol | source=app/Http/Controllers/ProyectoController.php:L23 | neighbors=[ProyectoController]
- "controllers_proyectocontroller_proyectocontroller_update": ".update()" | kind=code-symbol | source=app/Http/Controllers/ProyectoController.php:L56 | neighbors=[ProyectoController]
- "controllers_ufcontroller": "UfController.php" | kind=code-symbol | source=app/Http/Controllers/UfController.php:L1 | neighbors=[UfController]
- "controllers_ufcontroller_ufcontroller_index": ".index()" | kind=code-symbol | source=app/Http/Controllers/UfController.php:L9 | neighbors=[UfController]
- "factories_userfactory": "UserFactory.php" | kind=code-symbol | source=database/factories/UserFactory.php:L1 | neighbors=[UserFactory]
- "factories_userfactory_userfactory_definition": ".definition()" | kind=code-symbol | source=database/factories/UserFactory.php:L25 | neighbors=[UserFactory]

## Instructions

Write a single JSON object mapping each node id to a one-sentence description
to: c:\MMarinro\gestion-proyectos\.graphify\description-instructions\batch-000.json

Keep each description factual and concise (one sentence). No markdown, no prose
outside the JSON object. It is acceptable to omit a node if context is
insufficient — but include every node you can ground confidently.

Example answer format:
```json
{
  "node_id_1": "Resolves the configured ontology profile from graphify.yaml.",
  "node_id_2": "Colonel James Barclay, an antagonist in The Crooked Man."
}
```
