# Node Description Batch 3 of 3

Graphify is running in assistant/skill mode (no API key). You are the host
assistant (Claude Code / Codex / Gemini CLI). Read the prompt below and write
your JSON answer to the answer file.

## Prompt

You are documenting nodes in a knowledge graph.
For each entry below, write ONE concise factual plain-language sentence
describing what it is or does. Use only the provided context.
For a code symbol (kind=code-symbol — a function, class, or constant),
describe what the function/symbol does based on its name, source location
and neighbors — e.g. "Resolves the configured ontology profile from graphify.yaml.".
Write every description in English (en). Do not switch languages.
No marketing language.
Respond ONLY with a JSON object mapping each node id (as a string) to its
one-sentence description — no prose, no markdown fences.

- "config_app": "app.php" | kind=code-symbol | source=config/app.php:L1
- "config_auth": "auth.php" | kind=code-symbol | source=config/auth.php:L1
- "config_cache": "cache.php" | kind=code-symbol | source=config/cache.php:L1
- "config_database": "database.php" | kind=code-symbol | source=config/database.php:L1
- "config_filesystems": "filesystems.php" | kind=code-symbol | source=config/filesystems.php:L1
- "config_logging": "logging.php" | kind=code-symbol | source=config/logging.php:L1
- "config_mail": "mail.php" | kind=code-symbol | source=config/mail.php:L1
- "config_queue": "queue.php" | kind=code-symbol | source=config/queue.php:L1
- "config_services": "services.php" | kind=code-symbol | source=config/services.php:L1
- "config_session": "session.php" | kind=code-symbol | source=config/session.php:L1
- "js_app": "app.js" | kind=code-symbol | source=resources/js/app.js:L1
- "layouts_app_blade": "app.blade.php" | kind=code-symbol | source=resources/views/layouts/app.blade.php:L1
- "proyectos_create_blade": "create.blade.php" | kind=code-symbol | source=resources/views/proyectos/create.blade.php:L1
- "proyectos_delete_blade": "delete.blade.php" | kind=code-symbol | source=resources/views/proyectos/delete.blade.php:L1
- "proyectos_edit_blade": "edit.blade.php" | kind=code-symbol | source=resources/views/proyectos/edit.blade.php:L1
- "proyectos_index_blade": "index.blade.php" | kind=code-symbol | source=resources/views/proyectos/index.blade.php:L1
- "proyectos_show_blade": "show.blade.php" | kind=code-symbol | source=resources/views/proyectos/show.blade.php:L1
- "public_index": "index.php" | kind=code-symbol | source=public/index.php:L1
- "routes_console": "console.php" | kind=code-symbol | source=routes/console.php:L1
- "routes_web": "web.php" | kind=code-symbol | source=routes/web.php:L1
- "uf_index_blade": "index.blade.php" | kind=code-symbol | source=resources/views/uf/index.blade.php:L1
- "views_welcome_blade": "welcome.blade.php" | kind=code-symbol | source=resources/views/welcome.blade.php:L1
- "vite_config": "vite.config.js" | kind=code-symbol | source=vite.config.js:L1

## Instructions

Write a single JSON object mapping each node id to a one-sentence description
to: c:\MMarinro\gestion-proyectos\.graphify\description-instructions\batch-002.json

Keep each description factual and concise (one sentence). No markdown, no prose
outside the JSON object. It is acceptable to omit a node if context is
insufficient — but include every node you can ground confidently.

Example answer format:
```json
{
  "node_id_1": "Resolves the configured ontology profile from graphify.yaml.",
  "node_id_2": "Colonel James Barclay, an antagonist in The Crooked Man."
}
```
