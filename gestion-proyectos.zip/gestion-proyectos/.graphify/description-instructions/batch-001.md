# Node Description Batch 2 of 3

Graphify is running in assistant/skill mode (no API key). You are the host
assistant (Claude Code / Codex / Gemini CLI). Read the prompt below and write
your JSON answer to the answer file.

## Prompt

You are documenting nodes in a knowledge graph.
For each entry below, write ONE concise factual plain-language sentence
describing what it is or does. Use only the provided context.
For a code symbol (kind=code-symbol — a function, class, or constant),
describe what the function/symbol does based on its name, source location
and neighbors — e.g. "Resolves the configured ontology profile from graphify.yaml.".
Write every description in English (en). Do not switch languages.
No marketing language.
Respond ONLY with a JSON object mapping each node id (as a string) to its
one-sentence description — no prose, no markdown fences.

- "factories_userfactory_userfactory_unverified": ".unverified()" | kind=code-symbol | source=database/factories/UserFactory.php:L39 | neighbors=[UserFactory]
- "feature_exampletest": "ExampleTest.php" | kind=code-symbol | source=tests/Feature/ExampleTest.php:L1 | neighbors=[ExampleTest]
- "feature_exampletest_exampletest_test_the_application_returns_a_successful_response": ".test_the_application_returns_a_successful_response()" | kind=code-symbol | source=tests/Feature/ExampleTest.php:L13 | neighbors=[ExampleTest]
- "middleware_usuarioautenticado": "UsuarioAutenticado.php" | kind=code-symbol | source=app/Http/Middleware/UsuarioAutenticado.php:L1 | neighbors=[UsuarioAutenticado]
- "middleware_usuarioautenticado_usuarioautenticado_handle": ".handle()" | kind=code-symbol | source=app/Http/Middleware/UsuarioAutenticado.php:L15 | neighbors=[UsuarioAutenticado]
- "migrations_0001_01_01_000000_create_users_table_down": "down()" | kind=code-symbol | source=database/migrations/0001_01_01_000000_create_users_table.php:L43 | neighbors=[0001_01_01_000000_create_users_table.php]
- "migrations_0001_01_01_000000_create_users_table_up": "up()" | kind=code-symbol | source=database/migrations/0001_01_01_000000_create_users_table.php:L12 | neighbors=[0001_01_01_000000_create_users_table.php]
- "migrations_0001_01_01_000001_create_cache_table_down": "down()" | kind=code-symbol | source=database/migrations/0001_01_01_000001_create_cache_table.php:L30 | neighbors=[0001_01_01_000001_create_cache_table.php]
- "migrations_0001_01_01_000001_create_cache_table_up": "up()" | kind=code-symbol | source=database/migrations/0001_01_01_000001_create_cache_table.php:L12 | neighbors=[0001_01_01_000001_create_cache_table.php]
- "migrations_0001_01_01_000002_create_jobs_table_down": "down()" | kind=code-symbol | source=database/migrations/0001_01_01_000002_create_jobs_table.php:L53 | neighbors=[0001_01_01_000002_create_jobs_table.php]
- "migrations_0001_01_01_000002_create_jobs_table_up": "up()" | kind=code-symbol | source=database/migrations/0001_01_01_000002_create_jobs_table.php:L12 | neighbors=[0001_01_01_000002_create_jobs_table.php]
- "migrations_2026_07_19_191511_create_proyectos_table_down": "down()" | kind=code-symbol | source=database/migrations/2026_07_19_191511_create_proyectos_table.php:L22 | neighbors=[2026_07_19_191511_create_proyectos_tabl…]
- "migrations_2026_07_19_191511_create_proyectos_table_up": "up()" | kind=code-symbol | source=database/migrations/2026_07_19_191511_create_proyectos_table.php:L9 | neighbors=[2026_07_19_191511_create_proyectos_tabl…]
- "migrations_2026_08_09_215028_update_users_table_for_evaluacion_u2_down": "down()" | kind=code-symbol | source=database/migrations/2026_08_09_215028_update_users_table_for_evaluacion_u2.php:L24 | neighbors=[2026_08_09_215028_update_users_table_fo…]
- "migrations_2026_08_09_215028_update_users_table_for_evaluacion_u2_up": "up()" | kind=code-symbol | source=database/migrations/2026_08_09_215028_update_users_table_for_evaluacion_u2.php:L12 | neighbors=[2026_08_09_215028_update_users_table_fo…]
- "migrations_2026_08_09_215821_add_created_by_to_proyectos_table_down": "down()" | kind=code-symbol | source=database/migrations/2026_08_09_215821_add_created_by_to_proyectos_table.php:L25 | neighbors=[2026_08_09_215821_add_created_by_to_pro…]
- "migrations_2026_08_09_215821_add_created_by_to_proyectos_table_up": "up()" | kind=code-symbol | source=database/migrations/2026_08_09_215821_add_created_by_to_proyectos_table.php:L12 | neighbors=[2026_08_09_215821_add_created_by_to_pro…]
- "models_proyecto": "Proyecto.php" | kind=code-symbol | source=app/Models/Proyecto.php:L1 | neighbors=[Proyecto]
- "models_proyecto_proyecto_usuario": ".usuario()" | kind=code-symbol | source=app/Models/Proyecto.php:L20 | neighbors=[Proyecto]
- "models_user": "User.php" | kind=code-symbol | source=app/Models/User.php:L1 | neighbors=[User]
- "models_user_user_casts": ".casts()" | kind=code-symbol | source=app/Models/User.php:L42 | neighbors=[User]
- "models_user_user_getauthpasswordname": ".getAuthPasswordName()" | kind=code-symbol | source=app/Models/User.php:L29 | neighbors=[User]
- "models_user_user_proyectos": ".proyectos()" | kind=code-symbol | source=app/Models/User.php:L37 | neighbors=[User]
- "models_usuario": "Usuario.php" | kind=code-symbol | source=app/Models/Usuario.php:L1 | neighbors=[Usuario]
- "models_usuario_usuario_proyectos": ".proyectos()" | kind=code-symbol | source=app/Models/Usuario.php:L21 | neighbors=[Usuario]
- "providers_appserviceprovider": "AppServiceProvider.php" | kind=code-symbol | source=app/Providers/AppServiceProvider.php:L1 | neighbors=[AppServiceProvider]
- "providers_appserviceprovider_appserviceprovider_boot": ".boot()" | kind=code-symbol | source=app/Providers/AppServiceProvider.php:L20 | neighbors=[AppServiceProvider]
- "providers_appserviceprovider_appserviceprovider_register": ".register()" | kind=code-symbol | source=app/Providers/AppServiceProvider.php:L12 | neighbors=[AppServiceProvider]
- "seeders_databaseseeder": "DatabaseSeeder.php" | kind=code-symbol | source=database/seeders/DatabaseSeeder.php:L1 | neighbors=[DatabaseSeeder]
- "seeders_databaseseeder_databaseseeder_run": ".run()" | kind=code-symbol | source=database/seeders/DatabaseSeeder.php:L16 | neighbors=[DatabaseSeeder]
- "services_ufservice": "UfService.php" | kind=code-symbol | source=app/Services/UfService.php:L1 | neighbors=[UfService]
- "services_ufservice_ufservice_obtenerufdeldia": ".obtenerUfDelDia()" | kind=code-symbol | source=app/Services/UfService.php:L7 | neighbors=[UfService]
- "tests_testcase": "TestCase.php" | kind=code-symbol | source=tests/TestCase.php:L1 | neighbors=[TestCase]
- "tests_testcase_testcase": "TestCase" | kind=code-symbol | source=tests/TestCase.php:L7 | neighbors=[TestCase.php]
- "unit_exampletest": "ExampleTest.php" | kind=code-symbol | source=tests/Unit/ExampleTest.php:L1 | neighbors=[ExampleTest]
- "unit_exampletest_exampletest_test_that_true_is_true": ".test_that_true_is_true()" | kind=code-symbol | source=tests/Unit/ExampleTest.php:L12 | neighbors=[ExampleTest]
- "auth_login_blade": "login.blade.php" | kind=code-symbol | source=resources/views/auth/login.blade.php:L1
- "auth_registro_blade": "registro.blade.php" | kind=code-symbol | source=resources/views/auth/registro.blade.php:L1
- "bootstrap_app": "app.php" | kind=code-symbol | source=bootstrap/app.php:L1
- "bootstrap_providers": "providers.php" | kind=code-symbol | source=bootstrap/providers.php:L1

## Instructions

Write a single JSON object mapping each node id to a one-sentence description
to: c:\MMarinro\gestion-proyectos\.graphify\description-instructions\batch-001.json

Keep each description factual and concise (one sentence). No markdown, no prose
outside the JSON object. It is acceptable to omit a node if context is
insufficient — but include every node you can ground confidently.

Example answer format:
```json
{
  "node_id_1": "Resolves the configured ontology profile from graphify.yaml.",
  "node_id_2": "Colonel James Barclay, an antagonist in The Crooked Man."
}
```
