<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Registro de Usuario</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .contenedor {
            width: 100%;
            max-width: 430px;
            padding: 20px;
        }

        .tarjeta {
            background: white;
            padding: 35px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.12);
        }

        h1 {
            text-align: center;
            margin-bottom: 10px;
            color: #1f2937;
        }

        .subtitulo {
            text-align: center;
            color: #6b7280;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
            color: #374151;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-bottom: 18px;
            border: 1px solid #d1d5db;
            border-radius: 7px;
            font-size: 15px;
        }

        input:focus {
            outline: none;
            border-color: #2563eb;
        }

        button {
            width: 100%;
            padding: 13px;
            border: none;
            border-radius: 7px;
            background: #2563eb;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #1d4ed8;
        }

        .errores {
            background: #fee2e2;
            color: #991b1b;
            padding: 12px;
            border-radius: 7px;
            margin-bottom: 20px;
        }

        .enlace {
            text-align: center;
            margin-top: 20px;
        }

        .enlace a {
            color: #2563eb;
            text-decoration: none;
        }
    </style>
</head>

<body>

<div class="contenedor">

    <div class="tarjeta">

        <h1>Crear cuenta</h1>

        <p class="subtitulo">
            Registro de usuario
        </p>

        @if ($errors->any())
            <div class="errores">
                <strong>Revisa los siguientes errores:</strong>

                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ url('/registro') }}" method="POST">

            @csrf

            <label for="nombre">Nombre</label>

            <input
                type="text"
                id="nombre"
                name="nombre"
                value="{{ old('nombre') }}"
                required
            >

            <label for="correo">Correo</label>

            <input
                type="email"
                id="correo"
                name="correo"
                value="{{ old('correo') }}"
                required
            >

            <label for="clave">Clave</label>

            <input
                type="password"
                id="clave"
                name="clave"
                required
            >

            <label for="clave_confirmation">
                Confirmar clave
            </label>

            <input
                type="password"
                id="clave_confirmation"
                name="clave_confirmation"
                required
            >

            <button type="submit">
                Registrarme
            </button>

        </form>

        <div class="enlace">
            ¿Ya tienes una cuenta?
            <a href="{{ url('/login') }}">
                Iniciar sesión
            </a>
        </div>

    </div>

</div>

</body>
</html>
