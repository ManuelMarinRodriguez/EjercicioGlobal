@extends('layouts.app')

@section('content')
    <h1>Crear Proyecto</h1>

    <form action="{{ route('proyectos.store') }}" method="POST">
        @csrf

        <label>Nombre</label>
        <input type="text" name="nombre" value="{{ old('nombre') }}">
        @error('nombre')
            <div class="error">{{ $message }}</div>
        @enderror

        <label>Fecha de Inicio</label>
        <input type="date" name="fecha_inicio" value="{{ old('fecha_inicio') }}">
        @error('fecha_inicio')
            <div class="error">{{ $message }}</div>
        @enderror

        <label>Estado</label>
        <input type="text" name="estado" value="{{ old('estado') }}">
        @error('estado')
            <div class="error">{{ $message }}</div>
        @enderror

        <label>Responsable</label>
        <input type="text" name="responsable" value="{{ old('responsable') }}">
        @error('responsable')
            <div class="error">{{ $message }}</div>
        @enderror

        <label>Monto</label>
        <input type="number" step="0.01" name="monto" value="{{ old('monto') }}">
        @error('monto')
            <div class="error">{{ $message }}</div>
        @enderror

        <button type="submit">Guardar Proyecto</button>
    </form>
@endsection
