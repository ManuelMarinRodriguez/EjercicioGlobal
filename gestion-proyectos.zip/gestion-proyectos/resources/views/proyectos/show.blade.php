@extends('layouts.app')

@section('content')
    <h1>Detalle del Proyecto</h1>

    <p><strong>ID:</strong> {{ $proyecto->id }}</p>
    <p><strong>Nombre:</strong> {{ $proyecto->nombre }}</p>
    <p><strong>Fecha de Inicio:</strong> {{ $proyecto->fecha_inicio }}</p>
    <p><strong>Estado:</strong> {{ $proyecto->estado }}</p>
    <p><strong>Responsable:</strong> {{ $proyecto->responsable }}</p>
    <p><strong>Monto:</strong> ${{ number_format($proyecto->monto, 0, ',', '.') }}</p>

    <a class="btn btn-secondary" href="{{ route('proyectos.index') }}">Volver</a>
@endsection
