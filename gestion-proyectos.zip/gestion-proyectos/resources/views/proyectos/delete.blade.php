@extends('layouts.app')

@section('content')
    <h1>Eliminar Proyecto</h1>

    <p>¿Estás seguro de eliminar el proyecto <strong>{{ $proyecto->nombre }}</strong>?</p>

    <form action="{{ route('proyectos.destroy', $proyecto->id) }}" method="POST">
        @csrf
        @method('DELETE')
        <button type="submit" class="btn btn-danger">Eliminar</button>
        <a href="{{ route('proyectos.index') }}" class="btn btn-secondary">Cancelar</a>
    </form>
@endsection
