@extends('layouts.app')

@section('content')
    <h1>Editar Proyecto</h1>

    <form action="{{ route('proyectos.update', $proyecto->id) }}" method="POST">
        @csrf
        @method('PUT')

        <label>Nombre</label>
        <input type="text" name="nombre" value="{{ old('nombre', $proyecto->nombre) }}">
        @error('nombre')
            <div class="error">{{ $message }}</div>
        @enderror

        <label>Fecha de Inicio</label>
        <input type="date" name="fecha_inicio" value="{{ old('fecha_inicio', $proyecto->fecha_inicio) }}">
        @error('fecha_inicio')
            <div class="error">{{ $message }}</div>
        @enderror

        <label>Estado</label>
        <input type="text" name="estado" value="{{ old('estado', $proyecto->estado) }}">
        @error('estado')
            <div class="error">{{ $message }}</div>
        @enderror

        <label>Responsable</label>
        <input type="text" name="responsable" value="{{ old('responsable', $proyecto->responsable) }}">
        @error('responsable')
            <div class="error">{{ $message }}</div>
        @enderror

        <label>Monto</label>
        <input type="number" step="0.01" name="monto" value="{{ old('monto', $proyecto->monto) }}">
        @error('monto')
            <div class="error">{{ $message }}</div>
        @enderror

        <button type="submit">Actualizar Proyecto</button>
    </form>
@endsection
