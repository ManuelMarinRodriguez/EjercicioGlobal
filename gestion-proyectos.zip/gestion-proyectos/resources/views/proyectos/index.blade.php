<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Gestión de Proyectos</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px;
            font-family: Arial, sans-serif;
            background: #f4f6f8;
        }

        .contenedor {
            max-width: 1100px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.10);
        }

        .menu {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            padding-bottom: 12px;
            border-bottom: 1px solid #ccc;
            margin-bottom: 10px;
        }

        .menu a {
            color: #2563eb;
            text-decoration: none;
            font-weight: bold;
            font-size: 16px;
        }

        .menu a:hover {
            text-decoration: underline;
        }

        .logout-form {
            display: inline;
            margin-left: auto;
        }

        .logout-button {
            background: #dc3545;
            color: white;
            border: none;
            padding: 9px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 15px;
        }

        .logout-button:hover {
            background: #b02a37;
        }

        .mensaje {
            background: #d1e7dd;
            color: #0f5132;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .titulo {
            font-size: 32px;
            margin-bottom: 25px;
            color: #111827;
        }

        .sin-proyectos {
            font-size: 16px;
            color: #374151;
        }

        .tabla-contenedor {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th,
        td {
            border: 1px solid #ccc;
            padding: 12px;
            text-align: left;
        }

        th {
            background: #f8f9fa;
            font-weight: bold;
        }

        .btn {
            display: inline-block;
            padding: 8px 12px;
            border-radius: 5px;
            text-decoration: none;
            color: white;
            font-size: 14px;
            margin-right: 4px;
        }

        .btn-ver {
            background: #0d6efd;
        }

        .btn-editar {
            background: #ffc107;
            color: #212529;
        }

        .btn-eliminar {
            background: #dc3545;
        }

        .btn:hover {
            opacity: 0.85;
        }

        @media (max-width: 700px) {
            body {
                padding: 15px;
            }

            .contenedor {
                padding: 20px;
            }

            .titulo {
                font-size: 26px;
            }

            .logout-form {
                margin-left: 0;
            }

            .menu {
                gap: 12px;
            }
        }
    </style>
</head>

<body>

<div class="contenedor">

    <!-- MENÚ PRINCIPAL -->
    <nav class="menu">

        <a href="{{ route('proyectos.index') }}">
            Proyectos
        </a>

        <a href="{{ route('proyectos.create') }}">
            Crear Proyecto
        </a>

        <a href="{{ route('uf.index') }}">
            Ver UF del Día
        </a>

        <!-- CERRAR SESIÓN -->
        <form
            action="{{ route('logout') }}"
            method="POST"
            class="logout-form"
        >
            @csrf

            <button
                type="submit"
                class="logout-button"
            >
                Cerrar sesión
            </button>
        </form>

    </nav>

    <!-- MENSAJE DE ÉXITO -->
    @if (session('success'))
        <div class="mensaje">
            {{ session('success') }}
        </div>
    @endif

    <!-- TÍTULO -->
    <h1 class="titulo">
        Listado de Proyectos
    </h1>

    <!-- LISTADO -->
    @if ($proyectos->count() > 0)

        <div class="tabla-contenedor">

            <table>

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Fecha Inicio</th>
                        <th>Estado</th>
                        <th>Responsable</th>
                        <th>Monto</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>

                    @foreach ($proyectos as $proyecto)

                        <tr>

                            <td>
                                {{ $proyecto->id }}
                            </td>

                            <td>
                                {{ $proyecto->nombre }}
                            </td>

                            <td>
                                {{ $proyecto->fecha_inicio }}
                            </td>

                            <td>
                                {{ $proyecto->estado }}
                            </td>

                            <td>
                                {{ $proyecto->responsable }}
                            </td>

                            <td>
                                ${{ number_format($proyecto->monto, 0, ',', '.') }}
                            </td>

                            <td>

                                <a
                                    href="{{ route('proyectos.show', $proyecto->id) }}"
                                    class="btn btn-ver"
                                >
                                    Ver
                                </a>

                                <a
                                    href="{{ route('proyectos.edit', $proyecto->id) }}"
                                    class="btn btn-editar"
                                >
                                    Editar
                                </a>

                                <a
                                    href="{{ route('proyectos.delete', $proyecto->id) }}"
                                    class="btn btn-eliminar"
                                >
                                    Eliminar
                                </a>

                            </td>

                        </tr>

                    @endforeach

                </tbody>

            </table>

        </div>

    @else

        <p class="sin-proyectos">
            No hay proyectos registrados.
        </p>

    @endif

</div>

</body>
</html>
