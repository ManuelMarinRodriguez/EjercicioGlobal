@extends('layouts.app')

@section('content')
    <h1>Valor de la UF del Día</h1>
    <p>El valor simulado de la UF es: <strong>${{ number_format($uf, 2, ',', '.') }}</strong></p>
@endsection
