# Diagnostico: la API responde HTML/login en vez de JSON

Esta guia es para el equipo con base de datos disponible, cuando la API
`/api/proyectos` parece exigir inicio de sesion o devuelve una pagina HTML en
vez de JSON. Sigue los pasos en orden.

## 1. Limpiar caches antes de cualquier prueba

Una cache de rutas o configuracion vieja puede seguir sirviendo codigo
anterior aunque el repositorio ya este corregido:

```bash
php artisan route:clear
php artisan config:clear
php artisan cache:clear
php artisan serve
```

Repite las pruebas de este documento **despues** de limpiar caches, no antes.

## 2. Confirmar que estas usando la URL correcta

Hay dos rutas que se parecen pero son completamente distintas:

| Ruta | Archivo | Protegida por sesion | Formato de respuesta |
|---|---|---|---|
| `/proyectos` | `routes/web.php` | Si (login requerido) | HTML (vistas Blade) |
| `/api/proyectos` | `routes/api.php` | No (publica) | JSON |

```bash
# Vista web (HTML, redirect a /login si no hay sesion) - esto es esperado
curl -i http://127.0.0.1:8000/proyectos

# API (JSON, sin login) - esta es la ruta correcta para consumir desde Postman/curl
curl -i http://127.0.0.1:8000/api/proyectos
```

Si estas probando `/proyectos` (sin `/api`) y ves HTML o un redirect a
`/login`, **no es un bug**: esa vista siempre requiere sesion. Usa siempre el
prefijo `/api`.

## 3. Diagnostico minimo sin controlador

```bash
curl -i http://127.0.0.1:8000/api/ping
```

**Esperado:** `200 OK`, `Content-Type: application/json`, body `{"ok":true}`.

Esta ruta no pasa por ningun controlador ni Form Request; si falla o
devuelve HTML, el problema es de infraestructura (middleware, cache, servidor
web) y no de un endpoint en particular.

## 4. Confirmar el endpoint real sin ningun header adicional

```bash
curl -i http://127.0.0.1:8000/api/proyectos
```

**Esperado:** `200 OK`, `Content-Type: application/json`, sin encabezado
`Location: /login` en la respuesta.

## 5. Confirmar una ruta inexistente bajo `/api`

```bash
curl -i http://127.0.0.1:8000/api/ruta-inexistente
```

**Esperado:** `404 Not Found` (JSON, gracias a `Route::fallback()` en
`routes/api.php`), nunca la pagina de error HTML de Laravel.

## 6. Por que el codigo ya no puede iniciar sesion

- `routes/api.php`: ninguna ruta usa el middleware `web` ni `UsuarioAutenticado`.
- `bootstrap/app.php`: el grupo de middleware `api` esta redefinido
  explicitamente con solo `SubstituteBindings` y `ThrottleRequests` — sin
  `StartSession`, `EncryptCookies`, `VerifyCsrfToken` ni `Authenticate`.
- `app/Http/Middleware/ForceJsonResponse.php`: fuerza `Accept: application/json`
  en cada request bajo `/api/*`, para que ninguna respuesta pueda degradar a
  HTML sin importar los headers que envie el cliente.
- `bootstrap/app.php` (`shouldRenderJsonWhen`): fuerza JSON en cualquier
  excepcion (404, 405, 422, 500) cuando la URL empieza con `api/*`.

## 7. Si el problema persiste

Ejecuta la coleccion Postman completa (`postman_collection.json`) con el
Runner y revisa visualmente el `Content-Type` de cada respuesta. Si alguna
muestra `text/html`, copia la respuesta completa (`curl -i`, con headers) para
identificar el endpoint exacto afectado.
