<?php

use App\Http\Controllers\Api\ProyectoApiController;
use App\Http\Middleware\ForceJsonResponse;
use Illuminate\Support\Facades\Route;

Route::middleware(ForceJsonResponse::class)->group(function () {
    Route::get('/ping', fn () => response()->json(['ok' => true]))
        ->name('api.ping');

    Route::get('/proyectos', [ProyectoApiController::class, 'index'])
        ->name('api.proyectos.index');

    Route::post('/proyectos', [ProyectoApiController::class, 'store'])
        ->name('api.proyectos.store');

    Route::get('/proyectos/{id}', [ProyectoApiController::class, 'show'])
        ->name('api.proyectos.show');

    Route::match(['put', 'patch'], '/proyectos/{id}', [ProyectoApiController::class, 'update'])
        ->name('api.proyectos.update');

    Route::delete('/proyectos/{id}', [ProyectoApiController::class, 'destroy'])
        ->name('api.proyectos.destroy');
});

Route::fallback(function () {
    return response()->json([
        'message' => 'Ruta no encontrada.',
    ], 404);
});
