<?php

use App\Http\Controllers\Api\ProyectoApiController;
use App\Http\Middleware\ForceJsonResponse;
use Illuminate\Support\Facades\Route;

// fuerzo que todo lo de aca responda siempre en JSON, aunque
// pidan la ruta desde el navegador
Route::middleware(ForceJsonResponse::class)->group(function () {
    // ruta de prueba nomas, para saber que la api esta viva
    Route::get('/ping', fn () => response()->json(['ok' => true]))
        ->name('api.ping');

    // CRUD de proyectos pero version API (JSON)
    Route::get('/proyectos', [ProyectoApiController::class, 'index'])
        ->name('api.proyectos.index');

    Route::post('/proyectos', [ProyectoApiController::class, 'store'])
        ->name('api.proyectos.store');

    Route::get('/proyectos/{id}', [ProyectoApiController::class, 'show'])
        ->name('api.proyectos.show');

    Route::match(['put', 'patch'], '/proyectos/{id}', [ProyectoApiController::class, 'update'])
        ->name('api.proyectos.update');

    Route::delete('/proyectos/{id}', [ProyectoApiController::class, 'destroy'])
        ->name('api.proyectos.destroy');
});

// si piden cualquier otra ruta de la api que no existe, respondo
// json en vez de la pagina de error 404 normal de laravel
Route::fallback(function () {
    return response()->json([
        'message' => 'Ruta no encontrada.',
    ], 404);
});
