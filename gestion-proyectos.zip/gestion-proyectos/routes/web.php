<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProyectoController;
use App\Http\Controllers\UfController;
use App\Http\Controllers\AuthController;
use App\Http\Middleware\UsuarioAutenticado;


// Página principal
Route::get('/', function () {
    return redirect()->route('proyectos.index');
});


// ================================
// AUTENTICACIÓN
// ================================

Route::get('/registro', [AuthController::class, 'showRegistro'])
    ->name('registro');

Route::post('/registro', [AuthController::class, 'registro']);

Route::get('/login', [AuthController::class, 'showLogin'])
    ->name('login');

Route::post('/login', [AuthController::class, 'login']);

Route::post('/logout', [AuthController::class, 'logout'])
    ->name('logout');


// ================================
// RUTAS PROTEGIDAS
// ================================

Route::middleware(UsuarioAutenticado::class)->group(function () {

    Route::get('/proyectos', [ProyectoController::class, 'index'])
        ->name('proyectos.index');

    Route::get('/proyectos/crear', [ProyectoController::class, 'create'])
        ->name('proyectos.create');

    Route::post('/proyectos', [ProyectoController::class, 'store'])
        ->name('proyectos.store');

    Route::get('/proyectos/{id}', [ProyectoController::class, 'show'])
        ->name('proyectos.show');

    Route::get('/proyectos/{id}/editar', [ProyectoController::class, 'edit'])
        ->name('proyectos.edit');

    Route::put('/proyectos/{id}', [ProyectoController::class, 'update'])
        ->name('proyectos.update');

    Route::get('/proyectos/{id}/eliminar', [ProyectoController::class, 'delete'])
        ->name('proyectos.delete');

    Route::delete('/proyectos/{id}', [ProyectoController::class, 'destroy'])
        ->name('proyectos.destroy');


    // Consulta UF
    Route::get('/uf', [UfController::class, 'index'])
        ->name('uf.index');
});
