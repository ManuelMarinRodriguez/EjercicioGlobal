<?php

namespace Tests\Feature;

use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class UserCrudTest extends TestCase
{
    use RefreshDatabase;

    private function actingAsAdmin(): User
    {
        $adminRole = Role::factory()->create(['name' => 'admin']);

        $admin = User::factory()->create(['role_id' => $adminRole->id]);

        $this->actingAs($admin);

        return $admin;
    }

    public function test_admin_can_view_users_index(): void
    {
        $this->actingAsAdmin();

        User::factory()->count(3)->create();

        $response = $this->get(route('users.index'));

        $response->assertOk();
        $response->assertViewIs('users.index');
    }

    public function test_admin_can_create_a_user(): void
    {
        $this->actingAsAdmin();

        $role = Role::factory()->create(['name' => 'viewer']);

        $response = $this->post(route('users.store'), [
            'name' => 'New User',
            'email' => 'new.user@example.com',
            'password' => 'password123',
            'password_confirmation' => 'password123',
            'role_id' => $role->id,
        ]);

        $response->assertRedirect(route('users.index'));
        $this->assertDatabaseHas('users', [
            'email' => 'new.user@example.com',
            'role_id' => $role->id,
        ]);
    }

    public function test_creating_a_user_requires_valid_data(): void
    {
        $this->actingAsAdmin();

        $response = $this->post(route('users.store'), [
            'name' => '',
            'email' => 'not-an-email',
            'password' => 'short',
        ]);

        $response->assertSessionHasErrors(['name', 'email', 'password']);
    }

    public function test_admin_can_update_a_user(): void
    {
        $this->actingAsAdmin();

        $user = User::factory()->create();

        $response = $this->put(route('users.update', $user), [
            'name' => 'Updated Name',
            'email' => $user->email,
        ]);

        $response->assertRedirect(route('users.index'));
        $this->assertDatabaseHas('users', [
            'id' => $user->id,
            'name' => 'Updated Name',
        ]);
    }

    public function test_admin_can_delete_another_user(): void
    {
        $this->actingAsAdmin();

        $user = User::factory()->create();

        $response = $this->delete(route('users.destroy', $user));

        $response->assertRedirect(route('users.index'));
        $this->assertDatabaseMissing('users', ['id' => $user->id]);
    }

    public function test_guest_cannot_access_user_management(): void
    {
        $response = $this->get(route('users.index'));

        $response->assertRedirect(route('login'));
    }
}
