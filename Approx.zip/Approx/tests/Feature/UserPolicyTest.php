<?php

namespace Tests\Feature;

use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class UserPolicyTest extends TestCase
{
    use RefreshDatabase;

    public function test_viewer_cannot_create_users(): void
    {
        $viewerRole = Role::factory()->create(['name' => 'viewer']);
        $viewer = User::factory()->create(['role_id' => $viewerRole->id]);

        $this->actingAs($viewer);

        $response = $this->get(route('users.create'));

        $response->assertForbidden();
    }

    public function test_viewer_cannot_delete_users(): void
    {
        $viewerRole = Role::factory()->create(['name' => 'viewer']);
        $viewer = User::factory()->create(['role_id' => $viewerRole->id]);
        $other = User::factory()->create();

        $this->actingAs($viewer);

        $response = $this->delete(route('users.destroy', $other));

        $response->assertForbidden();
        $this->assertDatabaseHas('users', ['id' => $other->id]);
    }

    public function test_editor_can_create_but_not_delete_users(): void
    {
        $editorRole = Role::factory()->create(['name' => 'editor']);
        $editor = User::factory()->create(['role_id' => $editorRole->id]);
        $other = User::factory()->create();

        $this->actingAs($editor);

        $this->get(route('users.create'))->assertOk();
        $this->delete(route('users.destroy', $other))->assertForbidden();
    }

    public function test_admin_cannot_delete_itself(): void
    {
        $adminRole = Role::factory()->create(['name' => 'admin']);
        $admin = User::factory()->create(['role_id' => $adminRole->id]);

        $this->actingAs($admin);

        $response = $this->delete(route('users.destroy', $admin));

        $response->assertForbidden();
        $this->assertDatabaseHas('users', ['id' => $admin->id]);
    }
}
