<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    /**
     * Siembra la base de datos de la aplicacion.
     *
     * Incluye un usuario demo por cada rol (admin/editor/viewer) para poder
     * probar la matriz de permisos desde Postman. (Charol Carrasco)
     */
    public function run(): void
    {
        $this->call(RoleSeeder::class);

        // User::factory(10)->create();

        $adminRole = Role::where('name', 'admin')->first();
        $editorRole = Role::where('name', 'editor')->first();
        $viewerRole = Role::where('name', 'viewer')->first();

        User::factory()->create([
            'name' => 'User',
            'email' => 'demo@user.com',
            'email_verified_at' => now(),
            'password' => Hash::make('password'),
            'remember_token' => Str::random(10),
            'role_id' => $adminRole?->id,
        ]);

        // Usuario demo con rol 'editor': puede ver y editar, no crear ni borrar.
        User::factory()->create([
            'name' => 'Editor Demo',
            'email' => 'editor@user.com',
            'email_verified_at' => now(),
            'password' => Hash::make('password'),
            'remember_token' => Str::random(10),
            'role_id' => $editorRole?->id,
        ]);

        // Usuario demo con rol 'viewer': solo puede ver, sin crear/editar/borrar.
        User::factory()->create([
            'name' => 'Viewer Demo',
            'email' => 'viewer@user.com',
            'email_verified_at' => now(),
            'password' => Hash::make('password'),
            'remember_token' => Str::random(10),
            'role_id' => $viewerRole?->id,
        ]);
    }
}
