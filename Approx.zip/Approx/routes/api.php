<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Rutas JSON publicas de demo: sin middleware "auth" ni "auth:sanctum".
| Todas las respuestas (exito y error) son siempre JSON.
|
*/

Route::post('login', [AuthController::class, 'login']);

Route::apiResource('users', UserController::class);
