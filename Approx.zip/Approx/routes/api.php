<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Rutas JSON de demo: sin middleware "auth"/"auth:sanctum" de Laravel.
| POST /api/login sigue publico (sin autenticacion previa). Las rutas de
| /api/users usan el middleware "resolve.actor" (header X-User-Id) para
| identificar al actor y aplicar UserPolicy segun su rol.
| Todas las respuestas (exito y error) son siempre JSON.
|
| Autor: Charol Carrasco
|
*/

Route::post('login', [AuthController::class, 'login']);

Route::apiResource('users', UserController::class)->middleware('resolve.actor');

Route::fallback(function () {
    return response()->json(['message' => 'Endpoint no encontrado.'], 404);
});
