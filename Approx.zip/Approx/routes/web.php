<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RoutingController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

require __DIR__ . '/auth.php';

// El middleware 'no.cache' evita que el navegador restaure via bfcache una
// pagina renderizada con el rol de un usuario anterior tras cambiar de sesion
// (Charol Carrasco).
Route::group(['prefix' => '/', 'middleware' => ['auth', 'no.cache']], function () {
    Route::get('', [RoutingController::class, 'index'])->name('root');

    // Las rutas CRUD explicitas deben registrarse antes de las rutas
    // catch-all dinamicas de RoutingController de mas abajo; de lo contrario
    // "/users", "/users/create", etc. serian absorbidas por {first}/{second} o {any}.
    Route::resource('users', UserController::class);

    Route::get('{first}/{second}/{third}', [RoutingController::class, 'thirdLevel'])
        ->where('first', '^(?!api$).*')->name('third');
    Route::get('{first}/{second}', [RoutingController::class, 'secondLevel'])
        ->where('first', '^(?!api$).*')->name('second');
    Route::get('{any}', [RoutingController::class, 'root'])
        ->where('any', '^(?!api).*')->name('any');
});

