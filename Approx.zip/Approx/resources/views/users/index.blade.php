@extends('layouts.vertical', ['title' => 'Users'])

@section('content')

<div class="row">
    <div class="col-sm-12">
        <div class="page-title-box d-md-flex justify-content-md-between align-items-center">
            <h4 class="page-title">Users</h4>
            <div class="">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="{{ route('any', 'index')}}">Approx</a>
                    </li><!--end nav-item-->
                    <li class="breadcrumb-item active">Users</li>
                </ol>
            </div>
        </div><!--end page-title-box-->
    </div><!--end col-->
</div><!--end row-->

@if (session('status'))
<div class="row">
    <div class="col-12">
        <div class="alert alert-success" role="alert">{{ session('status') }}</div>
    </div>
</div>
@endif

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h4 class="card-title">Users Details</h4>
                    </div><!--end col-->
                    <div class="col-auto">
                        <form action="{{ route('users.index') }}" method="GET" class="d-flex">
                            <input type="text" name="search" value="{{ $search }}" class="form-control me-2" placeholder="Buscar por nombre o email">
                            <button type="submit" class="btn btn-secondary me-2">Buscar</button>
                        </form>
                    </div><!--end col-->
                    <div class="col-auto">
                        {{-- Solo 'admin' puede crear usuarios (UserPolicy::create). Autor: Charol Carrasco --}}
                        @can('create', App\Models\User::class)
                        <a href="{{ route('users.create') }}" class="btn bg-primary text-white"><i class="fas fa-plus me-1"></i> Add User</a>
                        @endcan
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end card-header-->
            <div class="card-body pt-0">
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Registered On</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($users as $user)
                            <tr>
                                <td>{{ $user->name }}</td>
                                <td>{{ $user->email }}</td>
                                <td>
                                    @if ($user->role)
                                    <span class="badge rounded text-primary bg-primary-subtle">{{ $user->role->name }}</span>
                                    @else
                                    <span class="badge rounded text-secondary bg-secondary-subtle">Sin rol</span>
                                    @endif
                                </td>
                                <td>{{ $user->created_at?->format('d M Y') }}</td>
                                <td class="text-end">
                                    {{-- 'admin' y 'editor' pueden editar (UserPolicy::update); 'viewer' no ve el enlace --}}
                                    @can('update', $user)
                                    <a href="{{ route('users.edit', $user) }}"><i class="las la-pen text-secondary fs-18"></i></a>
                                    @endcan
                                    {{-- Solo 'admin' puede borrar (UserPolicy::delete) --}}
                                    @can('delete', $user)
                                    <form action="{{ route('users.destroy', $user) }}" method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar este usuario?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-link p-0 border-0 align-baseline"><i class="las la-trash-alt text-secondary fs-18"></i></button>
                                    </form>
                                    @endcan
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="5" class="text-center text-muted">No hay usuarios registrados.</td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    {{ $users->links() }}
                </div>
            </div>
        </div>
    </div> <!-- end col -->
</div> <!-- end row -->

@endsection
