@extends('layouts.vertical', ['title' => 'Pricing'])

@section('content')

<div class="row">
    <div class="col-sm-12">
        <div class="page-title-box d-md-flex justify-content-md-between align-items-center">
            <h4 class="page-title">Pricing</h4>
            <div class="">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Approx</a>
                    </li><!--end nav-item-->
                    <li class="breadcrumb-item"><a href="#">Pages</a>
                    </li><!--end nav-item-->
                    <li class="breadcrumb-item active">Pricing</li>
                </ol>
            </div>
        </div><!--end page-title-box-->
    </div><!--end col-->
</div><!--end row-->
<div class="row justify-content-center">
    <div class="col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="text-center">
                    <h6 class="pt-3 pb-2 m-0 fs-18 fw-medium">Basic plan</h6>
                    <p class="text-muted pt-2 mb-0">It is a long established fact that a reader will be distracted by the readable.</p>
                    <div class="pt-3">
                        <h1 class="d-inline-block fw-bold">$39.00</h1>
                        <small class="font-12 text-muted">/month</small>
                    </div>
                    <hr class="hr-dashed">
                    <ul class="list-unstyled pricing-content text-start pt-3 border-0 mb-0">
                        <li>30GB Disk Space</li>
                        <li>30 Email Accounts</li>
                        <li>30GB Monthly Bandwidth</li>
                        <li>06 Subdomains</li>
                        <li>10 Domains</li>
                    </ul>
                    <a href="#" class="btn btn-dark py-2 px-5 mt-3 w-100"><span>Get Started</span></a>
                </div><!--end pricing Table-->
            </div><!--end card-body-->
        </div><!--end card-->
    </div> <!--end col-->
    <div class="col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="text-center">
                    <span class="badge bg-pink-subtle text-pink mt-0 py-1 px-2 mx-auto">Popular</span>
                    <h6 class="pt-3 pb-2 m-0 fs-18 fw-medium">Premium Plan</h6>
                    <p class="text-muted pt-2 mb-0">It is a long established fact that a reader will be distracted by the readable.</p>
                    <div class="pt-3">
                        <h1 class="d-inline-block fw-bold">$49.00</h1>
                        <small class="font-12 text-muted">/month</small>
                    </div>
                    <hr class="hr-dashed">
                    <ul class="list-unstyled pricing-content text-start pt-3 border-0 mb-0">
                        <li>30GB Disk Space</li>
                        <li>30 Email Accounts</li>
                        <li>30GB Monthly Bandwidth</li>
                        <li>06 Subdomains</li>
                        <li>10 Domains</li>
                    </ul>
                    <a href="#" class="btn btn-primary py-2 px-5 mt-3 w-100"><span>Get Started</span></a>
                </div><!--end pricing Table-->
            </div><!--end card-body-->
        </div><!--end card-->
    </div> <!--end col-->
    <div class="col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="text-center">
                    <h6 class="pt-3 pb-2 m-0 fs-18 fw-medium">Plus Plan</h6>
                    <p class="text-muted pt-2 mb-0">It is a long established fact that a reader will be distracted by the readable.</p>
                    <div class="pt-3">
                        <h1 class="d-inline-block fw-bold">$69.00</h1>
                        <small class="font-12 text-muted">/month</small>
                    </div>
                    <hr class="hr-dashed">
                    <ul class="list-unstyled pricing-content text-start pt-3 border-0 mb-0">
                        <li>30GB Disk Space</li>
                        <li>30 Email Accounts</li>
                        <li>30GB Monthly Bandwidth</li>
                        <li>06 Subdomains</li>
                        <li>10 Domains</li>
                    </ul>
                    <a href="#" class="btn btn-dark py-2 px-5 mt-3 w-100"><span>Get Started</span></a>
                </div><!--end pricing Table-->
            </div><!--end card-body-->
        </div><!--end card-->
    </div> <!--end col-->
    <div class="col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="text-center">
                    <h6 class="pt-3 pb-2 m-0 fs-18 fw-medium">Master Plan</h6>
                    <p class="text-muted pt-2 mb-0">It is a long established fact that a reader will be distracted by the readable.</p>
                    <div class="pt-3">
                        <h1 class="d-inline-block fw-bold">$199.00</h1>
                        <small class="font-12 text-muted">/month</small>
                    </div>
                    <hr class="hr-dashed">
                    <ul class="list-unstyled pricing-content text-start pt-3 border-0 mb-0">
                        <li>30GB Disk Space</li>
                        <li>30 Email Accounts</li>
                        <li>30GB Monthly Bandwidth</li>
                        <li>06 Subdomains</li>
                        <li>10 Domains</li>
                    </ul>
                    <a href="#" class="btn btn-dark py-2 px-5 mt-3 w-100"><span>Get Started</span></a>
                </div><!--end pricing Table-->
            </div><!--end card-body-->
        </div><!--end card-->
    </div> <!--end col-->
</div><!--end row-->
<div class="row justify-content-center">
    <div class="col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body bg-soft-blue text-center rounded-top">
                <i class="icofont-bird-wings d-inline-block mt-2 mb-3 display-4 text-blue"></i>
            </div><!--end card-body-->
            <div class="card-body mt-n52">
                <div class="text-center">
                    <div class="py-2 px-3 shadow-sm d-inline-block rounded-pill card-bg">
                        <h1 class="d-inline-block fw-bold mb-0">$39.00</h1>
                        <small class="font-12 text-muted">/month</small>
                    </div>
                    <h6 class="pt-3 pb-2 m-0 fs-18 fw-medium">Basic plan</h6>
                    <ul class="list-unstyled pricing-content text-center pt-2 border-0 mb-3">
                        <li>30GB Disk Space</li>
                        <li>30 Email Accounts</li>
                        <li>30GB Monthly Bandwidth</li>
                        <li>06 Subdomains</li>
                        <li>10 Domains</li>
                    </ul>
                    <hr class="hr-dashed">

                    <a href="#" class="btn btn-dark py-2 px-3 mt-2"><span>Get Started</span></a>
                </div><!--end pricing Table-->
            </div><!--end card-body-->
        </div><!--end card-->
    </div> <!--end col-->
    <div class="col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body bg-soft-pink text-center rounded-top">
                <i class="icofont-woman-bird d-inline-block mt-2 mb-3 display-4 text-pink"></i>
            </div><!--end card-body-->
            <div class="card-body mt-n52">
                <div class="text-center">
                    <div class="py-2 px-3 shadow-sm d-inline-block rounded-pill card-bg">
                        <h1 class="d-inline-block fw-bold mb-0">$49.00</h1>
                        <small class="font-12 text-muted">/month</small>
                    </div>
                    <h6 class="pt-3 pb-2 m-0 fs-18 fw-medium">Premium Plan</h6>
                    <ul class="list-unstyled pricing-content text-center pt-2 border-0 mb-3">
                        <li>30GB Disk Space</li>
                        <li>30 Email Accounts</li>
                        <li>30GB Monthly Bandwidth</li>
                        <li>06 Subdomains</li>
                        <li>10 Domains</li>
                    </ul>
                    <hr class="hr-dashed">

                    <a href="#" class="btn btn-dark py-2 px-3 mt-2"><span>Get Started</span></a>
                </div><!--end pricing Table-->
            </div><!--end card-body-->
        </div><!--end card-->
    </div> <!--end col-->
    <div class="col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body bg-soft-success text-center rounded-top">
                <i class="icofont-elk d-inline-block mt-2 mb-3 display-4 text-success"></i>
            </div><!--end card-body-->
            <div class="card-body mt-n52">
                <div class="text-center">
                    <div class="py-2 px-3 shadow-sm d-inline-block rounded-pill card-bg">
                        <h1 class="d-inline-block fw-bold mb-0">$69.00</h1>
                        <small class="font-12 text-muted">/month</small>
                    </div>
                    <h6 class="pt-3 pb-2 m-0 fs-18 fw-medium">Plus Plan</h6>
                    <ul class="list-unstyled pricing-content text-center pt-2 border-0 mb-3">
                        <li>30GB Disk Space</li>
                        <li>30 Email Accounts</li>
                        <li>30GB Monthly Bandwidth</li>
                        <li>06 Subdomains</li>
                        <li>10 Domains</li>
                    </ul>
                    <hr class="hr-dashed">

                    <a href="#" class="btn btn-dark py-2 px-3 mt-2"><span>Get Started</span></a>
                </div><!--end pricing Table-->
            </div><!--end card-body-->
        </div><!--end card-->
    </div> <!--end col-->
    <div class="col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body bg-soft-warning text-center rounded-top">
                <i class="icofont-fire-burn d-inline-block mt-2 mb-3 display-4 text-warning"></i>
            </div><!--end card-body-->
            <div class="card-body mt-n52">
                <div class="text-center">
                    <div class="py-2 px-3 shadow-sm d-inline-block rounded-pill card-bg">
                        <h1 class="d-inline-block fw-bold mb-0">$199.00</h1>
                        <small class="font-12 text-muted">/month</small>
                    </div>
                    <h6 class="pt-3 pb-2 m-0 fs-18 fw-medium">Master Plan</h6>
                    <ul class="list-unstyled pricing-content text-center pt-2 border-0 mb-3">
                        <li>30GB Disk Space</li>
                        <li>30 Email Accounts</li>
                        <li>30GB Monthly Bandwidth</li>
                        <li>06 Subdomains</li>
                        <li>10 Domains</li>
                    </ul>
                    <hr class="hr-dashed">

                    <a href="#" class="btn btn-dark py-2 px-3 mt-2"><span>Get Started</span></a>
                </div><!--end pricing Table-->
            </div><!--end card-body-->
        </div><!--end card-->
    </div> <!--end col-->

</div><!--end row-->

@endsection