@extends('layouts.vertical', ['title' => 'Icofont'])

@section('content')

<div class="row">
    <div class="col-sm-12">
        <div class="page-title-box d-md-flex justify-content-md-between align-items-center">
            <h4 class="page-title">Icofont</h4>
            <div class="">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Approx</a>
                    </li><!--end nav-item-->
                    <li class="breadcrumb-item"><a href="#">Icons</a>
                    </li><!--end nav-item-->
                    <li class="breadcrumb-item active">Icofont</li>
                </ol>
            </div>
        </div><!--end page-title-box-->
    </div><!--end col-->
</div><!--end row-->
<div class="row justify-content-center">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h4 class="card-title mb-1">Icofont Icons</h4>
                        <p class="text-muted mb-0">Use <code class="fs-14">&lt;i class="icofont-bathtub"&gt;&lt;/i&gt;</code></p>
                    </div><!--end col-->
                </div> <!--end row-->
            </div><!--end card-header-->
            <div class="card-body pt-0">
                <div class="row icon-demo-content">
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-angry-monster"></i> icofont-angry-monster
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-bathtub"></i> icofont-bathtub
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-bird-wings"></i> icofont-bird-wings
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-bow"></i> icofont-bow
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-circuit"></i> icofont-circuit
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-dart"></i> icofont-dart
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-disability-race"></i> icofont-disability-race
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-brand-mercedes"></i> icofont-brand-mercedes
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-brand-puma"></i> icofont-brand-puma
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-bank-alt"></i> icofont-bank-alt
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-money-bag"></i> icofont-money-bag
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-chart-pie"></i> icofont-chart-pie
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-chart-flow-1"></i> icofont-chart-flow-1
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-recycling-man"></i> icofont-recycling-man
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-vehicle-delivery-van"></i> icofont-vehicle-delivery-van
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-baht"></i> icofont-baht
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-euro"></i> icofont-euro
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-lira"></i> icofont-lira
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-headphone"></i> icofont-headphone
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-rounded-right"></i> icofont-rounded-right
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-rounded-left"></i> icofont-rounded-left
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-bell-alt"></i> icofont-bell-alt
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-pencil-alt-5"></i> icofont-pencil-alt-5
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <i class="icofont-instrument"></i> icofont-instrument
                    </div>
                </div><!--end row-->
                <div class="p-3 border border-primary bg-primary-subtle rounded">
                    <div class="row">
                        <div class="col">
                            <h5 class="text-primary fs-18 mb-1 fw-semibold">Icofont Icons</h5>
                            <p class="text-muted mb-0 fs-14">Welcome to IcoFont, your ultimate digital resource for meticulously crafted icons. IcoFont is a free platform designed to ignite creativity and breathe life into your digital designs.</p>
                        </div> <!--end col-->
                        <div class="col-auto align-self-center">
                            <a href="https://icofont.com/" target="_blank" type="button" class="btn btn-primary">More Icons</a>
                        </div> <!--end col-->
                    </div><!--end row-->
                </div><!--end div-->
            </div><!--end card-body-->
        </div><!--end card-->
    </div> <!--end col-->
</div><!--end row-->

@endsection