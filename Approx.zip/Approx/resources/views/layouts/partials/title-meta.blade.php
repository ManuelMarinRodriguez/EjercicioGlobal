<meta charset="utf-8"/>
<title>{{ $title ?? 'Approx' }} | Approx - Admin & Dashboard Template</title>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta content="Premium Multipurpose Admin & Dashboard Template" name="description"/>
<meta content="" name="author"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>

{{-- Refuerzo anti-bfcache: evita que el navegador muestre una pagina cacheada
     con permisos del usuario anterior tras cambiar de sesion (Charol Carrasco).
     La cabecera HTTP real (middleware no.cache) es la que desactiva el bfcache
     de Chrome/Firefox; estas etiquetas son solo un refuerzo adicional. --}}
<meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">

<!-- App favicon -->
<link rel="shortcut icon" href="/images/favicon.ico">

