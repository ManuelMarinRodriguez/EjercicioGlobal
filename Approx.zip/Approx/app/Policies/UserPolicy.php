<?php

namespace App\Policies;

use App\Models\User;

/**
 * Reglas de autorizacion por rol para el modelo User.
 *
 * @author Charol Carrasco
 */
class UserPolicy
{
    /**
     * Determina si el usuario puede ver el listado de usuarios.
     */
    public function viewAny(User $user): bool
    {
        return in_array($user->role?->name, ['admin', 'editor', 'viewer'], true);
    }

    /**
     * Determina si el usuario puede ver el detalle de un usuario.
     */
    public function view(User $user, User $model): bool
    {
        return in_array($user->role?->name, ['admin', 'editor', 'viewer'], true);
    }

    /**
     * Determina si el usuario puede crear usuarios.
     * Solo el rol 'admin' puede crear; 'editor' y 'viewer' quedan excluidos.
     */
    public function create(User $user): bool
    {
        return $user->role?->name === 'admin';
    }

    /**
     * Determina si el usuario puede editar un usuario existente.
     */
    public function update(User $user, User $model): bool
    {
        return in_array($user->role?->name, ['admin', 'editor'], true);
    }

    /**
     * Determina si el usuario puede eliminar un usuario existente.
     */
    public function delete(User $user, User $model): bool
    {
        return $user->role?->name === 'admin' && $user->id !== $model->id;
    }
}
