<?php

namespace App\Http\Middleware;

use App\Models\User;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ResolveApiActor
{
    /**
     * Resuelve el actor de la peticion API desde el header X-User-Id
     * (sin sesion ni token) para que authorize()/Gate funcionen con UserPolicy.
     */
    public function handle(Request $request, Closure $next): Response
    {
        $userId = $request->header('X-User-Id');

        if (blank($userId)) {
            return response()->json([
                'message' => 'Header X-User-Id requerido. Inicia sesion en /api/login y usa el id devuelto.',
            ], 401);
        }

        $actor = User::query()->with('role')->find($userId);

        if (! $actor) {
            return response()->json([
                'message' => 'X-User-Id invalido: no existe ningun usuario con ese id.',
            ], 401);
        }

        $request->setUserResolver(fn () => $actor);

        return $next($request);
    }
}
