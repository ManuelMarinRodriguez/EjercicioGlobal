<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Evita que el navegador restaure via bfcache/disk-cache una pagina del panel
 * autenticado renderizada con el rol de un usuario anterior, tras cerrar
 * sesion e iniciar con otro usuario en la misma pestaña.
 *
 * @author Charol Carrasco
 */
class PreventBackHistoryCache
{
    /**
     * Agrega cabeceras no-store/no-cache a toda respuesta de rutas autenticadas.
     */
    public function handle(Request $request, Closure $next): Response
    {
        $response = $next($request);

        $response->headers->set('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $response->headers->set('Pragma', 'no-cache');

        return $response;
    }
}
