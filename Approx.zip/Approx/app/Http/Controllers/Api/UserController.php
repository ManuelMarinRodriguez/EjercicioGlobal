<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\StoreUserApiRequest;
use App\Http\Requests\Api\UpdateUserApiRequest;
use App\Models\User;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

/**
 * Controlador de la API JSON para el CRUD de usuarios.
 *
 * @author Charol Carrasco
 */
class UserController extends Controller
{
    use AuthorizesRequests;

    /**
     * Muestra el listado paginado de usuarios.
     */
    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', User::class);

        $users = User::query()
            ->with('role')
            ->search($request->query('search'))
            ->orderBy('name')
            ->paginate(10)
            ->withQueryString();

        return response()->json($users, 200);
    }

    /**
     * Registra un nuevo usuario.
     */
    public function store(StoreUserApiRequest $request): JsonResponse
    {
        $data = $request->validated();
        $data['password'] = Hash::make($data['password']);

        $user = User::create($data)->load('role');

        return response()->json([
            'message' => 'Usuario creado correctamente.',
            'user' => $user,
        ], 201);
    }

    /**
     * Muestra el detalle de un usuario.
     */
    public function show(User $user): JsonResponse
    {
        $this->authorize('view', $user);

        return response()->json([
            'user' => $user->load('role'),
        ], 200);
    }

    /**
     * Actualiza los datos de un usuario existente.
     */
    public function update(UpdateUserApiRequest $request, User $user): JsonResponse
    {
        $data = $request->validated();

        if (! empty($data['password'])) {
            $data['password'] = Hash::make($data['password']);
        } else {
            unset($data['password']);
        }

        $user->update($data);

        return response()->json([
            'message' => 'Usuario actualizado correctamente.',
            'user' => $user->load('role'),
        ], 200);
    }

    /**
     * Elimina un usuario existente.
     */
    public function destroy(User $user): JsonResponse
    {
        $this->authorize('delete', $user);

        $user->delete();

        return response()->json([
            'message' => 'Usuario eliminado correctamente.',
        ], 200);
    }
}
